import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { AudioAssetCatalog, DEFAULT_CURATED_AUDIO_CATALOG } from '../../src/assets/catalog.ts';
import { AudioAssetValidator } from '../../src/assets/validator.ts';
import { LocalAudioAssetProvider } from '../../src/assets/local_provider.ts';
import { AudioAssetCache } from '../../src/assets/cache.ts';
import fs from 'node:fs';
import path from 'node:path';

describe('Audio Asset Catalog & Validator', () => {
  it('should initialize with default curated catalog', () => {
    const catalog = new AudioAssetCatalog();
    assert.ok(catalog.count() > 0, 'Catalog should contain default assets');
    const all = catalog.getAll();
    assert.strictEqual(all.length, DEFAULT_CURATED_AUDIO_CATALOG.length);
  });

  it('should query music tracks by category, mood, and energy', () => {
    const catalog = new AudioAssetCatalog();
    const musicTracks = catalog.query({ type: 'music' });
    assert.ok(musicTracks.length > 0, 'Should have music tracks');
    assert.ok(musicTracks.every(t => t.type === 'music'));

    const energeticMusic = catalog.query({ type: 'music', energyLevel: 'high' });
    assert.ok(energeticMusic.length > 0);
    assert.ok(energeticMusic.every(t => t.energyLevel === 'high'));

    const cinematic = catalog.query({ type: 'music', category: 'cinematic' });
    assert.ok(cinematic.length > 0);
    assert.ok(cinematic.every(t => t.category === 'cinematic'));
  });

  it('should query SFX assets by category', () => {
    const catalog = new AudioAssetCatalog();
    const sfxAssets = catalog.query({ type: 'sfx' });
    assert.ok(sfxAssets.length > 0, 'Should have SFX assets');
    assert.ok(sfxAssets.every(s => s.type === 'sfx'));

    const whooshes = catalog.query({ type: 'sfx', category: 'whoosh' });
    assert.ok(whooshes.length > 0);
    assert.ok(whooshes.every(w => w.category === 'whoosh'));

    const impacts = catalog.query({ type: 'sfx', category: 'impact' });
    assert.ok(impacts.length > 0);
    assert.ok(impacts.every(i => i.category === 'impact'));
  });

  it('should validate valid audio asset metadata', () => {
    const asset = DEFAULT_CURATED_AUDIO_CATALOG[0];
    const res = AudioAssetValidator.validateMetadata(asset, { requireCommercialUse: true });
    assert.strictEqual(res.valid, true);
    assert.strictEqual(res.issues.filter(i => i.severity === 'error').length, 0);
  });

  it('should reject invalid metadata or non-commercial assets when commercial is required', () => {
    const invalidAsset: any = {
      assetId: '',
      filename: '',
      type: 'invalid_type',
      category: 'music',
      energyLevel: 'super_high',
      durationSeconds: -10,
      license: '',
      commercialUsePermitted: false,
      checksumSha256: 'short',
    };

    const res = AudioAssetValidator.validateMetadata(invalidAsset, { requireCommercialUse: true });
    assert.strictEqual(res.valid, false);
    assert.ok(res.issues.some(i => i.field === 'assetId'));
    assert.ok(res.issues.some(i => i.field === 'durationSeconds'));
    assert.ok(res.issues.some(i => i.field === 'commercialUsePermitted'));
  });

  it('should generate offline mock audio files cleanly via LocalAudioAssetProvider', async () => {
    const provider = new LocalAudioAssetProvider();
    const asset = DEFAULT_CURATED_AUDIO_CATALOG[0];
    const testDestDir = path.resolve('./.cache/clipforge/test_assets');

    const stagedFile = await provider.getAssetFile(asset, testDestDir);
    assert.ok(fs.existsSync(stagedFile), 'Generated audio file must exist');
    assert.ok(fs.statSync(stagedFile).size > 0, 'Audio file must be non-empty');

    const validation = AudioAssetValidator.validateAudioFile(stagedFile);
    assert.strictEqual(validation.valid, true);

    // Cleanup
    if (fs.existsSync(stagedFile)) {
      fs.unlinkSync(stagedFile);
    }
  });

  it('should cache asset files via AudioAssetCache', () => {
    const cache = new AudioAssetCache({ cacheDir: './.cache/clipforge/test_cache' });
    const asset = DEFAULT_CURATED_AUDIO_CATALOG[0];
    const dummySrc = path.resolve('./.cache/clipforge/test_cache/temp_source.bin');
    fs.mkdirSync(path.dirname(dummySrc), { recursive: true });
    fs.writeFileSync(dummySrc, 'test_audio_bytes');

    const cached = cache.setCachedFile(asset, dummySrc);
    assert.ok(fs.existsSync(cached));
    assert.strictEqual(cache.getCachedFile(asset), cached);

    // In-memory caching
    cache.set('key_1', { hello: 'world' });
    assert.deepStrictEqual(cache.get('key_1'), { hello: 'world' });

    // Cleanup
    if (fs.existsSync(dummySrc)) fs.unlinkSync(dummySrc);
    if (fs.existsSync(cached)) fs.unlinkSync(cached);
  });
});
