import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { AudioAssetCatalog } from '../../src/assets/catalog.ts';
import { AudioAssetSelector } from '../../src/assets/selector.ts';

describe('Audio Asset Selector (Deterministic Scoring)', () => {
  const catalog = new AudioAssetCatalog();
  const selector = new AudioAssetSelector(catalog);

  it('should deterministically select the optimal music track for short-form tech video', () => {
    const selection1 = selector.selectMusic({
      format: 'short',
      topic: 'AI Technology breakthroughs',
      targetMood: 'energetic',
      desiredEnergy: 'high',
      totalDurationSeconds: 45,
      commercialUseRequired: true,
    });

    assert.ok(selection1, 'Music selection should not be null');
    assert.strictEqual(selection1.purpose, 'background_music');
    assert.strictEqual(selection1.asset.type, 'music');
    assert.strictEqual(selection1.asset.commercialUsePermitted, true);
    assert.strictEqual(selection1.volumeLevel, 0.18, 'Short-form music volume should be 0.18');
    assert.strictEqual(selection1.fadeInSeconds, 0.5);

    // Repeat execution to verify determinism
    const selection2 = selector.selectMusic({
      format: 'short',
      topic: 'AI Technology breakthroughs',
      targetMood: 'energetic',
      desiredEnergy: 'high',
      totalDurationSeconds: 45,
      commercialUseRequired: true,
    });

    assert.strictEqual(selection1.asset.assetId, selection2?.asset.assetId, 'Selection must be 100% deterministic');
  });

  it('should calculate loop count when music track is shorter than video duration', () => {
    const selection = selector.selectMusic({
      format: 'long',
      topic: 'Ancient archaeological mysteries documentary',
      targetMood: 'curious',
      desiredEnergy: 'medium',
      totalDurationSeconds: 300, // 5 minutes
      commercialUseRequired: true,
    });

    assert.ok(selection);
    if (selection.asset.durationSeconds < 300 && selection.asset.loopable) {
      assert.ok(selection.loopCount && selection.loopCount > 1, 'Loop count should be > 1');
      assert.strictEqual(selection.loopCount, Math.ceil(300 / selection.asset.durationSeconds));
    }
  });

  it('should apply repetition penalty to avoid selecting recently used tracks', () => {
    const context = {
      format: 'short' as const,
      topic: 'Robotics',
      targetMood: 'energetic',
      desiredEnergy: 'high' as const,
      totalDurationSeconds: 30,
      commercialUseRequired: true,
    };

    const firstPick = selector.selectMusic(context);
    assert.ok(firstPick);

    // Run again with firstPick in recentlyUsedAssetIds
    const secondPick = selector.selectMusic({
      ...context,
      recentlyUsedAssetIds: [firstPick.asset.assetId],
    });

    assert.ok(secondPick);
    assert.notStrictEqual(
      secondPick.asset.assetId,
      firstPick.asset.assetId,
      'Repetition penalty should deprioritize recent asset'
    );
  });

  it('should deterministically select SFX for different editing landmarks', () => {
    const hookSfx = selector.selectSfx({
      purpose: 'hook',
      desiredEnergy: 'high',
      commercialUseRequired: true,
    });
    assert.ok(hookSfx);
    assert.strictEqual(hookSfx.type, 'sfx');
    assert.ok(['whoosh', 'impact', 'hit'].includes(hookSfx.category));

    const statSfx = selector.selectSfx({
      purpose: 'statistic_reveal',
      desiredEnergy: 'medium',
      commercialUseRequired: true,
    });
    assert.ok(statSfx);
    assert.strictEqual(statSfx.type, 'sfx');
    assert.ok(['click', 'hit', 'transition'].includes(statSfx.category));

    const interruptSfx = selector.selectSfx({
      purpose: 'pattern_interrupt',
      desiredEnergy: 'high',
      commercialUseRequired: true,
    });
    assert.ok(interruptSfx);
    assert.strictEqual(interruptSfx.type, 'sfx');
    assert.ok(['glitch', 'whoosh', 'riser'].includes(interruptSfx.category));
  });
});
