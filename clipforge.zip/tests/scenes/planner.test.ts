import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { GeminiScenePlanningProvider } from '../../src/scenes/gemini.ts';
import { ScenePlanner } from '../../src/scenes/engine.ts';
import { ScriptArtifact } from '../../src/contracts/script.ts';
import { NarrationArtifact } from '../../src/contracts/narration.ts';
import { LocalStorageProvider } from '../../src/storage/local.ts';
import { CacheManager } from '../../src/storage/cache.ts';
import fs from 'node:fs';
import path from 'node:path';

describe('Scene Planner Engine & Provider', () => {
  const mockScript: ScriptArtifact = {
    jobId: 'job_test_scene_001',
    topic: 'CRISPR Gene Editing Revolutions',
    title: 'How CRISPR Rewrote Medicine',
    format: 'short',
    totalWordCount: 80,
    estimatedTotalDurationSeconds: 24.5,
    segments: [
      {
        segmentId: 'seg_001',
        sectionIndex: 0,
        sectionName: 'Hook',
        narrationText: 'For decades, genetic diseases were an inescapable life sentence.',
        estimatedDurationSeconds: 4.2,
        emphasisKeywords: ['genetic diseases', 'sentence'],
        visualIntentDescription: 'Dramatic medical laboratory microscope footage of DNA strands',
        sourceReference: 'National Institutes of Health',
      },
      {
        segmentId: 'seg_002',
        sectionIndex: 1,
        sectionName: 'Core Mechanism',
        narrationText: 'Then scientists discovered bacteria using molecular scissors to cut invading viruses with laser accuracy.',
        estimatedDurationSeconds: 6.8,
        emphasisKeywords: ['molecular scissors', 'viruses', 'laser accuracy'],
        visualIntentDescription: '3D scientific rendering of Cas9 protein cleaving a double helix DNA strand',
        sourceReference: 'Science Journal 2020',
      },
      {
        segmentId: 'seg_003',
        sectionIndex: 2,
        sectionName: 'Impact',
        narrationText: 'Today, clinical trials are curing sickle cell anemia in real human patients.',
        estimatedDurationSeconds: 5.5,
        emphasisKeywords: ['clinical trials', 'curing', 'sickle cell'],
        visualIntentDescription: 'Doctor consulting smiling patient in modern hospital room',
        sourceReference: 'Clinical Trials 2023',
      },
    ],
  };

  const mockNarration: NarrationArtifact = {
    jobId: 'job_test_scene_001',
    createdAt: new Date().toISOString(),
    scriptReference: 'jobs/job_test_scene_001/script.json',
    engine: 'piper',
    modelOrVoice: 'en_US-lessac-medium',
    totalDurationSeconds: 16.5,
    segmentResults: [
      {
        segmentId: 'seg_001',
        audioFilePath: '/tmp/seg_001.wav',
        actualDurationSeconds: 4.2,
        sampleRateHz: 22050,
        channels: 1,
        audioFormat: 'wav',
      },
      {
        segmentId: 'seg_002',
        audioFilePath: '/tmp/seg_002.wav',
        actualDurationSeconds: 6.8,
        sampleRateHz: 22050,
        channels: 1,
        audioFormat: 'wav',
      },
      {
        segmentId: 'seg_003',
        audioFilePath: '/tmp/seg_003.wav',
        actualDurationSeconds: 5.5,
        sampleRateHz: 22050,
        channels: 1,
        audioFormat: 'wav',
      },
    ],
  };

  it('generates scenes directly corresponding to script segments and narration timing', async () => {
    const provider = new GeminiScenePlanningProvider({ apiKey: '' });
    const scenesArtifact = await provider.planScenes(mockScript, mockNarration);

    assert.equal(scenesArtifact.format, 'short');
    assert.ok(scenesArtifact.scenes.length >= 3);
    assert.equal(scenesArtifact.scenes[0].targetAspectRatio, '9:16');

    // Verify duration equals sum of narration exactly
    assert.equal(scenesArtifact.totalDurationSeconds, 16.5);

    // Verify first scene is tied to seg_001
    assert.equal(scenesArtifact.scenes[0].correspondingSegmentId, 'seg_001');
    assert.ok(scenesArtifact.scenes[0].searchKeywords.length >= 1);
  });

  it('splits long segments into multi-shot scenes to maintain active visual pacing', async () => {
    const provider = new GeminiScenePlanningProvider({ apiKey: '' });
    // seg_002 is 6.8s which exceeds default short maxSceneDuration 4.5s
    const scenesArtifact = await provider.planScenes(mockScript, mockNarration);

    const seg2Scenes = scenesArtifact.scenes.filter(s => s.correspondingSegmentId === 'seg_002');
    assert.ok(seg2Scenes.length >= 2, 'Should have split 6.8s segment into at least 2 shots');

    // Sum of split shots must equal segment duration
    const seg2DurationSum = seg2Scenes.reduce((sum, s) => sum + s.desiredDurationSeconds, 0);
    assert.ok(Math.abs(seg2DurationSum - 6.8) < 0.05);
  });

  it('generates targeted queries derived from visual concept, not just topic', async () => {
    const provider = new GeminiScenePlanningProvider({ apiKey: '' });
    const scenesArtifact = await provider.planScenes(mockScript, mockNarration);

    const allQueries = scenesArtifact.scenes.flatMap(s => s.searchKeywords);
    // Queries should contain visual elements
    const hasSpecificVisualTerms = allQueries.some(
      q => q.includes('dna') || q.includes('scissors') || q.includes('microscope') || q.includes('clinical')
    );
    assert.ok(hasSpecificVisualTerms, 'Search queries must reflect visual concept details');
  });

  it('supports long-form 16:9 aspect ratio target', async () => {
    const provider = new GeminiScenePlanningProvider({ apiKey: '' });
    const longScript: ScriptArtifact = {
      ...mockScript,
      format: 'long',
    };
    const scenesArtifact = await provider.planScenes(longScript, mockNarration, undefined, undefined, {
      format: 'long',
    });

    assert.equal(scenesArtifact.format, 'long');
    assert.equal(scenesArtifact.scenes[0].targetAspectRatio, '16:9');
    assert.equal(scenesArtifact.scenes[0].preferredOrientation, 'landscape');
  });

  it('ScenePlanner coordinates validation and storage persistence', async () => {
    const testDir = path.resolve('./.cache/test_scenes_engine');
    if (fs.existsSync(testDir)) fs.rmSync(testDir, { recursive: true, force: true });

    const storage = new LocalStorageProvider(testDir);
    const cache = new CacheManager(storage);
    const engine = new ScenePlanner({
      storage,
      cache,
      provider: new GeminiScenePlanningProvider({ apiKey: '', cache }),
    });

    const result = await engine.executeScenePlanning(mockScript, mockNarration);
    assert.ok(result.totalScenes > 0);
    assert.ok(await storage.exists('inputs', `jobs/${mockScript.jobId}/scenes.json`));

    if (fs.existsSync(testDir)) fs.rmSync(testDir, { recursive: true, force: true });
  });
});
