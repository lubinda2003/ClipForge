import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { validateScenesArtifact } from '../../src/scenes/validator.ts';
import { ScenesArtifact } from '../../src/contracts/scenes.ts';

describe('Scenes Artifact Validator', () => {
  const validArtifact: ScenesArtifact = {
    jobId: 'job_val_01',
    format: 'short',
    totalScenes: 2,
    totalDurationSeconds: 8.5,
    scenes: [
      {
        sceneId: 'scene_001',
        correspondingSegmentId: 'seg_001',
        sequenceOrder: 0,
        narrationExcerpt: 'First line',
        visualConcept: 'Futuristic city street with holograms',
        searchKeywords: ['futuristic city', 'neon street'],
        preferredVisualType: 'realistic_video',
        desiredDurationSeconds: 4.0,
        targetAspectRatio: '9:16',
        format: 'short',
        visualMood: 'energetic',
        allowCropping: true,
        startTimeSeconds: 0,
        endTimeSeconds: 4.0,
      },
      {
        sceneId: 'scene_002',
        correspondingSegmentId: 'seg_002',
        sequenceOrder: 1,
        narrationExcerpt: 'Second line',
        visualConcept: 'Scientist analyzing hologram',
        searchKeywords: ['scientist lab', 'hologram research'],
        preferredVisualType: 'realistic_video',
        desiredDurationSeconds: 4.5,
        targetAspectRatio: '9:16',
        format: 'short',
        visualMood: 'contemplative',
        allowCropping: true,
        startTimeSeconds: 4.0,
        endTimeSeconds: 8.5,
      },
    ],
  };

  it('validates a correct scenes artifact', () => {
    const result = validateScenesArtifact(validArtifact);
    assert.equal(result.isValid, true);
    assert.equal(result.errors.length, 0);
  });

  it('rejects empty scenes array', () => {
    const invalid: ScenesArtifact = {
      ...validArtifact,
      totalScenes: 0,
      scenes: [],
    };
    const result = validateScenesArtifact(invalid);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.some(e => e.includes('at least one scene')));
  });

  it('rejects duplicate scene IDs', () => {
    const invalid: ScenesArtifact = {
      ...validArtifact,
      scenes: [
        validArtifact.scenes[0],
        { ...validArtifact.scenes[1], sceneId: 'scene_001' },
      ],
    };
    const result = validateScenesArtifact(invalid);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.some(e => e.includes('Duplicate sceneId')));
  });

  it('rejects non-positive desiredDurationSeconds', () => {
    const invalid: ScenesArtifact = {
      ...validArtifact,
      scenes: [
        { ...validArtifact.scenes[0], desiredDurationSeconds: 0 },
        validArtifact.scenes[1],
      ],
    };
    const result = validateScenesArtifact(invalid);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.some(e => e.includes('desiredDurationSeconds')));
  });

  it('rejects mismatched aspect ratio', () => {
    const invalid: ScenesArtifact = {
      ...validArtifact,
      format: 'short',
      scenes: [
        { ...validArtifact.scenes[0], targetAspectRatio: '16:9' },
        validArtifact.scenes[1],
      ],
    };
    const result = validateScenesArtifact(invalid);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.some(e => e.includes('targetAspectRatio')));
  });
});
