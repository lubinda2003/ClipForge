import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

import { MediaOutputValidator } from '../../src/rendering/validator.ts';
import { FfprobeRunner } from '../../src/rendering/ffprobe.ts';
import { SHORT_FORM_PROFILE, LONG_FORM_PROFILE } from '../../src/contracts/rendering.ts';

describe('Phase 6: Media Output Validator Tests', () => {
  const tmpDir = './.cache/clipforge/test_validator';
  if (!fs.existsSync(tmpDir)) {
    fs.mkdirSync(tmpDir, { recursive: true });
  }

  it('FfprobeRunner probes existing video file correctly', async () => {
    // Generate a quick 1-second 1080x1920 test MP4 using FFmpeg
    const testVideoPath = path.join(tmpDir, 'probe_test.mp4');
    execFileSync('ffmpeg', [
      '-y',
      '-f', 'lavfi',
      '-i', 'color=c=blue:s=1080x1920:d=1.5:r=30',
      '-f', 'lavfi',
      '-i', 'anullsrc=r=44100:cl=stereo',
      '-t', '1.5',
      '-c:v', 'libx264',
      '-c:a', 'aac',
      '-pix_fmt', 'yuv420p',
      testVideoPath,
    ]);

    const runner = new FfprobeRunner();
    const data = await runner.probe(testVideoPath);

    assert.equal(data.videoStream?.width, 1080);
    assert.equal(data.videoStream?.height, 1920);
    assert.equal(data.videoStream?.codecName, 'h264');
    assert.equal(data.audioStream?.codecName, 'aac');
    assert.ok(Math.abs(data.format.duration - 1.5) < 0.2);
    assert.ok((data.format.sizeBytes || 0) > 0);
  });

  it('MediaOutputValidator passes compliant short-form video', async () => {
    const testVideoPath = path.join(tmpDir, 'probe_test.mp4');
    const validator = new MediaOutputValidator();
    const result = await validator.validate(testVideoPath, {
      profile: SHORT_FORM_PROFILE,
      targetDurationSeconds: 1.5,
      jobId: 'job_val_01',
    });

    assert.equal(result.status, 'passed');
    assert.equal(result.checks.fileExists, true);
    assert.equal(result.checks.nonEmpty, true);
    assert.equal(result.checks.containerValid, true);
    assert.equal(result.checks.videoStreamValid, true);
    assert.equal(result.checks.audioStreamValid, true);
    assert.equal(result.checks.dimensionsValid, true);
    assert.equal(result.checks.durationValid, true);
    assert.equal(result.checks.videoCodecValid, true);
    assert.equal(result.checks.audioCodecValid, true);
    assert.equal(result.errors.length, 0);
  });

  it('MediaOutputValidator fails for non-existent file', async () => {
    const validator = new MediaOutputValidator();
    const result = await validator.validate('/tmp/non_existent_video_12345.mp4', {
      profile: SHORT_FORM_PROFILE,
      targetDurationSeconds: 5.0,
      jobId: 'job_val_02',
    });

    assert.equal(result.status, 'failed');
    assert.equal(result.checks.fileExists, false);
    assert.ok(result.errors.some((e) => e.includes('does not exist')));
  });

  it('MediaOutputValidator detects resolution and aspect ratio mismatch', async () => {
    // Probe test video is 1080x1920 (short form 9:16), but validate against LONG_FORM_PROFILE (1920x1080)
    const testVideoPath = path.join(tmpDir, 'probe_test.mp4');
    const validator = new MediaOutputValidator();
    const result = await validator.validate(testVideoPath, {
      profile: LONG_FORM_PROFILE,
      targetDurationSeconds: 1.5,
      jobId: 'job_val_03',
    });

    assert.equal(result.status, 'failed');
    assert.equal(result.checks.dimensionsValid, false);
    assert.ok(result.errors.some((e) => e.includes('Dimensions mismatch')));
  });
});
