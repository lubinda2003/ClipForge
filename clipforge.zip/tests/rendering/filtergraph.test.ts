import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { FilterGraphAssembler } from '../../src/rendering/filters.ts';
import { VideoTrackBuilder } from '../../src/rendering/video.ts';
import { AudioMixerBuilder } from '../../src/rendering/audio.ts';
import { CaptionFilterBuilder } from '../../src/rendering/captions.ts';
import { MotionTransformBuilder } from '../../src/rendering/motion.ts';
import { SHORT_FORM_PROFILE, LONG_FORM_PROFILE } from '../../src/contracts/rendering.ts';
import { TimelineArtifact } from '../../src/contracts/timeline.ts';

describe('Phase 6: Filter Graph Construction Unit Tests', () => {
  it('VideoTrackBuilder correctly formats scale, setsar=1, and concat', () => {
    const filters = VideoTrackBuilder.buildVideoPipeline(
      [
        {
          elementId: 'v_01',
          sceneId: 'sc_01',
          sourceFilePath: '/tmp/test_v1.mp4',
          startTimelineSeconds: 0,
          durationSeconds: 5.0,
          sourceTrimStartSeconds: 0,
          motionEffect: 'ken_burns_zoom_in',
          cropOrScale: { scaleMode: 'smart_center_crop', aspectRatio: '9:16' },
          transitionIn: { type: 'fade', durationSeconds: 0.5 },
        },
      ],
      [],
      [0],
      SHORT_FORM_PROFILE,
      5.0,
      'v_out'
    );

    const script = filters.filterLines.join('; ');
    assert.ok(script.includes('setsar=1'), 'Must apply setsar=1 to avoid concat pad mismatches');
    assert.ok(script.includes('scale='), 'Must scale to profile dimensions');
    assert.ok(script.includes('trim='), 'Must apply duration trim');
    assert.ok(script.includes('fade='), 'Must apply fade transition');
  });

  it('AudioMixerBuilder constructs ducking volume envelope expressions', () => {
    const duckingFilter = AudioMixerBuilder.buildDuckingExpression(
      [
        { timestampSeconds: 0, volumeMultiplier: 0.8 },
        { timestampSeconds: 1.0, volumeMultiplier: 0.15 },
        { timestampSeconds: 4.0, volumeMultiplier: 0.15 },
        { timestampSeconds: 5.0, volumeMultiplier: 0.8 },
      ],
      1.0
    );

    assert.ok(duckingFilter.includes('volume='), 'Must use volume expression');
    assert.ok(duckingFilter.includes('if(lt(t,'), 'Must use if(lt(t,...)) nested conditions');
  });

  it('CaptionFilterBuilder safely escapes characters and formats drawtext filter', () => {
    const drawtext = CaptionFilterBuilder.buildFilter(
      {
        elementId: 'cap_01',
        primaryText: "It's 100% true: special 'characters' & colons!",
        startTimelineSeconds: 1.5,
        durationSeconds: 3.0,
        styleVariant: 'bold_caption',
        positioning: {
          horizontalAlign: 'center',
          verticalAlign: 'bottom',
          safeZoneMargins: {
            topPercent: 15,
            bottomPercent: 20,
            leftPercent: 8,
            rightPercent: 18,
          },
        },
      },
      SHORT_FORM_PROFILE
    );

    assert.ok(drawtext.includes('drawtext='), 'Must contain drawtext=');
    assert.ok(drawtext.includes('between(t,1.50,4.50)'), 'Must include time enable expression');
    assert.ok(drawtext.includes('fontcolor='), 'Must set font styling');
    assert.ok(!drawtext.includes("It's"), 'Apostrophes must be escaped');
  });

  it('MotionTransformBuilder generates Ken Burns pan/zoom filters', () => {
    const zoomIn = MotionTransformBuilder.buildFilter({
      effect: 'ken_burns_zoom_in',
      width: LONG_FORM_PROFILE.resolution.width,
      height: LONG_FORM_PROFILE.resolution.height,
      durationSeconds: 5.0,
      fps: 30,
    });
    assert.ok(zoomIn.includes('scale=eval=frame'), 'Must scale dynamically per frame');
    assert.ok(zoomIn.includes('crop='), 'Must crop to target dimensions');

    const panLeft = MotionTransformBuilder.buildFilter({
      effect: 'slow_pan_left',
      width: SHORT_FORM_PROFILE.resolution.width,
      height: SHORT_FORM_PROFILE.resolution.height,
      durationSeconds: 4.0,
      fps: 30,
    });
    assert.ok(panLeft.includes('crop='), 'Must crop along pan axis');
    assert.ok(panLeft.includes('scale='), 'Must scale prior to crop');
  });

  it('FilterGraphAssembler outputs valid filter_complex script from timeline', () => {
    const mockTimeline: TimelineArtifact = {
      jobId: 'job_test_fg',
      format: 'short',
      aspectRatio: '9:16',
      totalDurationSeconds: 6.0,
      tracks: {
        video: [
          {
            elementId: 'v_01',
            sceneId: 'sc_01',
            sourceFilePath: '/tmp/test_v1.mp4',
            startTimelineSeconds: 0,
            durationSeconds: 6.0,
            sourceTrimStartSeconds: 0,
            motionEffect: 'ken_burns_zoom_in',
            cropOrScale: { scaleMode: 'smart_center_crop', aspectRatio: '9:16' },
            transitionIn: { type: 'fade', durationSeconds: 0.5 },
          },
        ],
        narration: [
          {
            elementId: 'a_nar_01',
            segmentId: 'seg_01',
            audioFilePath: '/tmp/test_nar.wav',
            startTimelineSeconds: 0.5,
            durationSeconds: 5.0,
            volume: 1.0,
          },
        ],
        music: [
          {
            elementId: 'a_mus_01',
            type: 'music',
            audioFilePath: '/tmp/test_mus.wav',
            startTimelineSeconds: 0,
            durationSeconds: 6.0,
            volume: 0.8,
            loop: true,
            duckingEnvelope: [
              { timestampSeconds: 0, volumeMultiplier: 0.8 },
              { timestampSeconds: 0.5, volumeMultiplier: 0.2 },
              { timestampSeconds: 5.5, volumeMultiplier: 0.2 },
              { timestampSeconds: 6.0, volumeMultiplier: 0.8 },
            ],
          },
        ],
        sfx: [],
        textOverlays: [
          {
            elementId: 'txt_01',
            primaryText: 'Breaking Discovery',
            startTimelineSeconds: 0.5,
            durationSeconds: 3.0,
            styleVariant: 'bold_caption',
            positioning: {
              horizontalAlign: 'center',
              verticalAlign: 'bottom',
              safeZoneMargins: {
                topPercent: 15,
                bottomPercent: 20,
                leftPercent: 8,
                rightPercent: 18,
              },
            },
          },
        ],
      },
      retentionAnnotations: [],
    };

    const graph = FilterGraphAssembler.assemble(
      mockTimeline,
      SHORT_FORM_PROFILE,
      (p) => p
    );

    assert.equal(graph.inputs.length, 3, 'Must register 3 input streams (video, narration, music)');
    assert.ok(graph.filterComplexScript.includes('[v_out]'), 'Must terminate with [v_out] video pad');
    assert.ok(graph.filterComplexScript.includes('[a_out]'), 'Must terminate with [a_out] audio pad');
    assert.ok(graph.filterComplexScript.includes('drawtext='), 'Must include caption filter');
    assert.ok(graph.filterComplexScript.includes('amix='), 'Must mix audio channels');
  });
});

