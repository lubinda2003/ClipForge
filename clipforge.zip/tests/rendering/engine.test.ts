import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

import { RenderEngine } from '../../src/rendering/engine.ts';
import { SHORT_FORM_PROFILE } from '../../src/contracts/rendering.ts';
import { TimelineArtifact } from '../../src/contracts/timeline.ts';

describe('Phase 6: RenderEngine Orchestrator Unit Tests', () => {
  const testBaseDir = './.cache/clipforge/test_render_engine';
  if (!fs.existsSync(testBaseDir)) {
    fs.mkdirSync(testBaseDir, { recursive: true });
  }

  it('checks FFmpeg and FFprobe environment availability', async () => {
    const engine = new RenderEngine({ baseDirectory: testBaseDir });
    const env = await engine.checkEnvironment();

    assert.equal(env.ffmpegAvailable, true);
    assert.equal(env.ffprobeAvailable, true);
    assert.ok(env.ffmpegVersion.length > 0);
    assert.ok(env.ffprobeVersion.length > 0);
  });

  it('renders a real multi-track timeline into a valid MP4 with audio and captions', async () => {
    const engine = new RenderEngine({ baseDirectory: testBaseDir });
    const jobId = 'job_test_engine_render';

    // Generate real minimal media inputs for the test
    const clipVideoPath = path.join(testBaseDir, 'engine_clip.mp4');
    const clipAudioPath = path.join(testBaseDir, 'engine_narration.wav');
    const musicAudioPath = path.join(testBaseDir, 'engine_music.wav');

    // 2-second test video
    execFileSync('ffmpeg', [
      '-y',
      '-f', 'lavfi',
      '-i', 'color=c=red:s=720x1280:d=2.0:r=30',
      '-c:v', 'libx264',
      '-pix_fmt', 'yuv420p',
      clipVideoPath,
    ]);

    // 2-second test narration tone
    execFileSync('ffmpeg', [
      '-y',
      '-f', 'lavfi',
      '-i', 'sine=frequency=440:duration=2.0',
      clipAudioPath,
    ]);

    // 2-second test music tone
    execFileSync('ffmpeg', [
      '-y',
      '-f', 'lavfi',
      '-i', 'sine=frequency=220:duration=2.0',
      musicAudioPath,
    ]);

    const timeline: TimelineArtifact = {
      jobId,
      format: 'short',
      aspectRatio: '9:16',
      totalDurationSeconds: 2.0,
      tracks: {
        video: [
          {
            elementId: 'v_01',
            sceneId: 'sc_01',
            sourceFilePath: clipVideoPath,
            startTimelineSeconds: 0,
            durationSeconds: 2.0,
            sourceTrimStartSeconds: 0,
            motionEffect: 'slow_zoom_in',
            cropOrScale: { scaleMode: 'smart_center_crop', aspectRatio: '9:16' },
          },
        ],
        narration: [
          {
            elementId: 'nar_01',
            segmentId: 'seg_01',
            audioFilePath: clipAudioPath,
            startTimelineSeconds: 0,
            durationSeconds: 2.0,
            volume: 1.0,
          },
        ],
        music: [
          {
            elementId: 'mus_01',
            type: 'music',
            audioFilePath: musicAudioPath,
            startTimelineSeconds: 0,
            durationSeconds: 2.0,
            volume: 0.5,
            duckingEnvelope: [
              { timestampSeconds: 0, volumeMultiplier: 0.5 },
              { timestampSeconds: 2.0, volumeMultiplier: 0.5 },
            ],
          },
        ],
        sfx: [],
        textOverlays: [
          {
            elementId: 'ov_01',
            primaryText: 'RenderEngine Test',
            startTimelineSeconds: 0.2,
            durationSeconds: 1.6,
            styleVariant: 'bold_caption',
            positioning: {
              horizontalAlign: 'center',
              verticalAlign: 'bottom',
              safeZoneMargins: {
                topPercent: 15,
                bottomPercent: 20,
                leftPercent: 8,
                rightPercent: 18,
              },
            },
          },
        ],
      },
      retentionAnnotations: [],
    };

    const result = await engine.executeRender({
      jobId,
      timeline,
      profile: SHORT_FORM_PROFILE,
    });

    assert.equal(result.jobId, jobId);
    assert.ok(fs.existsSync(result.outputPath));
    assert.equal(result.width, 1080);
    assert.equal(result.height, 1920);
    assert.equal(result.videoCodec, 'h264');
    assert.equal(result.audioCodec, 'aac');
    assert.ok(result.fileSize > 0);
    assert.equal(result.validation.status, 'passed');
    assert.ok(result.renderTime > 0);
  });
});
