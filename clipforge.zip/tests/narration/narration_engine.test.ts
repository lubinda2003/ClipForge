import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { NarrationEngine } from '../../src/narration/engine.ts';
import { PiperNarrationProvider } from '../../src/narration/piper.ts';
import { ScriptArtifact } from '../../src/contracts/script.ts';
import { LocalStorageProvider } from '../../src/storage/local.ts';

describe('Narration Engine', () => {
  const tmpDir = path.join(os.tmpdir(), `clipforge_engine_test_${Date.now()}`);

  const mockScript: ScriptArtifact = {
    jobId: 'job_narrate_test_101',
    title: 'Why Concorde Failed',
    topic: 'Concorde Supersonic Flight',
    format: 'short',
    totalWordCount: 45,
    estimatedTotalDurationSeconds: 18.0,
    segments: [
      {
        segmentId: 'seg_001',
        sectionIndex: 0,
        sectionName: 'Hook',
        narrationText: 'Concorde did not fail because of ticket prices.',
        estimatedDurationSeconds: 3.5,
        emphasisKeywords: ['Concorde', 'ticket prices'],
        visualIntentDescription: 'Concorde archival footage',
      },
      {
        segmentId: 'seg_002',
        sectionIndex: 1,
        sectionName: 'Mechanism',
        narrationText: 'It failed because supersonic booms were banned over populated land in 1973.',
        estimatedDurationSeconds: 6.5,
        emphasisKeywords: ['supersonic booms', 'banned'],
        visualIntentDescription: 'Map of flight bans',
      },
      {
        segmentId: 'seg_003',
        sectionIndex: 2,
        sectionName: 'Payoff',
        narrationText: 'Until aircraft shape eliminates the sonic thump, supersonic flight cannot scale.',
        estimatedDurationSeconds: 5.5,
        emphasisKeywords: ['sonic thump', 'scale'],
        visualIntentDescription: 'X-59 low-boom aircraft schematic',
      },
    ],
  };

  it('synthesizes full script, measures durations, and records narration.json artifact', async () => {
    const storage = new LocalStorageProvider(tmpDir);
    const engine = new NarrationEngine({
      storage,
      provider: new PiperNarrationProvider({ mockMode: true }),
    });

    const narration = await engine.executeNarration(mockScript, {
      jobId: 'job_narrate_test_101',
    });

    assert.equal(narration.jobId, 'job_narrate_test_101');
    assert.equal(narration.engine, 'piper');
    assert.equal(narration.segmentResults.length, 3);
    assert.ok(narration.totalDurationSeconds > 0);

    // Verify all segment audio files exist on disk
    for (const seg of narration.segmentResults) {
      assert.ok(fs.existsSync(seg.audioFilePath), `Audio file ${seg.audioFilePath} must exist`);
      assert.ok(seg.actualDurationSeconds > 0);
      assert.equal(seg.audioFormat, 'wav');
    }

    // Verify sum of segments matches totalDurationSeconds within 0.05s
    const sum = narration.segmentResults.reduce((acc, s) => acc + s.actualDurationSeconds, 0);
    assert.ok(Math.abs(sum - narration.totalDurationSeconds) < 0.05);

    // Verify narration.json is persisted in storage
    const savedArtifactPath = path.join(tmpDir, 'inputs', 'jobs', 'job_narrate_test_101', 'narration.json');
    assert.ok(fs.existsSync(savedArtifactPath), 'narration.json must be saved in storage');

    const savedContent = JSON.parse(fs.readFileSync(savedArtifactPath, 'utf-8'));
    assert.equal(savedContent.jobId, 'job_narrate_test_101');
    assert.equal(savedContent.segmentResults.length, 3);

    fs.rmSync(tmpDir, { recursive: true, force: true });
  });
});
