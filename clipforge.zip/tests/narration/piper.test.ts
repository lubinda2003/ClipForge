import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { PiperNarrationProvider } from '../../src/narration/piper.ts';
import { CacheManager } from '../../src/storage/cache.ts';
import { LocalStorageProvider } from '../../src/storage/local.ts';
import { createMockWavBuffer } from '../../src/narration/duration.ts';

describe('Piper Narration Provider', () => {
  const tmpDir = path.join(os.tmpdir(), `clipforge_piper_test_${Date.now()}`);

  it('synthesizes segment and measures actual duration in mock mode', async () => {
    const provider = new PiperNarrationProvider({ mockMode: true });
    const outPath = path.join(tmpDir, 'mock_seg_001.wav');

    const result = await provider.synthesizeSegment('seg_001', 'This is a test narration for ClipForge.', outPath);

    assert.equal(result.segmentId, 'seg_001');
    assert.equal(result.audioFormat, 'wav');
    assert.ok(result.actualDurationSeconds > 0);
    assert.ok(fs.existsSync(outPath));
    assert.ok(fs.statSync(outPath).size > 44);

    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('invokes piper binary with correct arguments and streams stdin text', async () => {
    let capturedCmd = '';
    let capturedArgs: string[] = [];
    let capturedStdin = '';

    const customRunner = async (cmd: string, args: string[], stdin?: string) => {
      capturedCmd = cmd;
      capturedArgs = args;
      capturedStdin = stdin || '';

      // Find the output file argument and write a valid WAV file
      const outIdx = args.indexOf('--output_file');
      if (outIdx !== -1 && args[outIdx + 1]) {
        const outPath = args[outIdx + 1];
        const wav = createMockWavBuffer(2.5, 22050, 1, 16);
        fs.writeFileSync(outPath, wav);
      }

      return { code: 0, stdout: '', stderr: '' };
    };

    const provider = new PiperNarrationProvider({
      binPath: '/usr/local/bin/piper',
      modelPath: 'en_US-lessac-medium',
      commandRunner: customRunner,
    });

    const outPath = path.join(tmpDir, 'custom_runner_test.wav');
    const result = await provider.synthesizeSegment('seg_002', 'Spoken line testing CLI runner.', outPath, {
      speed: 1.25,
    });

    assert.equal(capturedCmd, '/usr/local/bin/piper');
    assert.ok(capturedArgs.includes('--model'));
    assert.ok(capturedArgs.includes('en_US-lessac-medium'));
    assert.ok(capturedArgs.includes('--output_file'));
    assert.ok(capturedArgs.includes('--length_scale'));
    assert.equal(capturedStdin, 'Spoken line testing CLI runner.');
    assert.ok(result.actualDurationSeconds > 0);

    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('reuses cached audio for identical text and model settings', async () => {
    const storage = new LocalStorageProvider(path.join(tmpDir, 'cache_store'));
    const cache = new CacheManager(storage);

    let executions = 0;
    const runner = async (_cmd: string, args: string[], _stdin?: string) => {
      executions++;
      const outIdx = args.indexOf('--output_file');
      const outPath = args[outIdx + 1];
      fs.writeFileSync(outPath, createMockWavBuffer(3.0));
      return { code: 0, stdout: '', stderr: '' };
    };

    const provider = new PiperNarrationProvider({
      cache,
      commandRunner: runner,
    });

    const outPath1 = path.join(tmpDir, 'cache_test_1.wav');
    const outPath2 = path.join(tmpDir, 'cache_test_2.wav');

    const res1 = await provider.synthesizeSegment('seg_003', 'Deterministic text cache test.', outPath1);
    const res2 = await provider.synthesizeSegment('seg_003', 'Deterministic text cache test.', outPath2);

    assert.equal(executions, 1, 'Piper should only execute once due to caching');
    assert.ok(fs.existsSync(outPath1));
    assert.ok(fs.existsSync(outPath2));
    assert.equal(res1.actualDurationSeconds, res2.actualDurationSeconds);

    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('rejects empty narration text', async () => {
    const provider = new PiperNarrationProvider({ mockMode: true });
    await assert.rejects(
      async () => {
        await provider.synthesizeSegment('seg_empty', '   ', path.join(tmpDir, 'empty.wav'));
      },
      /Narration text is empty/
    );
  });
});
