import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {
  readWavHeaderMetadata,
  measureAudioDuration,
  createMockWavBuffer,
} from '../../src/narration/duration.ts';

describe('Audio Duration & Metadata Analyzer', () => {
  const tmpDir = path.join(os.tmpdir(), `clipforge_audio_test_${Date.now()}`);

  it('accurately parses binary WAV header for exact duration and channel metadata', async () => {
    if (!fs.existsSync(tmpDir)) {
      fs.mkdirSync(tmpDir, { recursive: true });
    }

    const testWavPath = path.join(tmpDir, 'test_audio.wav');
    const targetDuration = 4.25; // 4.25 seconds
    const sampleRate = 22050;
    const channels = 1;

    const wavBuffer = createMockWavBuffer(targetDuration, sampleRate, channels, 16);
    fs.writeFileSync(testWavPath, wavBuffer);

    // Read header directly
    const meta = readWavHeaderMetadata(testWavPath);
    assert.equal(meta.format, 'wav');
    assert.equal(meta.sampleRateHz, 22050);
    assert.equal(meta.channels, 1);
    assert.equal(meta.bitsPerSample, 16);
    // Float precision tolerance within 0.01s
    assert.ok(Math.abs(meta.durationSeconds - targetDuration) < 0.01, `Duration ${meta.durationSeconds} should match ${targetDuration}`);

    // Call measureAudioDuration
    const measured = await measureAudioDuration(testWavPath);
    assert.equal(measured.sampleRateHz, 22050);
    assert.ok(Math.abs(measured.durationSeconds - targetDuration) < 0.01);

    // Clean up
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('rejects invalid or corrupted audio containers', () => {
    if (!fs.existsSync(tmpDir)) {
      fs.mkdirSync(tmpDir, { recursive: true });
    }

    const badFile = path.join(tmpDir, 'corrupted.wav');
    fs.writeFileSync(badFile, Buffer.from('NOT_A_VALID_RIFF_WAV_HEADER_DATA_123456789012345678901234567890'));

    assert.throws(() => {
      readWavHeaderMetadata(badFile);
    }, /Invalid audio container/);

    const tooSmallFile = path.join(tmpDir, 'too_small.wav');
    fs.writeFileSync(tooSmallFile, Buffer.from('tiny'));
    assert.throws(() => {
      readWavHeaderMetadata(tooSmallFile);
    }, /too small/);

    fs.rmSync(tmpDir, { recursive: true, force: true });
  });
});
