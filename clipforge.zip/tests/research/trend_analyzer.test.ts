import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { analyzePublicTrends } from '../../src/research/trend_analyzer.ts';
import { YouTubePublicVideoMetadata } from '../../src/contracts/research.ts';

describe('Public Signal Trend Analyzer', () => {
  it('returns insufficient_data for empty input', () => {
    const assessment = analyzePublicTrends([], 'rare topic');
    assert.equal(assessment.trendStatus, 'insufficient_data');
    assert.equal(assessment.confidence, 'low');
    assert.ok(assessment.evidence.length > 0);
  });

  it('detects emerging trend when majority of videos are recent with high velocity', () => {
    const now = Date.now();
    const MS_PER_DAY = 1000 * 60 * 60 * 24;

    const mockVideos: YouTubePublicVideoMetadata[] = [
      {
        videoId: 'v1',
        title: 'Breakthrough Announced Yesterday',
        description: '',
        publishedAt: new Date(now - 2 * MS_PER_DAY).toISOString(),
        channelId: 'c1',
        channelTitle: 'Tech News',
        viewCount: 85000,
      },
      {
        videoId: 'v2',
        title: 'Why Everyone Is Talking About It',
        description: '',
        publishedAt: new Date(now - 5 * MS_PER_DAY).toISOString(),
        channelId: 'c2',
        channelTitle: 'Deep Dive',
        viewCount: 42000,
      },
      {
        videoId: 'v3',
        title: 'Initial Reactions and Test',
        description: '',
        publishedAt: new Date(now - 12 * MS_PER_DAY).toISOString(),
        channelId: 'c3',
        channelTitle: 'Analysis',
        viewCount: 31000,
      },
    ];

    const assessment = analyzePublicTrends(mockVideos, 'breakthrough technology');
    assert.equal(assessment.trendStatus, 'emerging');
    assert.equal(assessment.confidence, 'high');
    assert.ok(assessment.analysis.includes('emerging'));
  });

  it('detects stable / evergreen trend for older videos across multiple months', () => {
    const now = Date.now();
    const MS_PER_DAY = 1000 * 60 * 60 * 24;

    const mockVideos: YouTubePublicVideoMetadata[] = [
      {
        videoId: 'v1',
        title: 'History of the Roman Republic',
        description: '',
        publishedAt: new Date(now - 60 * MS_PER_DAY).toISOString(),
        channelId: 'c1',
        channelTitle: 'History Channel',
        viewCount: 15000,
      },
      {
        videoId: 'v2',
        title: 'Fall of the Republic Explained',
        description: '',
        publishedAt: new Date(now - 75 * MS_PER_DAY).toISOString(),
        channelId: 'c2',
        channelTitle: 'Classics',
        viewCount: 22000,
      },
      {
        videoId: 'v3',
        title: 'Roman Senate Architecture',
        description: '',
        publishedAt: new Date(now - 80 * MS_PER_DAY).toISOString(),
        channelId: 'c3',
        channelTitle: 'Ancient Rome',
        viewCount: 18000,
      },
    ];

    const assessment = analyzePublicTrends(mockVideos, 'Roman Republic');
    assert.equal(assessment.trendStatus, 'stable');
  });
});
