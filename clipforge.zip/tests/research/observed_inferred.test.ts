import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { ResearchEngine } from '../../src/research/engine.ts';
import { IGeminiResearchProvider, IYouTubeProvider } from '../../src/research/interfaces.ts';
import { ResearchArtifact } from '../../src/contracts/research.ts';

describe('Strict Separation: Observed Data vs Inferred Insights', () => {
  it('enforces boundaries between observed facts and strategic inferences', async () => {
    // Mock YouTube provider returning deterministic observed data
    const mockYouTubeProvider: IYouTubeProvider = {
      providerName: 'mock_youtube',
      isAvailable: () => true,
      searchPublicVideos: async () => ({
        videos: [
          {
            videoId: 'demo1',
            title: 'How Batteries Work in 2025',
            description: 'Solid state battery chemistry',
            publishedAt: '2025-02-01T00:00:00Z',
            channelId: 'chan1',
            channelTitle: 'ElectroLab',
            viewCount: 50000,
          },
        ],
      }),
    };

    // Mock Gemini provider returning structured separation
    const mockGeminiProvider: IGeminiResearchProvider = {
      providerName: 'mock_gemini',
      isAvailable: () => true,
      synthesizeResearch: async () => ({
        topicSummary: 'Overview of solid state battery progress.',
        verifiableFacts: [
          {
            claim: 'Solid-state batteries replace liquid electrolyte with solid material.',
            source: 'MIT Technology Review',
            confidence: 'high',
          },
        ],
        commonQuestions: ['When will solid-state batteries be in cars?'],
        competitorTitles: ['How Batteries Work in 2025'],
        inferredInsights: {
          audienceInterestLevel: 'viral_potential',
          saturationLevel: 'moderate',
          promisingContentAngles: ['Why the manufacturing bottleneck is the real story'],
          contentGapsIdentified: ['Lack of practical cost breakdown'],
          potentialHooks: ['The battery breakthrough everyone missed.'],
          curiosityGaps: ['Why lab success does not equal commercial reality'],
          narrativeAngles: ['Scientific premise vs Industrial scale'],
        },
        claimsRequiringVerification: [
          {
            claim: 'Production cost will decrease by 70% by 2027.',
            reason: 'Forward-looking industry projection requires explicit attribution.',
            verificationRequired: true,
          },
        ],
      }),
    };

    const engine = new ResearchEngine({
      youtubeProvider: mockYouTubeProvider,
      geminiProvider: mockGeminiProvider,
    });

    const artifact: ResearchArtifact = await engine.executeResearch('solid state batteries', {
      format: 'short',
    });

    // 1. Observed Data checks
    assert.ok(artifact.observedData);
    assert.equal(artifact.observedData.topic, 'solid state batteries');
    assert.equal(artifact.observedData.youtubePublicVideos.length, 1);
    assert.equal(artifact.observedData.verifiableFacts.length, 1);
    assert.equal(artifact.observedData.verifiableFacts[0].source, 'MIT Technology Review');

    // 2. Inferred Insights checks (must NOT be treated as empirical observations)
    assert.ok(artifact.inferredInsights);
    assert.equal(artifact.inferredInsights.audienceInterestLevel, 'viral_potential');
    assert.equal(artifact.inferredInsights.saturationLevel, 'moderate');
    assert.ok(artifact.inferredInsights.potentialHooks.length > 0);
    assert.ok(artifact.inferredInsights.trendAssessment);

    // 3. Claims requiring verification
    assert.ok(artifact.inferredInsights.claimsRequiringVerification);
    assert.equal(artifact.inferredInsights.claimsRequiringVerification[0].verificationRequired, true);
  });
});
