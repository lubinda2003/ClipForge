import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { generateResearchQueries } from '../../src/research/query_generator.ts';

describe('Research Query Generator', () => {
  it('generates multi-dimensional search queries for a topic', () => {
    const queries = generateResearchQueries('quantum computing', { maxQueries: 6 });

    assert.ok(queries.length > 0);
    assert.ok(queries.length <= 6);
    assert.ok(queries.some(q => q.toLowerCase().includes('quantum computing')));
    // Must include varied angles like explanation, data, controversy, future
    assert.ok(queries.some(q => q.includes('how it works') || q.includes('explained')));
  });

  it('deduplicates queries and respects bounds', () => {
    const queries = generateResearchQueries('Artificial Intelligence', { maxQueries: 3 });
    assert.equal(queries.length, 3);
    const unique = new Set(queries.map(q => q.toLowerCase()));
    assert.equal(unique.size, 3);
  });

  it('handles empty or whitespace topic safely', () => {
    const emptyQueries = generateResearchQueries('   ');
    assert.deepEqual(emptyQueries, []);
  });
});
