import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { LocalStorageProvider } from '../../src/storage/local.ts';
import { CacheManager } from '../../src/storage/cache.ts';

describe('Research Caching Layer', () => {
  const testCacheDir = path.resolve('./.cache/test_cache');
  let storage: LocalStorageProvider;
  let cache: CacheManager;

  beforeEach(() => {
    if (fs.existsSync(testCacheDir)) {
      fs.rmSync(testCacheDir, { recursive: true, force: true });
    }
    storage = new LocalStorageProvider(testCacheDir);
    cache = new CacheManager(storage, 3600);
  });

  afterEach(() => {
    if (fs.existsSync(testCacheDir)) {
      fs.rmSync(testCacheDir, { recursive: true, force: true });
    }
  });

  it('generates deterministic keys for identical requests regardless of object key order', () => {
    const key1 = cache.generateKey('youtube', { query: 'fusion', max: 5 });
    const key2 = cache.generateKey('youtube', { max: 5, query: 'fusion' });

    assert.equal(key1, key2);
    assert.ok(key1.startsWith('cache/youtube/'));
    assert.ok(key1.endsWith('.json'));
  });

  it('stores and retrieves payloads successfully', async () => {
    const key = cache.generateKey('test_provider', { topic: 'fusion' });
    const payload = { result: 'verified', count: 42 };

    await cache.set('test_provider', key, payload);

    const retrieved = await cache.get<typeof payload>(key);
    assert.deepEqual(retrieved, payload);
  });

  it('returns null on cache miss', async () => {
    const missing = await cache.get('cache/non_existent/123.json');
    assert.equal(missing, null);
  });

  it('invalidates expired cache items', async () => {
    const key = cache.generateKey('short_lived', { id: 1 });
    const payload = { temp: true };

    // Set with negative TTL so it is already expired
    await cache.set('short_lived', key, payload, -1);

    const retrieved = await cache.get(key);
    assert.equal(retrieved, null);
  });
});
