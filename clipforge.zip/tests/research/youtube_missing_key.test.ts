import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { YouTubeResearchProvider } from '../../src/research/youtube.ts';

describe('YouTube Missing API Key Handling', () => {
  it('gracefully reports unavailable when key is empty or missing', async () => {
    const provider = new YouTubeResearchProvider({ apiKey: '' });

    assert.equal(provider.isAvailable(), false);

    const result = await provider.searchPublicVideos('solar flare');
    assert.deepEqual(result.videos, []);
    assert.ok(result.error);
    assert.ok(result.error.includes('not configured'));
  });

  it('never fabricates citations or video entries when unconfigured', async () => {
    const provider = new YouTubeResearchProvider({ apiKey: undefined });
    const result = await provider.searchPublicVideos('artificial superintelligence');

    assert.equal(result.videos.length, 0);
  });
});
