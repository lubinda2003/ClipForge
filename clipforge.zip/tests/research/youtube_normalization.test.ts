import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { YouTubeResearchProvider } from '../../src/research/youtube.ts';
import { YouTubePublicVideoMetadata } from '../../src/contracts/research.ts';

describe('YouTube Response Normalization', () => {
  it('correctly maps raw YouTube API payload and distinguishes undefined counts from zero', async () => {
    // Mock global fetch to simulate YouTube API search and videos responses
    const originalFetch = globalThis.fetch;

    const mockSearchResponse = {
      items: [
        {
          id: { videoId: 'vid123' },
          snippet: {
            title: 'Deep Dive into Fusion Energy',
            description: 'A comprehensive look at fusion reactors.',
            publishedAt: '2025-01-15T10:00:00Z',
            channelId: 'chan456',
            channelTitle: 'Science Today',
            thumbnails: { high: { url: 'https://img.youtube.com/vi/vid123/hqdefault.jpg' } },
          },
        },
      ],
      pageInfo: { totalResults: 1 },
    };

    const mockVideosResponse = {
      items: [
        {
          id: 'vid123',
          snippet: {
            title: 'Deep Dive into Fusion Energy',
            description: 'A comprehensive look at fusion reactors.',
            publishedAt: '2025-01-15T10:00:00Z',
            channelId: 'chan456',
            channelTitle: 'Science Today',
            tags: ['fusion', 'energy', 'science'],
            thumbnails: { high: { url: 'https://img.youtube.com/vi/vid123/hqdefault.jpg' } },
          },
          contentDetails: {
            duration: 'PT8M24S',
          },
          statistics: {
            viewCount: '154200',
            likeCount: '8900',
            // commentCount omitted to test undefined distinction
          },
        },
      ],
    };

    globalThis.fetch = async (input: RequestInfo | URL) => {
      const urlStr = String(input);
      if (urlStr.includes('/search')) {
        return new Response(JSON.stringify(mockSearchResponse), { status: 200 });
      }
      if (urlStr.includes('/videos')) {
        return new Response(JSON.stringify(mockVideosResponse), { status: 200 });
      }
      return new Response('Not found', { status: 404 });
    };

    try {
      const provider = new YouTubeResearchProvider({ apiKey: 'AIzaSyTestValidFakeKey123' });
      const result = await provider.searchPublicVideos('fusion energy');

      assert.equal(result.videos.length, 1);
      const video: YouTubePublicVideoMetadata = result.videos[0];

      assert.equal(video.videoId, 'vid123');
      assert.equal(video.title, 'Deep Dive into Fusion Energy');
      assert.equal(video.channelTitle, 'Science Today');
      assert.equal(video.viewCount, 154200);
      assert.equal(video.likeCount, 8900);
      // Crucial: commentCount must be undefined, not 0 or NaN
      assert.equal(video.commentCount, undefined);
      assert.equal(video.durationIso, 'PT8M24S');
      assert.deepEqual(video.tags, ['fusion', 'energy', 'science']);
    } finally {
      globalThis.fetch = originalFetch;
    }
  });
});
