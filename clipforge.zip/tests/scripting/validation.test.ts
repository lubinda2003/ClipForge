import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { validateScriptArtifact } from '../../src/scripting/validator.ts';
import { ScriptArtifact } from '../../src/contracts/script.ts';

describe('Script Validator', () => {
  const validScript: ScriptArtifact = {
    title: 'Why Concorde Really Failed',
    topic: 'Concorde Supersonic Flight',
    format: 'short',
    totalWordCount: 85,
    estimatedTotalDurationSeconds: 34.0,
    segments: [
      {
        segmentId: 'seg_001',
        sectionIndex: 0,
        sectionName: 'Hook',
        narrationText: 'Concorde did not fail because tickets were expensive—it failed because of this single sound law.',
        estimatedDurationSeconds: 4.5,
        emphasisKeywords: ['Concorde', 'sound law'],
        visualIntentDescription: 'Dramatic takeoff archival footage.',
      },
      {
        segmentId: 'seg_002',
        sectionIndex: 1,
        sectionName: 'Mechanism',
        narrationText: 'In 1973, the FAA banned overland supersonic commercial flight due to sonic booms.',
        estimatedDurationSeconds: 14.5,
        emphasisKeywords: ['FAA', 'overland', 'sonic booms'],
        visualIntentDescription: 'Map animation showing flight routes restricted to ocean crossing.',
      },
      {
        segmentId: 'seg_003',
        sectionIndex: 2,
        sectionName: 'Payoff',
        narrationText: 'Until modern planes solve the acoustic boom, supersonic travel will remain an offshore luxury.',
        estimatedDurationSeconds: 15.0,
        emphasisKeywords: ['acoustic boom', 'offshore'],
        visualIntentDescription: 'Quiet supersonic NASA X-59 experimental aircraft b-roll.',
      },
    ],
  };

  it('passes a fully compliant script artifact', () => {
    const result = validateScriptArtifact(validScript);
    assert.equal(result.isValid, true);
    assert.equal(result.errors.length, 0);
  });

  it('rejects missing or empty title and topic', () => {
    const invalid = { ...validScript, title: '', topic: '   ' };
    const result = validateScriptArtifact(invalid);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.some(e => e.includes('title')));
    assert.ok(result.errors.some(e => e.includes('topic')));
  });

  it('rejects empty narrationText in a segment', () => {
    const invalid: ScriptArtifact = {
      ...validScript,
      segments: [
        validScript.segments[0],
        { ...validScript.segments[1], narrationText: '   ' },
      ],
    };
    const result = validateScriptArtifact(invalid);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.some(e => e.includes('narrationText')));
  });

  it('rejects duplicate segment IDs', () => {
    const invalid: ScriptArtifact = {
      ...validScript,
      segments: [
        validScript.segments[0],
        { ...validScript.segments[1], segmentId: 'seg_001' },
      ],
    };
    const result = validateScriptArtifact(invalid);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.some(e => e.includes('Duplicate segmentId')));
  });

  it('rejects invalid chapter startSegmentId in long-form scripts', () => {
    const invalidLong: ScriptArtifact = {
      ...validScript,
      format: 'long',
      chapters: [
        { chapterIndex: 0, title: 'Act 1', startSegmentId: 'non_existent_id' },
      ],
    };
    const result = validateScriptArtifact(invalidLong);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.some(e => e.includes('non-existent startSegmentId')));
  });

  it('warns when duration is artificially locked to 30s with few segments', () => {
    const clamped30s: ScriptArtifact = {
      ...validScript,
      estimatedTotalDurationSeconds: 30.0,
      segments: [
        validScript.segments[0],
        { ...validScript.segments[1], sectionName: 'Payoff' },
      ],
    };
    const result = validateScriptArtifact(clamped30s);
    assert.ok(result.warnings.some(w => w.includes('30s')));
  });
});
