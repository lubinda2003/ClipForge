import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { GeminiScriptProvider } from '../../src/scripting/gemini.ts';
import { validateScriptArtifact } from '../../src/scripting/validator.ts';
import { ResearchArtifact } from '../../src/contracts/research.ts';
import { ContentStrategyArtifact } from '../../src/contracts/strategy.ts';

describe('Scripting: Short-form vs Long-form', () => {
  const baseResearch: ResearchArtifact = {
    jobId: 'job_form_test',
    topic: 'Nuclear Fusion Breakthroughs',
    createdAt: new Date().toISOString(),
    formatTarget: 'short',
    observedData: {
      topic: 'Nuclear Fusion Breakthroughs',
      collectedAt: new Date().toISOString(),
      sources: [
        {
          type: 'web_search',
          url: 'https://example.com/fusion',
          title: 'Nuclear Fusion Milestone',
          snippet: 'Lawrence Livermore National Laboratory NIF ignition milestone.',
        },
      ],
      youtubePublicVideos: [],
      competitorTitles: ['Fusion Finally Works', 'The Truth About NIF'],
      commonQuestions: ['Did we achieve net energy gain?'],
      verifiableFacts: [
        {
          claim: 'NIF achieved Q > 1 in December 2022 using 192 laser beams.',
          source: 'Lawrence Livermore National Laboratory',
          confidence: 'high',
        },
      ],
    },
    inferredInsights: {
      audienceInterestLevel: 'viral_potential',
      saturationLevel: 'oversaturated',
      promisingContentAngles: ['Laser wall-plug efficiency vs target gain'],
      contentGapsIdentified: ['Engineering Q vs Scientific Q'],
      potentialHooks: ['They told you fusion achieved net energy. They left out the 300 megawatt catch.'],
      curiosityGaps: ['Why wall-plug efficiency is 100x lower than target gain'],
    },
  };

  const baseStrategy: ContentStrategyArtifact = {
    jobId: 'job_form_test',
    createdAt: new Date().toISOString(),
    topic: 'Nuclear Fusion Breakthroughs',
    format: 'short',
    targetAudience: {
      primarySegment: 'Science and tech enthusiasts',
      familiarityLevel: 'intermediate',
      primaryMotivation: 'Separate genuine physics breakthroughs from hype',
    },
    angle: {
      coreThesis: 'Scientific net energy gain is real, but commercial fusion requires solving engineering gain.',
      whyNow: 'Government laboratories recently repeated the ignition milestone.',
      contrarianOrUniquePerspective: 'The reaction produced 3 megajoules, but the facility drew 300 megajoules from the grid to fire.',
    },
    hook: {
      hookText: 'Scientists achieved net energy fusion, but they left out one giant catch.',
      hookType: 'curiosity_gap',
      visualCue: 'Target chamber laser array illumination.',
      durationTargetSeconds: 3.2,
    },
    titleConcepts: ['The 300 Megawatt Fusion Catch'],
    narrativeStructure: [
      { actOrSection: 'Hook', objective: 'Call out the grid power paradox', approxPercentageOfVideo: 20 },
      { actOrSection: 'The Contrast', objective: 'Explain Scientific Q vs Engineering Q', approxPercentageOfVideo: 50 },
      { actOrSection: 'Resolution', objective: 'Highlight magnet technology progress', approxPercentageOfVideo: 30 },
    ],
    emotionalTriggers: ['curiosity', 'illumination'],
    retentionPlan: [
      { timestampTargetSeconds: 0, mechanism: 'curiosity_loop_open', description: 'Introduce grid power discrepancy' },
      { timestampTargetSeconds: 22, mechanism: 'pattern_interrupt', description: 'Wall plug diagram' },
    ],
    callToAction: {
      type: 'comment_prompt',
      promptText: 'Do you think private fusion will beat ITER? Comment below.',
    },
    estimatedDurationRangeSeconds: {
      min: 40,
      max: 65,
      target: 50,
    },
  };

  it('generates short-form script with immediate hook and no 30s clamping', async () => {
    const provider = new GeminiScriptProvider({ apiKey: '' });
    const script = await provider.generateScript(baseResearch, baseStrategy, { format: 'short' });

    assert.equal(script.format, 'short');
    assert.ok(script.segments.length >= 3);
    assert.notEqual(script.estimatedTotalDurationSeconds, 30.0, 'Must not be artificially clamped to exactly 30s');
    assert.ok(script.estimatedTotalDurationSeconds > 15 && script.estimatedTotalDurationSeconds < 120);

    const validation = validateScriptArtifact(script);
    assert.ok(validation.isValid, `Validation errors: ${validation.errors.join(', ')}`);
  });

  it('generates long-form script with structured chapters and multi-act progression', async () => {
    const longResearch = { ...baseResearch, formatTarget: 'long' as const };
    const longStrategy = {
      ...baseStrategy,
      format: 'long' as const,
      estimatedDurationRangeSeconds: { min: 360, max: 600, target: 480 },
    };

    const provider = new GeminiScriptProvider({ apiKey: '' });
    const script = await provider.generateScript(longResearch, longStrategy, { format: 'long' });

    assert.equal(script.format, 'long');
    assert.ok(script.segments.length >= 4, 'Long form requires at least 4 segments');
    assert.ok(Array.isArray(script.chapters) && script.chapters.length >= 2, 'Long form requires chapters array');

    // Verify each chapter references a valid segmentId
    const segmentIds = new Set(script.segments.map(s => s.segmentId));
    for (const chapter of script.chapters!) {
      assert.ok(segmentIds.has(chapter.startSegmentId), `Chapter startSegmentId ${chapter.startSegmentId} must exist`);
      assert.ok(chapter.title.length > 0);
    }

    const validation = validateScriptArtifact(script);
    assert.ok(validation.isValid, `Validation errors: ${validation.errors.join(', ')}`);
  });
});
