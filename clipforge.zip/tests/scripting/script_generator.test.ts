import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { ScriptEngine } from '../../src/scripting/engine.ts';
import { GeminiScriptProvider } from '../../src/scripting/gemini.ts';
import { ResearchArtifact } from '../../src/contracts/research.ts';
import { ContentStrategyArtifact } from '../../src/contracts/strategy.ts';

describe('Script Generator', () => {
  const mockResearch: ResearchArtifact = {
    jobId: 'job_script_001',
    topic: 'Solid State Batteries',
    createdAt: new Date().toISOString(),
    formatTarget: 'short',
    observedData: {
      topic: 'Solid State Batteries',
      collectedAt: new Date().toISOString(),
      sources: [
        {
          type: 'web_search',
          url: 'https://example.com/battery-study',
          title: 'Solid State Battery Progress',
          snippet: 'Study on ceramic electrolytes and dendrite penetration.',
        },
      ],
      youtubePublicVideos: [],
      competitorTitles: ['Why Solid State Is Hard', 'The Battery Revolution'],
      commonQuestions: ['Why are solid state batteries not in cars yet?'],
      verifiableFacts: [
        {
          claim: 'Ceramic electrolytes can suffer dendrite penetration at current densities above 2 mA/cm2.',
          source: 'Nature Energy 2023',
          confidence: 'high',
        },
      ],
    },
    inferredInsights: {
      audienceInterestLevel: 'viral_potential',
      saturationLevel: 'moderate',
      promisingContentAngles: ['The dendrite bottleneck nobody talks about'],
      contentGapsIdentified: ['Visualizing ceramic separator micro-cracks'],
      potentialHooks: ['You were promised solid state batteries in 2025. Here is why that was impossible.'],
      curiosityGaps: ['Why ceramic dendrites grow under pressure'],
      claimsRequiringVerification: [
        {
          claim: 'Commercial automotive production may achieve cost parity by 2028.',
          reason: 'Industry projection from startup investor presentation.',
          verificationRequired: true,
        },
      ],
    },
  };

  const mockStrategy: ContentStrategyArtifact = {
    jobId: 'job_script_001',
    createdAt: new Date().toISOString(),
    topic: 'Solid State Batteries',
    format: 'short',
    targetAudience: {
      primarySegment: 'EV enthusiasts and tech skeptics',
      familiarityLevel: 'intermediate',
      primaryMotivation: 'Understand the engineering reason behind delay timelines',
    },
    angle: {
      coreThesis: 'The delay in solid-state batteries is not chemistry—it is mechanical pressure.',
      whyNow: 'Automakers have quietly moved targets back by three years.',
      contrarianOrUniquePerspective: 'Everyone focuses on fire safety, but dendrite pressure cracking is the true barrier.',
    },
    hook: {
      hookText: 'Automakers quietly pushed back their solid-state battery deadlines. This microscopic crack explains why.',
      hookType: 'curiosity_gap',
      visualCue: 'High-magnification SEM imaging showing ceramic dendrite fracture.',
      durationTargetSeconds: 3.5,
    },
    titleConcepts: ['The Hidden Solid State Bottleneck'],
    narrativeStructure: [
      { actOrSection: 'Hook', objective: 'Freeze scroll with delayed timeline', approxPercentageOfVideo: 20 },
      { actOrSection: 'The Mechanism', objective: 'Show ceramic dendrite fracture data', approxPercentageOfVideo: 50 },
      { actOrSection: 'Payoff', objective: 'Explain realistic 2028+ timeline', approxPercentageOfVideo: 30 },
    ],
    emotionalTriggers: ['curiosity', 'realism', 'discovery'],
    retentionPlan: [
      { timestampTargetSeconds: 0, mechanism: 'curiosity_loop_open', description: 'Open loop on delayed deadline' },
      { timestampTargetSeconds: 20, mechanism: 'pattern_interrupt', description: 'Visual zoom on dendrite micro-crack' },
    ],
    callToAction: {
      type: 'comment_prompt',
      promptText: 'Will solid state beat sodium-ion first? Tell me below.',
    },
    estimatedDurationRangeSeconds: {
      min: 40,
      max: 65,
      target: 52,
    },
  };

  it('generates structured script with segments, duration estimates, and factual attribution', async () => {
    const engine = new ScriptEngine({
      scriptProvider: new GeminiScriptProvider({ apiKey: '' }),
    });

    const script = await engine.executeScripting(mockResearch, mockStrategy, {
      format: 'short',
      jobId: 'job_script_001',
    });

    assert.equal(script.topic, 'Solid State Batteries');
    assert.equal(script.format, 'short');
    assert.ok(script.title);
    assert.ok(script.totalWordCount > 20);
    assert.ok(script.estimatedTotalDurationSeconds > 15);
    assert.ok(script.segments.length >= 3);

    // Opening segment contains hook
    const hookSegment = script.segments[0];
    assert.equal(hookSegment.sectionIndex, 0);
    assert.ok(hookSegment.narrationText.length > 10);
    assert.ok(hookSegment.visualIntentDescription.length > 5);

    // Evidence segment contains factual citation
    const evidenceSegment = script.segments.find(s => s.sourceReference);
    assert.ok(evidenceSegment, 'Script should retain source reference from research');
    assert.ok(evidenceSegment.sourceReference?.includes('Nature Energy'));

    // Segment with unverified claim is marked verificationRequired
    const unverifiedSegment = script.segments.find(s => s.verificationRequired === true);
    assert.ok(unverifiedSegment, 'Script should flag unverified claim');
    assert.ok(
      unverifiedSegment.narrationText.toLowerCase().includes('preliminary') ||
      unverifiedSegment.narrationText.toLowerCase().includes('reports') ||
      unverifiedSegment.narrationText.toLowerCase().includes('projections') ||
      unverifiedSegment.narrationText.toLowerCase().includes('verification'),
      'Unverified claim must be qualified in narration'
    );
  });
});
