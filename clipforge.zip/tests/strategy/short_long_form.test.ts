import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { ContentStrategyEngine } from '../../src/strategy/engine.ts';
import { GeminiStrategyProvider } from '../../src/strategy/gemini.ts';
import { ResearchArtifact } from '../../src/contracts/research.ts';

describe('Short-Form vs Long-Form Strategy Optimization', () => {
  const baseResearch: ResearchArtifact = {
    jobId: 'job_form_test',
    topic: 'Nuclear Micro-Reactors',
    createdAt: new Date().toISOString(),
    formatTarget: 'short',
    observedData: {
      topic: 'Nuclear Micro-Reactors',
      collectedAt: new Date().toISOString(),
      sources: [],
      youtubePublicVideos: [],
      competitorTitles: ['Nuclear Reactors in a Shipping Container'],
      commonQuestions: ['Are micro-reactors safe?', 'How much power do they make?'],
      verifiableFacts: [
        {
          claim: 'Micro-reactors produce between 1 and 20 megawatts of thermal energy.',
          source: 'US Department of Energy',
          confidence: 'high',
        },
      ],
    },
    inferredInsights: {
      audienceInterestLevel: 'broad',
      saturationLevel: 'underserved',
      promisingContentAngles: ['Powering remote communities and military bases'],
      contentGapsIdentified: ['Meltdown-proof fuel pellet architecture'],
      potentialHooks: ['This shipping container holds enough nuclear power to run a town for 10 years.'],
      curiosityGaps: ['Why TRISO fuel cannot melt even if cooling fails'],
    },
  };

  it('optimizes short-form strategy with fast hook, high density, and NO 30s fixed limit', async () => {
    const engine = new ContentStrategyEngine({
      geminiProvider: new GeminiStrategyProvider({ apiKey: '' }),
    });
    const shortStrategy = await engine.executeStrategy(baseResearch, { format: 'short' });

    assert.equal(shortStrategy.format, 'short');
    // Hook target should be rapid (<4.5s)
    assert.ok(shortStrategy.hook.durationTargetSeconds <= 4.5);

    // Explicitly verify NO 30-second hardcoded fixed duration
    assert.notEqual(shortStrategy.estimatedDurationRangeSeconds.min, 30);
    assert.notEqual(shortStrategy.estimatedDurationRangeSeconds.max, 30);
    assert.ok(shortStrategy.estimatedDurationRangeSeconds.min >= 35);
    assert.ok(shortStrategy.estimatedDurationRangeSeconds.max <= 90);
    assert.ok(shortStrategy.estimatedDurationRangeSeconds.target >= shortStrategy.estimatedDurationRangeSeconds.min);
  });

  it('optimizes long-form strategy with chaptered narrative and deep evidence acts', async () => {
    const engine = new ContentStrategyEngine({
      geminiProvider: new GeminiStrategyProvider({ apiKey: '' }),
    });
    const longStrategy = await engine.executeStrategy(baseResearch, { format: 'long' });

    assert.equal(longStrategy.format, 'long');
    // Narrative structure must contain deep chaptered breakdown (>= 4 sections)
    assert.ok(longStrategy.narrativeStructure.length >= 4);

    // Duration range for long form should reflect sustained multi-minute analysis
    assert.ok(longStrategy.estimatedDurationRangeSeconds.min >= 180);
    assert.ok(longStrategy.estimatedDurationRangeSeconds.max >= 360);
    assert.ok(longStrategy.estimatedDurationRangeSeconds.target >= longStrategy.estimatedDurationRangeSeconds.min);

    // Retention plan must contain pacing shifts or pattern interrupts for sustained watch time
    assert.ok(longStrategy.retentionPlan.some(m => m.mechanism === 'pacing_shift' || m.mechanism === 'pattern_interrupt'));
  });
});
