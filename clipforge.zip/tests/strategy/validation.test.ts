import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { validateStrategyArtifact } from '../../src/strategy/validator.ts';
import { ContentStrategyArtifact } from '../../src/contracts/strategy.ts';

describe('Strategy Artifact Validation', () => {
  const validStrategy: ContentStrategyArtifact = {
    topic: 'Asteroid Mining Economics',
    format: 'short',
    targetAudience: {
      primarySegment: 'Space technology enthusiasts',
      familiarityLevel: 'intermediate',
      primaryMotivation: 'Understanding economic feasibility',
    },
    angle: {
      coreThesis: 'The value of asteroid mining is not bringing metals back to Earth, but building in orbit.',
      whyNow: 'Starship payload costs make orbital industry viable.',
      contrarianOrUniquePerspective: 'Importing platinum to Earth would crash the market, destroying the business model.',
    },
    hook: {
      hookText: 'Bringing a quadrillion-dollar asteroid to Earth would make everyone poorer, not richer.',
      hookType: 'shocking_stat',
      visualCue: 'Asteroid entering orbit over Earth with commodity price crash tickers.',
      durationTargetSeconds: 3.2,
    },
    titleConcepts: ['The Trillion Dollar Space Trap', 'Why Asteroid Mining is a Lie'],
    narrativeStructure: [
      { actOrSection: 'Hook & The Platinum Paradox', objective: 'Freeze attention', approxPercentageOfVideo: 20 },
      { actOrSection: 'The Supply Shock Problem', objective: 'Explain price elasticity', approxPercentageOfVideo: 40 },
      { actOrSection: 'The Real Orbital Economy', objective: 'Deliver the pivot', approxPercentageOfVideo: 40 },
    ],
    emotionalTriggers: ['curiosity', 'mind-blown'],
    retentionPlan: [
      { mechanism: 'curiosity_loop_open', description: 'Introduce the paradox at 0s' },
      { mechanism: 'pattern_interrupt', description: 'Visual audio glitch at 25s' },
    ],
    estimatedDurationRangeSeconds: {
      min: 45,
      max: 70,
      target: 55,
    },
  };

  it('passes a fully conforming strategy artifact', () => {
    const result = validateStrategyArtifact(validStrategy);
    assert.equal(result.isValid, true);
    assert.equal(result.errors.length, 0);
  });

  it('rejects strategies with missing hook text or negative duration', () => {
    const brokenStrategy: ContentStrategyArtifact = {
      ...validStrategy,
      hook: {
        ...validStrategy.hook,
        hookText: '',
        durationTargetSeconds: -5,
      },
    };

    const result = validateStrategyArtifact(brokenStrategy);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.some(e => e.includes('Hook text is required')));
    assert.ok(result.errors.some(e => e.includes('durationTargetSeconds must be a positive number')));
  });

  it('rejects invalid duration ranges where max is less than min', () => {
    const invertedDuration: ContentStrategyArtifact = {
      ...validStrategy,
      estimatedDurationRangeSeconds: {
        min: 60,
        max: 30,
        target: 45,
      },
    };

    const result = validateStrategyArtifact(invertedDuration);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.some(e => e.includes('cannot be less than minimum')));
  });

  it('warns when duration is artificially fixed to exactly 30s', () => {
    const fixed30s: ContentStrategyArtifact = {
      ...validStrategy,
      estimatedDurationRangeSeconds: {
        min: 30,
        max: 30,
        target: 30,
      },
    };

    const result = validateStrategyArtifact(fixed30s);
    assert.ok(result.warnings.some(w => w.includes('fixed to exactly 30s')));
  });
});
