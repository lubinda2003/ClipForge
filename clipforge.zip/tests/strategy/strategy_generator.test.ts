import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { ContentStrategyEngine } from '../../src/strategy/engine.ts';
import { GeminiStrategyProvider } from '../../src/strategy/gemini.ts';
import { ResearchArtifact } from '../../src/contracts/research.ts';
import { IGeminiStrategyProvider } from '../../src/strategy/interfaces.ts';
import { ContentStrategyArtifact } from '../../src/contracts/strategy.ts';

describe('Content Strategy Generator', () => {
  const mockResearchArtifact: ResearchArtifact = {
    jobId: 'job_test_001',
    topic: 'Supersonic Commercial Flight',
    createdAt: new Date().toISOString(),
    formatTarget: 'short',
    observedData: {
      topic: 'Supersonic Commercial Flight',
      collectedAt: new Date().toISOString(),
      sources: [],
      youtubePublicVideos: [],
      competitorTitles: ['Why Concorde Failed', 'The Return of Supersonic'],
      commonQuestions: ['Why did Concorde stop flying?', 'When is supersonic coming back?'],
      verifiableFacts: [
        {
          claim: 'Concorde retired from commercial service in 2003.',
          source: 'Aviation History Database',
          confidence: 'high',
        },
      ],
    },
    inferredInsights: {
      audienceInterestLevel: 'viral_potential',
      saturationLevel: 'moderate',
      promisingContentAngles: ['The acoustic sonic boom loophole'],
      contentGapsIdentified: ['Explaining how modern airframes mitigate sonic thump'],
      potentialHooks: ['Concorde did not fail because of speed—it failed because of this single sound rule.'],
      curiosityGaps: ['Why overland flight bans killed supersonic travel'],
    },
  };

  it('generates concrete, actionable content strategy from research artifact', async () => {
    const engine = new ContentStrategyEngine({
      geminiProvider: new GeminiStrategyProvider({ apiKey: '' }),
    });
    const strategy = await engine.executeStrategy(mockResearchArtifact, {
      format: 'short',
      jobId: 'job_test_001',
    });

    assert.equal(strategy.topic, 'Supersonic Commercial Flight');
    assert.equal(strategy.format, 'short');
    assert.ok(strategy.hook);
    assert.ok(strategy.hook.hookText.length > 10);
    assert.ok(strategy.hook.durationTargetSeconds > 0);
    assert.ok(strategy.angle.coreThesis);
    assert.ok(strategy.angle.contrarianOrUniquePerspective);
    assert.ok(strategy.titleConcepts.length >= 2);
    assert.ok(strategy.narrativeStructure.length >= 3);
    assert.ok(strategy.retentionPlan.length >= 2);

    // Duration range must be non-zero and flexible
    assert.ok(strategy.estimatedDurationRangeSeconds.min > 0);
    assert.ok(strategy.estimatedDurationRangeSeconds.max >= strategy.estimatedDurationRangeSeconds.min);
    assert.ok(strategy.estimatedDurationRangeSeconds.target >= strategy.estimatedDurationRangeSeconds.min);
  });
});
