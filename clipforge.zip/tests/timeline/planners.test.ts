import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { SafeZonePlanner } from '../../src/timeline/safe_zone_planner.ts';
import { DuckingPlanner } from '../../src/timeline/ducking_planner.ts';
import { MusicPlanner } from '../../src/timeline/music_planner.ts';
import { SfxPlanner } from '../../src/timeline/sfx_planner.ts';
import { CaptionPlanner } from '../../src/timeline/caption_planner.ts';
import { TransitionPlanner } from '../../src/timeline/transition_planner.ts';
import { MotionPlanner } from '../../src/timeline/motion_planner.ts';
import { RetentionEditingPlanner } from '../../src/timeline/retention_planner.ts';

import { ScriptArtifact } from '../../src/contracts/script.ts';
import { NarrationArtifact } from '../../src/contracts/narration.ts';
import { ScenesArtifact } from '../../src/contracts/scenes.ts';
import { SelectedAudioAsset } from '../../src/contracts/assets.ts';
import { DEFAULT_CURATED_AUDIO_CATALOG } from '../../src/assets/catalog.ts';

describe('Timeline Planners Unit Tests', () => {
  it('SafeZonePlanner should provide compliant boundaries for short and long formats', () => {
    const shortZone = SafeZonePlanner.getSafeZone('short');
    assert.strictEqual(shortZone.topPercent, 15);
    assert.strictEqual(shortZone.bottomPercent, 20);
    assert.strictEqual(shortZone.rightPercent, 18);
    assert.strictEqual(shortZone.leftPercent, 8);

    const longZone = SafeZonePlanner.getSafeZone('long');
    assert.strictEqual(longZone.topPercent, 8);
    assert.strictEqual(longZone.bottomPercent, 10);

    const heroPos = SafeZonePlanner.getPositioningForVariant('hero_hook', 'short');
    assert.strictEqual(heroPos.horizontalAlign, 'center');
    assert.strictEqual(heroPos.verticalAlign, 'center');

    const captionPos = SafeZonePlanner.getPositioningForVariant('bold_caption', 'short');
    assert.strictEqual(captionPos.verticalAlign, 'bottom');
  });

  it('DuckingPlanner should calculate smooth volume envelopes and bridge small speech gaps', () => {
    const planner = new DuckingPlanner({
      duckedMultiplier: 0.15,
      bridgeGapSeconds: 0.4,
    });

    const speechIntervals = [
      { startSeconds: 1.0, endSeconds: 3.5 },
      { startSeconds: 3.7, endSeconds: 6.0 }, // gap is 0.2s (< 0.4s), should be bridged!
      { startSeconds: 8.5, endSeconds: 11.0 }, // gap is 2.5s (> 0.4s), should un-duck
    ];

    const envelope = planner.generateMusicDuckingEnvelope(speechIntervals, 15.0);
    assert.ok(envelope.length > 2);

    // Initial volume should be 1.0
    assert.strictEqual(envelope[0].volumeMultiplier, 1.0);

    // During bridged interval (e.g. t=2.0 or t=3.6), volume should be ducked (0.15)
    const midSpeechPt = envelope.find(p => p.timestampSeconds >= 1.0 && p.timestampSeconds <= 6.0 && p.volumeMultiplier === 0.15);
    assert.ok(midSpeechPt, 'Speech interval should have ducked volume');

    // SFX volume calculation: reduced when overlapping speech
    const sfxVolDuringSpeech = planner.calculateSfxVolume(2.0, 0.4, speechIntervals);
    const sfxVolDuringSilence = planner.calculateSfxVolume(7.5, 0.4, speechIntervals);
    assert.ok(sfxVolDuringSpeech < sfxVolDuringSilence);
    assert.strictEqual(sfxVolDuringSilence, 0.4);
  });

  it('MusicPlanner should plan music clips with ducking and looping', () => {
    const musicTrack: SelectedAudioAsset = {
      purpose: 'background_music',
      asset: DEFAULT_CURATED_AUDIO_CATALOG.find(a => a.type === 'music')!,
      localPath: 'assets/music/cinematic/epic_build_01.mp3',
      targetTimestampSeconds: 0,
      targetDurationSeconds: 45,
      volumeLevel: 0.18,
      fadeInSeconds: 0.5,
      fadeOutSeconds: 1.5,
      score: 95,
      loopCount: 1,
    };

    const planner = new MusicPlanner();
    const clips = planner.planMusicClips(musicTrack, {
      format: 'short',
      totalDurationSeconds: 45,
      speechIntervals: [{ startSeconds: 0.5, endSeconds: 42.0 }],
    });

    assert.strictEqual(clips.length, 1);
    const clip = clips[0];
    assert.strictEqual(clip.type, 'music');
    assert.strictEqual(clip.volume, 0.18);
    assert.strictEqual(clip.durationSeconds, 45);
    assert.ok(clip.duckingEnvelope && clip.duckingEnvelope.length > 0);
  });

  it('CaptionPlanner should generate narration-synchronized text overlays with safe zone positioning', () => {
    const mockScript: ScriptArtifact = {
      jobId: 'job_test_cap',
      topic: 'Space Exploration',
      title: 'Voyage Beyond Mars',
      format: 'short',
      totalWordCount: 30,
      estimatedTotalDurationSeconds: 10,
      segments: [
        {
          segmentId: 'seg_01',
          sectionIndex: 0,
          sectionName: 'Hook',
          narrationText: 'Humans are finally heading to deep space.',
          estimatedDurationSeconds: 4.0,
          emphasisKeywords: ['deep space'],
          visualIntentDescription: 'Starship launch',
        },
        {
          segmentId: 'seg_02',
          sectionIndex: 1,
          sectionName: 'Data',
          narrationText: 'Over 140 million miles of radiation-filled void.',
          estimatedDurationSeconds: 5.5,
          emphasisKeywords: ['140 million miles'],
          visualIntentDescription: 'Planet Mars visual',
        },
      ],
    };

    const mockNarration: NarrationArtifact = {
      jobId: 'job_test_cap',
      createdAt: new Date().toISOString(),
      engine: 'mock',
      modelOrVoice: 'en_US-lessac-medium',
      totalDurationSeconds: 9.8,
      segmentResults: [
        {
          segmentId: 'seg_01',
          audioFilePath: 'audio/seg_01.wav',
          actualDurationSeconds: 4.2,
          audioFormat: 'wav',
          sampleRateHz: 24000,
          channels: 1,
        },
        {
          segmentId: 'seg_02',
          audioFilePath: 'audio/seg_02.wav',
          actualDurationSeconds: 5.6,
          audioFormat: 'wav',
          sampleRateHz: 24000,
          channels: 1,
        },
      ],
    };

    const planner = new CaptionPlanner();
    const captions = planner.planCaptions(mockScript, mockNarration, 'short');

    assert.strictEqual(captions.length, 2);
    // Segment 1: Hook -> hero_hook
    assert.strictEqual(captions[0].styleVariant, 'hero_hook');
    assert.strictEqual(captions[0].durationSeconds, 4.2);
    assert.strictEqual(captions[0].startTimelineSeconds, 0);
    assert.deepStrictEqual(captions[0].highlightWords, ['deep space']);

    // Segment 2: Contains statistic "140 million" -> statistic_card
    assert.strictEqual(captions[1].styleVariant, 'statistic_card');
    assert.strictEqual(captions[1].durationSeconds, 5.6);
    assert.strictEqual(captions[1].startTimelineSeconds, 4.2);
  });

  it('RetentionEditingPlanner should establish hook, pattern interrupts, and payoff', () => {
    const mockScenes: ScenesArtifact = {
      jobId: 'job_retention_test',
      createdAt: new Date().toISOString(),
      format: 'short',
      totalScenes: 4,
      totalDurationSeconds: 24,
      scenes: [
        {
          sceneId: 'sc_01',
          correspondingSegmentId: 'seg_01',
          sequenceOrder: 1,
          searchKeywords: ['rocket'],
          preferredVisualType: 'realistic_video',
          targetAspectRatio: '9:16',
          format: 'short',
          visualMood: 'energetic',
          allowCropping: true,
          desiredDurationSeconds: 4.0,
          visualConcept: 'Rocket launch',
          visualPurpose: 'establish_hook',
          narrationExcerpt: 'Watch this closely.',
        },
        {
          sceneId: 'sc_02',
          correspondingSegmentId: 'seg_02',
          sequenceOrder: 2,
          searchKeywords: ['engine'],
          preferredVisualType: 'realistic_video',
          targetAspectRatio: '9:16',
          format: 'short',
          visualMood: 'tense',
          allowCropping: true,
          desiredDurationSeconds: 8.0,
          visualConcept: 'Telemetry screen',
          visualPurpose: 'provide_pattern_interrupt',
          narrationExcerpt: 'Over 99.9% of engines fail this test.',
        },
        {
          sceneId: 'sc_03',
          correspondingSegmentId: 'seg_03',
          sequenceOrder: 3,
          searchKeywords: ['innovation'],
          preferredVisualType: 'realistic_video',
          targetAspectRatio: '9:16',
          format: 'short',
          visualMood: 'inspiring',
          allowCropping: true,
          desiredDurationSeconds: 6.0,
          visualConcept: 'Engine firing',
          visualPurpose: 'explain_core_mechanism',
          narrationExcerpt: 'Until this innovation.',
        },
        {
          sceneId: 'sc_04',
          correspondingSegmentId: 'seg_04',
          sequenceOrder: 4,
          searchKeywords: ['orbit'],
          preferredVisualType: 'realistic_video',
          targetAspectRatio: '9:16',
          format: 'short',
          visualMood: 'inspiring',
          allowCropping: true,
          desiredDurationSeconds: 6.0,
          visualConcept: 'Orbit view',
          visualPurpose: 'deliver_resolution',
          narrationExcerpt: 'Now we are going to Mars.',
        },
      ],
    };

    const mockScript: any = { segments: [{ visualIntentDescription: 'Hook visual' }] };
    const mockNarration: any = { totalDurationSeconds: 24, segmentResults: [] };

    const planner = new RetentionEditingPlanner();
    const result = planner.planRetentionEvents(mockScenes, mockScript, mockNarration, 'short');

    assert.ok(result.annotations.some(a => a.event === 'hook'));
    assert.ok(result.annotations.some(a => a.event === 'pattern_interrupt'));
    assert.ok(result.annotations.some(a => a.event === 'payoff'));
    assert.ok(result.sfxLandmarks.some(l => l.purpose === 'hook'));
    assert.ok(result.sfxLandmarks.some(l => l.purpose === 'statistic_reveal'));
  });
});
