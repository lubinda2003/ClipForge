import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { TimelineValidator } from '../../src/timeline/validator.ts';
import { TimelineArtifact } from '../../src/contracts/timeline.ts';

describe('Timeline Validator', () => {
  const validTimeline: TimelineArtifact = {
    jobId: 'job_val_001',
    createdAt: new Date().toISOString(),
    format: 'short',
    aspectRatio: '9:16',
    totalDurationSeconds: 15.0,
    tracks: {
      video: [
        {
          elementId: 'v1',
          sceneId: 'sc1',
          sourceFilePath: 'stock/clip_1.mp4',
          sourceTrimStartSeconds: 0,
          startTimelineSeconds: 0,
          durationSeconds: 7.5,
          cropOrScale: { scaleMode: 'smart_center_crop', aspectRatio: '9:16' },
          motionEffect: 'ken_burns_zoom_in',
        },
        {
          elementId: 'v2',
          sceneId: 'sc2',
          sourceFilePath: 'stock/clip_2.mp4',
          sourceTrimStartSeconds: 0,
          startTimelineSeconds: 7.5,
          durationSeconds: 7.5,
          cropOrScale: { scaleMode: 'smart_center_crop', aspectRatio: '9:16' },
          motionEffect: 'ken_burns_zoom_out',
        },
      ],
      narration: [
        {
          elementId: 'n1',
          segmentId: 'seg1',
          audioFilePath: 'audio/seg1.wav',
          startTimelineSeconds: 0,
          durationSeconds: 15.0,
          volume: 1.0,
        },
      ],
      music: [
        {
          elementId: 'm1',
          type: 'music',
          audioFilePath: 'assets/music/track.mp3',
          startTimelineSeconds: 0,
          durationSeconds: 15.0,
          volume: 0.18,
          duckingEnvelope: [
            { timestampSeconds: 0, volumeMultiplier: 1.0 },
            { timestampSeconds: 0.5, volumeMultiplier: 0.15 },
            { timestampSeconds: 14.5, volumeMultiplier: 0.15 },
            { timestampSeconds: 15.0, volumeMultiplier: 1.0 },
          ],
        },
      ],
      sfx: [
        {
          elementId: 's1',
          type: 'sfx',
          audioFilePath: 'assets/sfx/whoosh.wav',
          startTimelineSeconds: 0.2,
          durationSeconds: 1.0,
          volume: 0.4,
        },
      ],
      textOverlays: [
        {
          elementId: 't1',
          primaryText: 'Hook Text',
          styleVariant: 'hero_hook',
          startTimelineSeconds: 0,
          durationSeconds: 5.0,
          positioning: {
            horizontalAlign: 'center',
            verticalAlign: 'center',
            safeZoneMargins: { topPercent: 15, bottomPercent: 20, leftPercent: 8, rightPercent: 18 },
          },
        },
      ],
    },
    safeZone: { topPercent: 15, bottomPercent: 20, leftPercent: 8, rightPercent: 18 },
    retentionAnnotations: [
      {
        timestampSeconds: 0,
        event: 'hook',
        description: 'Initial strong hook event',
      },
    ],
  };

  it('should accept a valid TimelineArtifact without errors', () => {
    const result = TimelineValidator.validate(validTimeline);
    assert.strictEqual(result.valid, true);
    assert.strictEqual(result.issues.length, 0);
  });

  it('should reject format and aspect ratio mismatch', () => {
    const invalid = { ...validTimeline, format: 'short' as const, aspectRatio: '16:9' as const };
    const result = TimelineValidator.validate(invalid);
    assert.strictEqual(result.valid, false);
    assert.ok(result.issues.some(i => i.field === 'aspectRatio'));
  });

  it('should reject video track discontinuity', () => {
    const brokenVideo = JSON.parse(JSON.stringify(validTimeline));
    brokenVideo.tracks.video[1].startTimelineSeconds = 10.0; // gap from 7.5 to 10.0!
    const result = TimelineValidator.validate(brokenVideo);
    assert.strictEqual(result.valid, false);
    assert.ok(result.issues.some(i => i.field === 'startTimelineSeconds'));
  });

  it('should reject out-of-bounds ducking envelope timestamps or volume multipliers', () => {
    const badDucking = JSON.parse(JSON.stringify(validTimeline));
    badDucking.tracks.music[0].duckingEnvelope.push({
      timestampSeconds: 50.0, // beyond totalDurationSeconds 15.0!
      volumeMultiplier: 2.5, // > 1.0!
    });
    const result = TimelineValidator.validate(badDucking);
    assert.strictEqual(result.valid, false);
    assert.ok(result.issues.some(i => i.field === 'duckingEnvelope.timestampSeconds'));
    assert.ok(result.issues.some(i => i.field === 'duckingEnvelope.volumeMultiplier'));
  });

  it('should reject invalid safe zone margins', () => {
    const badMargins = JSON.parse(JSON.stringify(validTimeline));
    badMargins.tracks.textOverlays[0].positioning.safeZoneMargins.topPercent = 60;
    badMargins.tracks.textOverlays[0].positioning.safeZoneMargins.bottomPercent = 50; // sum 110% >= 100%!
    const result = TimelineValidator.validate(badMargins);
    assert.strictEqual(result.valid, false);
    assert.ok(result.issues.some(i => i.field === 'safeZoneMargins'));
  });
});
