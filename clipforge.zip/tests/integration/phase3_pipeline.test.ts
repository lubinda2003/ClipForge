import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { ResearchEngine } from '../../src/research/engine.ts';
import { GeminiResearchProvider } from '../../src/research/gemini.ts';
import { ContentStrategyEngine } from '../../src/strategy/engine.ts';
import { GeminiStrategyProvider } from '../../src/strategy/gemini.ts';
import { ScriptEngine } from '../../src/scripting/engine.ts';
import { GeminiScriptProvider } from '../../src/scripting/gemini.ts';
import { NarrationEngine } from '../../src/narration/engine.ts';
import { PiperNarrationProvider } from '../../src/narration/piper.ts';
import { LocalStorageProvider } from '../../src/storage/local.ts';
import { CacheManager } from '../../src/storage/cache.ts';
import { runCli } from '../../src/cli/index.ts';

describe('Phase 3 Pipeline Integration (Script + Narration)', () => {
  const testBaseDir = path.resolve('./.cache/test_integration_phase3');
  let storage: LocalStorageProvider;
  let cache: CacheManager;

  beforeEach(() => {
    if (fs.existsSync(testBaseDir)) {
      fs.rmSync(testBaseDir, { recursive: true, force: true });
    }
    storage = new LocalStorageProvider(testBaseDir);
    cache = new CacheManager(storage);
  });

  afterEach(() => {
    if (fs.existsSync(testBaseDir)) {
      fs.rmSync(testBaseDir, { recursive: true, force: true });
    }
  });

  it('runs complete Research -> Strategy -> Script -> Narration pipeline', async () => {
    const researchEngine = new ResearchEngine({
      storage,
      cache,
      geminiProvider: new GeminiResearchProvider({ apiKey: '' }),
    });

    const strategyEngine = new ContentStrategyEngine({
      storage,
      cache,
      geminiProvider: new GeminiStrategyProvider({ apiKey: '' }),
    });

    const scriptEngine = new ScriptEngine({
      storage,
      cache,
      scriptProvider: new GeminiScriptProvider({ apiKey: '' }),
    });

    const narrationEngine = new NarrationEngine({
      storage,
      cache,
      provider: new PiperNarrationProvider({ mockMode: true, cache }),
    });

    const topic = 'Quantum Computing Qubits';
    const jobId = 'job_phase3_int_001';

    // 1. Research
    const research = await researchEngine.executeResearch(topic, { jobId, format: 'short' });
    assert.equal(research.topic, topic);
    assert.ok(await storage.exists('inputs', `jobs/${jobId}/research.json`));

    // 2. Strategy
    const strategy = await strategyEngine.executeStrategy(research, { jobId, format: 'short' });
    assert.equal(strategy.topic, topic);
    assert.ok(await storage.exists('inputs', `jobs/${jobId}/strategy.json`));

    // 3. Scripting
    const script = await scriptEngine.executeScripting(research, strategy, { jobId, format: 'short' });
    assert.equal(script.topic, topic);
    assert.ok(script.segments.length >= 3);
    assert.ok(await storage.exists('inputs', `jobs/${jobId}/script.json`));

    // 4. Narration
    const narration = await narrationEngine.executeNarration(script, { jobId });
    assert.equal(narration.jobId, jobId);
    assert.equal(narration.segmentResults.length, script.segments.length);
    assert.ok(narration.totalDurationSeconds > 0);
    assert.ok(await storage.exists('inputs', `jobs/${jobId}/narration.json`));

    // Verify each generated WAV file
    for (const seg of narration.segmentResults) {
      assert.ok(fs.existsSync(seg.audioFilePath));
      assert.ok(seg.actualDurationSeconds > 0);
    }
  });

  it('CLI executes pipeline command end-to-end in offline mode', async () => {
    const exitCode = await runCli([
      'pipeline',
      '--topic', 'Superconductor Leaps',
      '--format', 'short',
      '--cache-dir', testBaseDir,
      '--offline',
    ]);

    assert.equal(exitCode, 0);
  });
});
