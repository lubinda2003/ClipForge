import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

import { TimelineEngine } from '../../src/timeline/engine.ts';
import { AudioAssetLibrary } from '../../src/assets/library.ts';
import { LocalStorageProvider } from '../../src/storage/local.ts';
import { runCli } from '../../src/cli/index.ts';

import { ScenesArtifact } from '../../src/contracts/scenes.ts';
import { BrollSelectionArtifact } from '../../src/contracts/stock.ts';
import { NarrationArtifact } from '../../src/contracts/narration.ts';
import { ScriptArtifact } from '../../src/contracts/script.ts';
import { ContentStrategyArtifact } from '../../src/contracts/strategy.ts';

describe('Phase 5 End-to-End Timeline & Asset Selection Integration', () => {
  const testJobId = 'job_test_phase5_e2e';
  const testDir = './.cache/clipforge';
  const storage = new LocalStorageProvider(testDir);

  const mockScript: ScriptArtifact = {
    jobId: testJobId,
    topic: 'Nuclear Fusion Breakthrough',
    title: 'The Day Fusion Changed Everything',
    format: 'short',
    totalWordCount: 45,
    estimatedTotalDurationSeconds: 16.0,
    segments: [
      {
        segmentId: 'seg_01',
        sectionIndex: 0,
        sectionName: 'Hook',
        narrationText: 'For seventy years, nuclear fusion was always thirty years away.',
        estimatedDurationSeconds: 5.0,
        emphasisKeywords: ['nuclear fusion', 'thirty years'],
        visualIntentDescription: 'Glowing tokamak magnetic plasma reactor',
      },
      {
        segmentId: 'seg_02',
        sectionIndex: 1,
        sectionName: 'Breakthrough',
        narrationText: 'Until magnetic containment reached 100 million degrees Celsius.',
        estimatedDurationSeconds: 5.5,
        emphasisKeywords: ['100 million degrees'],
        visualIntentDescription: 'Superheated laser confinement simulation',
      },
      {
        segmentId: 'seg_03',
        sectionIndex: 2,
        sectionName: 'Resolution',
        narrationText: 'Generating infinite clean energy for the first time in human history.',
        estimatedDurationSeconds: 5.5,
        emphasisKeywords: ['infinite clean energy'],
        visualIntentDescription: 'Futuristic clean city grid powered by fusion',
      },
    ],
  };

  const mockNarration: NarrationArtifact = {
    jobId: testJobId,
    createdAt: new Date().toISOString(),
    engine: 'mock',
    modelOrVoice: 'en_US-lessac-medium',
    totalDurationSeconds: 16.2,
    segmentResults: [
      {
        segmentId: 'seg_01',
        audioFilePath: 'audio/seg_01.wav',
        actualDurationSeconds: 5.2,
        audioFormat: 'wav',
        sampleRateHz: 24000,
        channels: 1,
      },
      {
        segmentId: 'seg_02',
        audioFilePath: 'audio/seg_02.wav',
        actualDurationSeconds: 5.4,
        audioFormat: 'wav',
        sampleRateHz: 24000,
        channels: 1,
      },
      {
        segmentId: 'seg_03',
        audioFilePath: 'audio/seg_03.wav',
        actualDurationSeconds: 5.6,
        audioFormat: 'wav',
        sampleRateHz: 24000,
        channels: 1,
      },
    ],
  };

  const mockScenes: ScenesArtifact = {
    jobId: testJobId,
    createdAt: new Date().toISOString(),
    format: 'short',
    totalScenes: 3,
    totalDurationSeconds: 16.2,
    scenes: [
      {
        sceneId: 'sc_01',
        correspondingSegmentId: 'seg_01',
        sequenceOrder: 1,
        searchKeywords: ['nuclear', 'fusion', 'tokamak'],
        preferredVisualType: 'realistic_video',
        targetAspectRatio: '9:16',
        format: 'short',
        visualMood: 'energetic',
        allowCropping: true,
        desiredDurationSeconds: 5.2,
        visualConcept: 'Tokamak fusion reactor core',
        visualPurpose: 'establish_hook',
        narrationExcerpt: 'For seventy years, nuclear fusion was always thirty years away.',
      },
      {
        sceneId: 'sc_02',
        correspondingSegmentId: 'seg_02',
        sequenceOrder: 2,
        searchKeywords: ['plasma', 'lasers', 'containment'],
        preferredVisualType: 'realistic_video',
        targetAspectRatio: '9:16',
        format: 'short',
        visualMood: 'tense',
        allowCropping: true,
        desiredDurationSeconds: 5.4,
        visualConcept: 'Plasma lasers heating containment chamber',
        visualPurpose: 'provide_pattern_interrupt',
        narrationExcerpt: 'Until magnetic containment reached 100 million degrees Celsius.',
      },
      {
        sceneId: 'sc_03',
        correspondingSegmentId: 'seg_03',
        sequenceOrder: 3,
        searchKeywords: ['clean energy', 'city', 'future'],
        preferredVisualType: 'realistic_video',
        targetAspectRatio: '9:16',
        format: 'short',
        visualMood: 'inspiring',
        allowCropping: true,
        desiredDurationSeconds: 5.6,
        visualConcept: 'Modern clean skyline at sunrise',
        visualPurpose: 'deliver_resolution',
        narrationExcerpt: 'Generating infinite clean energy for the first time in human history.',
      },
    ],
  };

  const mockBroll: BrollSelectionArtifact = {
    jobId: testJobId,
    createdAt: new Date().toISOString(),
    format: 'short',
    totalScenes: 3,
    selections: [
      {
        sceneId: 'sc_01',
        selectedCandidate: {
          candidateId: 'cand_01',
          source: 'local_cache',
          sourceId: 'tokamak_01',
          tags: ['nuclear', 'fusion'],
          durationSeconds: 10,
          previewUrl: 'https://example.com/tokamak.mp4',
          downloadUrl: 'https://example.com/tokamak.mp4',
          resolution: { width: 1080, height: 1920 },
          originalAspectRatio: '9:16',
          files: [],
          license: 'CC0',
          relevanceScore: 0.95,
        },
        selectedFile: {
          fileId: 'f1',
          url: 'stock/tokamak.mp4',
          width: 1080,
          height: 1920,
          aspectRatio: '9:16',
          fileType: 'mp4',
        },
        downloadedLocalPath: 'stock/tokamak.mp4',
        trimStartSeconds: 0,
        trimDurationSeconds: 5.2,
        appliedTransform: 'native',
      },
      {
        sceneId: 'sc_02',
        selectedCandidate: {
          candidateId: 'cand_02',
          source: 'local_cache',
          sourceId: 'plasma_02',
          tags: ['plasma', 'lasers'],
          durationSeconds: 8,
          previewUrl: 'https://example.com/plasma.mp4',
          downloadUrl: 'https://example.com/plasma.mp4',
          resolution: { width: 1920, height: 1080 },
          originalAspectRatio: '16:9',
          files: [],
          license: 'CC0',
          relevanceScore: 0.91,
        },
        selectedFile: {
          fileId: 'f2',
          url: 'stock/plasma.mp4',
          width: 1920,
          height: 1080,
          aspectRatio: '16:9',
          fileType: 'mp4',
        },
        downloadedLocalPath: 'stock/plasma.mp4',
        trimStartSeconds: 1.0,
        trimDurationSeconds: 5.4,
        appliedTransform: 'center_crop',
      },
      {
        sceneId: 'sc_03',
        selectedCandidate: {
          candidateId: 'cand_03',
          source: 'local_cache',
          sourceId: 'city_03',
          tags: ['clean', 'city'],
          durationSeconds: 12,
          previewUrl: 'https://example.com/city.mp4',
          downloadUrl: 'https://example.com/city.mp4',
          resolution: { width: 1080, height: 1920 },
          originalAspectRatio: '9:16',
          files: [],
          license: 'CC0',
          relevanceScore: 0.88,
        },
        selectedFile: {
          fileId: 'f3',
          url: 'stock/city.mp4',
          width: 1080,
          height: 1920,
          aspectRatio: '9:16',
          fileType: 'mp4',
        },
        downloadedLocalPath: 'stock/city.mp4',
        trimStartSeconds: 0,
        trimDurationSeconds: 5.6,
        appliedTransform: 'native',
      },
    ],
    cacheStats: { cacheHits: 3, apiQueries: 3, bytesDownloaded: 1048576 },
  };

  it('should execute timeline composition and persist valid timeline and assets artifacts', async () => {
    const engine = new TimelineEngine({ storage });

    const { timeline, assets } = await engine.executeTimelineComposition(
      mockScenes,
      mockBroll,
      mockNarration,
      mockScript,
      undefined,
      { jobId: testJobId, format: 'short', topic: 'Nuclear Fusion Breakthrough' }
    );

    assert.strictEqual(timeline.jobId, testJobId);
    assert.strictEqual(timeline.format, 'short');
    assert.strictEqual(timeline.aspectRatio, '9:16');
    assert.strictEqual(timeline.totalDurationSeconds, 16.2);

    // Check Video Track
    assert.strictEqual(timeline.tracks.video.length, 3);
    assert.strictEqual(timeline.tracks.video[0].durationSeconds, 5.2);
    assert.strictEqual(timeline.tracks.video[1].durationSeconds, 5.4);
    assert.strictEqual(timeline.tracks.video[1].cropOrScale.scaleMode, 'smart_center_crop');

    // Check Narration Track
    assert.strictEqual(timeline.tracks.narration.length, 3);

    // Check Music Track
    assert.strictEqual(timeline.tracks.music.length, 1);
    assert.strictEqual(timeline.tracks.music[0].type, 'music');
    assert.ok(timeline.tracks.music[0].duckingEnvelope && timeline.tracks.music[0].duckingEnvelope.length > 0);

    // Check SFX Track
    assert.ok(timeline.tracks.sfx.length > 0, 'Should have placed SFX accents');

    // Check Captions Track
    assert.strictEqual(timeline.tracks.textOverlays.length, 3);
    assert.strictEqual(timeline.tracks.textOverlays[0].styleVariant, 'hero_hook');
    assert.strictEqual(timeline.tracks.textOverlays[1].styleVariant, 'statistic_card');

    // Verify stored artifacts on disk
    const timelinePath = path.resolve(testDir, 'inputs/jobs', testJobId, 'timeline.json');
    const assetsPath = path.resolve(testDir, 'inputs/jobs', testJobId, 'assets.json');

    assert.ok(fs.existsSync(timelinePath), 'timeline.json should be saved');
    assert.ok(fs.existsSync(assetsPath), 'assets.json should be saved');

    const loadedTimeline = JSON.parse(fs.readFileSync(timelinePath, 'utf-8'));
    assert.strictEqual(loadedTimeline.jobId, testJobId);
    assert.strictEqual(loadedTimeline.tracks.video.length, 3);
  });

  it('should run CLI assets and timeline commands cleanly', async () => {
    // 1. Run CLI assets command
    const exitAssets = await runCli([
      'assets',
      '--topic', 'Artificial Intelligence in Medicine',
      '--format', 'short',
      '--job-id', 'job_cli_assets_test',
    ]);
    assert.strictEqual(exitAssets, 0, 'CLI assets command should return exit code 0');

    // 2. Run CLI timeline command with saved job inputs
    const scenesPath = path.resolve(testDir, 'inputs/jobs', testJobId, 'scenes.json');
    const brollPath = path.resolve(testDir, 'inputs/jobs', testJobId, 'broll_selection.json');
    const narrPath = path.resolve(testDir, 'inputs/jobs', testJobId, 'narration.json');
    const scriptPath = path.resolve(testDir, 'inputs/jobs', testJobId, 'script.json');

    fs.mkdirSync(path.dirname(scenesPath), { recursive: true });
    fs.writeFileSync(scenesPath, JSON.stringify(mockScenes, null, 2));
    fs.writeFileSync(brollPath, JSON.stringify(mockBroll, null, 2));
    fs.writeFileSync(narrPath, JSON.stringify(mockNarration, null, 2));
    fs.writeFileSync(scriptPath, JSON.stringify(mockScript, null, 2));

    const exitTimeline = await runCli([
      'timeline',
      '--scenes-json', scenesPath,
      '--broll-json', brollPath,
      '--narration-json', narrPath,
      '--script-json', scriptPath,
      '--format', 'short',
      '--job-id', testJobId,
    ]);
    assert.strictEqual(exitTimeline, 0, 'CLI timeline command should return exit code 0');
  });
});
