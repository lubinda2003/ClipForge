import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { ResearchEngine } from '../../src/research/engine.ts';
import { GeminiResearchProvider } from '../../src/research/gemini.ts';
import { ContentStrategyEngine } from '../../src/strategy/engine.ts';
import { GeminiStrategyProvider } from '../../src/strategy/gemini.ts';
import { ScriptEngine } from '../../src/scripting/engine.ts';
import { GeminiScriptProvider } from '../../src/scripting/gemini.ts';
import { NarrationEngine } from '../../src/narration/engine.ts';
import { PiperNarrationProvider } from '../../src/narration/piper.ts';
import { ScenePlanner } from '../../src/scenes/engine.ts';
import { GeminiScenePlanningProvider } from '../../src/scenes/gemini.ts';
import { BrollSelectionEngine } from '../../src/stock/engine.ts';
import { LocalStorageProvider } from '../../src/storage/local.ts';
import { CacheManager } from '../../src/storage/cache.ts';
import { runCli } from '../../src/cli/index.ts';

describe('Phase 4 Pipeline Integration (Scenes + B-Roll)', () => {
  const testBaseDir = path.resolve('./.cache/test_integration_phase4');
  let storage: LocalStorageProvider;
  let cache: CacheManager;

  beforeEach(() => {
    if (fs.existsSync(testBaseDir)) {
      fs.rmSync(testBaseDir, { recursive: true, force: true });
    }
    storage = new LocalStorageProvider(testBaseDir);
    cache = new CacheManager(storage);
  });

  afterEach(() => {
    if (fs.existsSync(testBaseDir)) {
      fs.rmSync(testBaseDir, { recursive: true, force: true });
    }
  });

  it('runs complete 6-stage pipeline from Topic to B-Roll selection', async () => {
    const researchEngine = new ResearchEngine({
      storage,
      cache,
      geminiProvider: new GeminiResearchProvider({ apiKey: '' }),
    });

    const strategyEngine = new ContentStrategyEngine({
      storage,
      cache,
      geminiProvider: new GeminiStrategyProvider({ apiKey: '' }),
    });

    const scriptEngine = new ScriptEngine({
      storage,
      cache,
      scriptProvider: new GeminiScriptProvider({ apiKey: '' }),
    });

    const narrationEngine = new NarrationEngine({
      storage,
      cache,
      provider: new PiperNarrationProvider({ mockMode: true, cache }),
    });

    const scenePlanner = new ScenePlanner({
      storage,
      cache,
      provider: new GeminiScenePlanningProvider({ apiKey: '', cache }),
    });

    const brollEngine = new BrollSelectionEngine({
      storage,
      cache,
      providers: [], // Force offline fallback candidate generation
    });

    const topic = 'Fusion Energy Milestones';
    const jobId = 'job_phase4_int_001';

    // 1. Research
    const research = await researchEngine.executeResearch(topic, { jobId, format: 'short' });
    assert.equal(research.topic, topic);
    assert.ok(await storage.exists('inputs', `jobs/${jobId}/research.json`));

    // 2. Strategy
    const strategy = await strategyEngine.executeStrategy(research, { jobId, format: 'short' });
    assert.equal(strategy.topic, topic);
    assert.ok(await storage.exists('inputs', `jobs/${jobId}/strategy.json`));

    // 3. Scripting
    const script = await scriptEngine.executeScripting(research, strategy, { jobId, format: 'short' });
    assert.equal(script.topic, topic);
    assert.ok(script.segments.length >= 3);
    assert.ok(await storage.exists('inputs', `jobs/${jobId}/script.json`));

    // 4. Narration
    const narration = await narrationEngine.executeNarration(script, { jobId });
    assert.equal(narration.jobId, jobId);
    assert.ok(narration.totalDurationSeconds > 0);
    assert.ok(await storage.exists('inputs', `jobs/${jobId}/narration.json`));

    // 5. Scene Planning
    const scenes = await scenePlanner.executeScenePlanning(script, narration, strategy, research, {
      jobId,
      format: 'short',
    });
    assert.equal(scenes.jobId, jobId);
    assert.equal(scenes.format, 'short');
    assert.ok(scenes.totalScenes >= script.segments.length);
    assert.ok(
      Math.abs(scenes.totalDurationSeconds - narration.totalDurationSeconds) < 0.05,
      `Duration mismatch: ${scenes.totalDurationSeconds} vs ${narration.totalDurationSeconds}`
    );
    assert.ok(await storage.exists('inputs', `jobs/${jobId}/scenes.json`));

    // 6. B-Roll Selection
    const broll = await brollEngine.executeBrollSelection(scenes, {
      jobId,
      format: 'short',
      downloadMedia: false,
    });
    assert.equal(broll.jobId, jobId);
    assert.equal(broll.format, 'short');
    assert.equal(broll.selections.length, scenes.totalScenes);
    assert.ok(await storage.exists('inputs', `jobs/${jobId}/broll_selection.json`));
  });

  it('CLI executes "scenes" and "broll" commands end-to-end', async () => {
    const topic = 'Neural Interfaces 2026';
    const jobId = 'job_cli_p4_001';

    // Run upstream with CLI scenes command directly from topic
    const scenesExit = await runCli([
      'scenes',
      '--topic', topic,
      '--job-id', jobId,
      '--format', 'short',
      '--cache-dir', testBaseDir,
      '--offline',
    ]);
    assert.equal(scenesExit, 0);

    const scenesPath = path.join(testBaseDir, 'inputs/jobs', jobId, 'scenes.json');
    assert.ok(fs.existsSync(scenesPath));

    // Run CLI broll command referencing generated scenes JSON
    const brollExit = await runCli([
      'broll',
      '--scenes-json', scenesPath,
      '--job-id', jobId,
      '--format', 'short',
      '--cache-dir', testBaseDir,
      '--offline',
      '--no-download',
    ]);
    assert.equal(brollExit, 0);

    const brollPath = path.join(testBaseDir, 'inputs/jobs', jobId, 'broll_selection.json');
    assert.ok(fs.existsSync(brollPath));
  });
});
