import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

import { RenderEngine } from '../../src/rendering/engine.ts';
import { SHORT_FORM_PROFILE, LONG_FORM_PROFILE } from '../../src/contracts/rendering.ts';
import { TimelineArtifact } from '../../src/contracts/timeline.ts';
import { runCli } from '../../src/cli/index.ts';

describe('Phase 6 End-to-End Real FFmpeg Video Rendering & Validation Integration', () => {
  const testJobId = 'job_test_phase6_e2e';
  const testDir = './.cache/clipforge';
  const mediaDir = path.join(testDir, 'test_media_p6');

  if (!fs.existsSync(mediaDir)) {
    fs.mkdirSync(mediaDir, { recursive: true });
  }

  const videoClip1 = path.join(mediaDir, 'broll_scene_1.mp4');
  const videoClip2 = path.join(mediaDir, 'broll_scene_2.mp4');
  const narrationAudio = path.join(mediaDir, 'narration_voice.wav');
  const musicAudio = path.join(mediaDir, 'background_music.wav');
  const sfxAudio = path.join(mediaDir, 'sfx_whoosh.wav');

  // Generate real audio/video files using FFmpeg synthetic filters
  execFileSync('ffmpeg', [
    '-y',
    '-f', 'lavfi',
    '-i', 'testsrc=duration=2.0:size=1280x720:rate=30',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    videoClip1,
  ]);

  execFileSync('ffmpeg', [
    '-y',
    '-f', 'lavfi',
    '-i', 'color=c=navy:s=1920x1080:d=2.0:r=30',
    '-c:v', 'libx264',
    '-pix_fmt', 'yuv420p',
    videoClip2,
  ]);

  execFileSync('ffmpeg', [
    '-y',
    '-f', 'lavfi',
    '-i', 'sine=frequency=500:duration=4.0',
    narrationAudio,
  ]);

  execFileSync('ffmpeg', [
    '-y',
    '-f', 'lavfi',
    '-i', 'sine=frequency=250:duration=4.0',
    musicAudio,
  ]);

  execFileSync('ffmpeg', [
    '-y',
    '-f', 'lavfi',
    '-i', 'sine=frequency=1000:duration=0.5',
    sfxAudio,
  ]);

  const mockTimeline: TimelineArtifact = {
    jobId: testJobId,
    createdAt: new Date().toISOString(),
    format: 'short',
    aspectRatio: '9:16',
    totalDurationSeconds: 4.0,
    tracks: {
      video: [
        {
          elementId: 'v_scene_01',
          sceneId: 'sc_01',
          sourceFilePath: videoClip1,
          startTimelineSeconds: 0,
          durationSeconds: 2.0,
          sourceTrimStartSeconds: 0,
          motionEffect: 'slow_zoom_in',
          cropOrScale: { scaleMode: 'smart_center_crop', aspectRatio: '9:16' },
          transitionIn: { type: 'fade', durationSeconds: 0.3 },
        },
        {
          elementId: 'v_scene_02',
          sceneId: 'sc_02',
          sourceFilePath: videoClip2,
          startTimelineSeconds: 2.0,
          durationSeconds: 2.0,
          sourceTrimStartSeconds: 0,
          motionEffect: 'slow_pan_left',
          cropOrScale: { scaleMode: 'smart_center_crop', aspectRatio: '9:16' },
          transitionIn: { type: 'fade', durationSeconds: 0.3 },
        },
      ],
      narration: [
        {
          elementId: 'nar_track_01',
          segmentId: 'seg_01',
          audioFilePath: narrationAudio,
          startTimelineSeconds: 0,
          durationSeconds: 4.0,
          volume: 1.0,
        },
      ],
      music: [
        {
          elementId: 'mus_track_01',
          type: 'music',
          audioFilePath: musicAudio,
          startTimelineSeconds: 0,
          durationSeconds: 4.0,
          volume: 0.8,
          loop: true,
          duckingEnvelope: [
            { timestampSeconds: 0, volumeMultiplier: 0.8 },
            { timestampSeconds: 0.5, volumeMultiplier: 0.2 },
            { timestampSeconds: 3.5, volumeMultiplier: 0.2 },
            { timestampSeconds: 4.0, volumeMultiplier: 0.8 },
          ],
        },
      ],
      sfx: [
        {
          elementId: 'sfx_track_01',
          type: 'sfx',
          audioFilePath: sfxAudio,
          startTimelineSeconds: 0.1,
          durationSeconds: 0.5,
          volume: 0.7,
        },
      ],
      textOverlays: [
        {
          elementId: 'txt_hook',
          primaryText: 'The Breakthrough Begins',
          startTimelineSeconds: 0.2,
          durationSeconds: 1.8,
          styleVariant: 'hero_hook',
          positioning: {
            horizontalAlign: 'center',
            verticalAlign: 'bottom',
            safeZoneMargins: {
              topPercent: 15,
              bottomPercent: 20,
              leftPercent: 8,
              rightPercent: 18,
            },
          },
        },
        {
          elementId: 'txt_resolution',
          primaryText: 'Unlimited Clean Energy',
          startTimelineSeconds: 2.2,
          durationSeconds: 1.6,
          styleVariant: 'bold_caption',
          positioning: {
            horizontalAlign: 'center',
            verticalAlign: 'bottom',
            safeZoneMargins: {
              topPercent: 15,
              bottomPercent: 20,
              leftPercent: 8,
              rightPercent: 18,
            },
          },
        },
      ],
    },
    retentionAnnotations: [],
  };

  it('executes real FFmpeg rendering and produces fully validated MP4 output', async () => {
    const renderEngine = new RenderEngine({ baseDirectory: testDir });
    const result = await renderEngine.executeRender({
      jobId: testJobId,
      timeline: mockTimeline,
      profile: SHORT_FORM_PROFILE,
    });

    assert.equal(result.jobId, testJobId);
    assert.ok(fs.existsSync(result.outputPath), 'Rendered output file must exist on disk');
    assert.equal(result.width, 1080, 'Rendered width must match 1080');
    assert.equal(result.height, 1920, 'Rendered height must match 1920');
    assert.equal(result.fps, 30, 'Rendered framerate must match 30');
    assert.equal(result.videoCodec, 'h264', 'Video codec must be h264');
    assert.equal(result.audioCodec, 'aac', 'Audio codec must be aac');
    assert.ok(result.fileSize > 10000, 'Rendered MP4 file size must be non-trivial');
    assert.equal(result.validation.status, 'passed', 'Validation status must be passed');
    assert.equal(result.validation.checks.containerValid, true);
    assert.equal(result.validation.checks.videoStreamValid, true);
    assert.equal(result.validation.checks.audioStreamValid, true);
    assert.equal(result.validation.checks.dimensionsValid, true);
    assert.equal(result.validation.checks.durationValid, true);
  });

  it('runs CLI "render" and "validate" commands cleanly against artifacts', async () => {
    // Save timeline artifact to disk
    const jobDir = path.join(testDir, 'outputs', 'jobs', testJobId);
    if (!fs.existsSync(jobDir)) fs.mkdirSync(jobDir, { recursive: true });
    const timelinePath = path.join(jobDir, 'timeline.json');
    fs.writeFileSync(timelinePath, JSON.stringify(mockTimeline, null, 2));

    const outputPath = path.join(jobDir, 'cli_rendered.mp4');

    // Test CLI render command
    const renderExitCode = await runCli([
      'render',
      '--timeline', timelinePath,
      '--format', 'short',
      '--output', outputPath,
      '--cache-dir', testDir,
    ]);
    assert.equal(renderExitCode, 0, 'CLI render command must exit with code 0');
    assert.ok(fs.existsSync(outputPath), 'CLI render output must exist on disk');

    // Test CLI validate command
    const validateExitCode = await runCli([
      'validate',
      '--output', outputPath,
      '--format', 'short',
      '--cache-dir', testDir,
    ]);
    assert.equal(validateExitCode, 0, 'CLI validate command must exit with code 0');
  });
});
