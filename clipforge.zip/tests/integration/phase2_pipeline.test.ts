import { describe, it, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { ResearchEngine } from '../../src/research/engine.ts';
import { GeminiResearchProvider } from '../../src/research/gemini.ts';
import { ContentStrategyEngine } from '../../src/strategy/engine.ts';
import { GeminiStrategyProvider } from '../../src/strategy/gemini.ts';
import { LocalStorageProvider } from '../../src/storage/local.ts';
import { CacheManager } from '../../src/storage/cache.ts';
import { parseArgs, runCli } from '../../src/cli/index.ts';

describe('Phase 2 Pipeline Integration', () => {
  const testBaseDir = path.resolve('./.cache/test_integration_phase2');
  let storage: LocalStorageProvider;
  let cache: CacheManager;

  beforeEach(() => {
    if (fs.existsSync(testBaseDir)) {
      fs.rmSync(testBaseDir, { recursive: true, force: true });
    }
    storage = new LocalStorageProvider(testBaseDir);
    cache = new CacheManager(storage);
  });

  afterEach(() => {
    if (fs.existsSync(testBaseDir)) {
      fs.rmSync(testBaseDir, { recursive: true, force: true });
    }
  });

  it('runs complete Phase 2 research-to-strategy pipeline and writes artifacts', async () => {
    const researchEngine = new ResearchEngine({
      storage,
      cache,
      geminiProvider: new GeminiResearchProvider({ apiKey: '' }),
    });
    const strategyEngine = new ContentStrategyEngine({
      storage,
      cache,
      geminiProvider: new GeminiStrategyProvider({ apiKey: '' }),
    });

    const topic = 'Geothermal Energy Drilling Technology';
    const jobId = 'job_int_001';

    // 1. Execute Research
    const research = await researchEngine.executeResearch(topic, {
      jobId,
      format: 'short',
    });

    assert.equal(research.jobId, jobId);
    assert.equal(research.topic, topic);
    assert.equal(research.formatTarget, 'short');
    assert.ok(research.observedData);
    assert.ok(research.inferredInsights);

    // Verify research.json written to storage
    const researchExists = await storage.exists('inputs', `jobs/${jobId}/research.json`);
    assert.equal(researchExists, true);

    // 2. Execute Strategy using research artifact
    const strategy = await strategyEngine.executeStrategy(research, {
      jobId,
      format: 'short',
    });

    assert.equal(strategy.jobId, jobId);
    assert.equal(strategy.topic, topic);
    assert.ok(strategy.hook.hookText);
    assert.ok(strategy.narrativeStructure.length >= 3);

    // Verify strategy.json written to storage
    const strategyExists = await storage.exists('inputs', `jobs/${jobId}/strategy.json`);
    assert.equal(strategyExists, true);

    // Verify persisted JSON content
    const savedResearch = await storage.readJson<typeof research>('inputs', `jobs/${jobId}/research.json`);
    const savedStrategy = await storage.readJson<typeof strategy>('inputs', `jobs/${jobId}/strategy.json`);

    assert.equal(savedResearch?.topic, topic);
    assert.equal(savedStrategy?.topic, topic);
  });

  it('CLI args parser parses commands and flags correctly', () => {
    const parsed = parseArgs(['research', '--topic', 'Mars Habitats', '--format', 'long', '--job-id', 'mars_1']);
    assert.equal(parsed.command, 'research');
    assert.equal(parsed.topic, 'Mars Habitats');
    assert.equal(parsed.format, 'long');
    assert.equal(parsed.jobId, 'mars_1');
  });

  it('CLI runner executes analyze command end-to-end', async () => {
    const exitCode = await runCli([
      'analyze',
      '--topic', 'Synthetic Biology',
      '--format', 'short',
      '--cache-dir', testBaseDir,
      '--offline',
    ]);

    assert.equal(exitCode, 0);
  });
});
