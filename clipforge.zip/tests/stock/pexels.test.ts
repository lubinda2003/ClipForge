import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { PexelsStockProvider } from '../../src/stock/pexels.ts';
import { StockError } from '../../src/stock/errors.ts';

describe('Pexels Stock Media Provider', () => {
  const mockPexelsApiResponse = {
    page: 1,
    per_page: 2,
    total_results: 10,
    videos: [
      {
        id: 855564,
        width: 1920,
        height: 1080,
        url: 'https://www.pexels.com/video/855564/',
        image: 'https://images.pexels.com/videos/855564/preview.jpg',
        duration: 18,
        user: { id: 123, name: 'Jane Doe', url: 'https://www.pexels.com/@janedoe' },
        video_files: [
          {
            id: 1,
            quality: 'hd',
            file_type: 'video/mp4',
            width: 1920,
            height: 1080,
            fps: 29.97,
            link: 'https://player.vimeo.com/external/hd_video.mp4',
          },
          {
            id: 2,
            quality: 'sd',
            file_type: 'video/mp4',
            width: 960,
            height: 540,
            fps: 29.97,
            link: 'https://player.vimeo.com/external/sd_video.mp4',
          },
        ],
        tags: [{ name: 'laboratory' }, { name: 'scientist' }],
      },
    ],
  };

  it('reports unavailable when API key is missing', async () => {
    const provider = new PexelsStockProvider({ apiKey: '' });
    const status = await provider.checkAvailability();
    assert.equal(status.available, false);
    assert.equal(status.reason, 'missing_api_key');

    await assert.rejects(
      async () => provider.searchVideos('quantum lab'),
      (err: StockError) => err.code === 'STOCK_AUTH_FAILED'
    );
  });

  it('parses and normalizes video search results correctly', async () => {
    const mockFetch = async () =>
      new Response(JSON.stringify(mockPexelsApiResponse), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });

    const provider = new PexelsStockProvider({
      apiKey: 'test_pexels_key_12345',
      fetchFn: mockFetch as any,
    });

    const candidates = await provider.searchVideos('laboratory research', { perPage: 2 });
    assert.equal(candidates.length, 1);

    const c = candidates[0];
    assert.equal(c.source, 'pexels');
    assert.equal(c.sourceId, '855564');
    assert.equal(c.candidateId, 'pexels_855564');
    assert.equal(c.author, 'Jane Doe');
    assert.equal(c.durationSeconds, 18);
    assert.equal(c.downloadUrl, 'https://player.vimeo.com/external/hd_video.mp4');
    assert.equal(c.resolution.width, 1920);
    assert.equal(c.resolution.height, 1080);
    assert.equal(c.originalAspectRatio, '16:9');
    assert.ok(c.tags.includes('laboratory'));
    assert.ok(c.files.length === 2);
  });

  it('handles HTTP 401 unauthorized gracefully without leaking key', async () => {
    const mockFetch = async () =>
      new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });

    const provider = new PexelsStockProvider({
      apiKey: 'secret_test_key_999999999',
      fetchFn: mockFetch as any,
    });

    await assert.rejects(
      async () => provider.searchVideos('physics'),
      (err: StockError) => {
        assert.equal(err.code, 'STOCK_AUTH_FAILED');
        assert.ok(!err.message.includes('secret_test_key'));
        return true;
      }
    );
  });

  it('handles HTTP 429 rate limit correctly', async () => {
    const mockFetch = async () =>
      new Response(JSON.stringify({ error: 'Too Many Requests' }), { status: 429 });

    const provider = new PexelsStockProvider({
      apiKey: 'test_key',
      fetchFn: mockFetch as any,
    });

    await assert.rejects(
      async () => provider.searchVideos('stars'),
      (err: StockError) => err.code === 'STOCK_RATE_LIMITED'
    );
  });
});
