import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { CandidateRanker } from '../../src/stock/ranker.ts';
import { StockCandidate } from '../../src/contracts/stock.ts';
import { PlannedScene } from '../../src/contracts/scenes.ts';

describe('B-Roll Candidate Ranker', () => {
  const ranker = new CandidateRanker();

  const mockScene: PlannedScene = {
    sceneId: 'scene_001',
    correspondingSegmentId: 'seg_001',
    sequenceOrder: 0,
    narrationExcerpt: 'Superconductors operate without resistance.',
    visualConcept: 'Futuristic floating maglev train in laboratory',
    searchKeywords: ['maglev train', 'levitation', 'laboratory'],
    preferredVisualType: 'realistic_video',
    desiredDurationSeconds: 4.5,
    targetAspectRatio: '9:16',
    format: 'short',
    visualMood: 'inspiring',
    allowCropping: true,
  };

  const portraitCandidate: StockCandidate = {
    candidateId: 'cand_portrait',
    source: 'pexels',
    sourceId: '101',
    title: 'Futuristic maglev high speed train levitation',
    tags: ['maglev', 'train', 'levitation', 'futuristic', 'technology'],
    durationSeconds: 8.0,
    previewUrl: 'https://example.com/p.jpg',
    downloadUrl: 'https://example.com/p.mp4',
    resolution: { width: 1080, height: 1920 },
    originalAspectRatio: '9:16',
    files: [{ fileId: 'f1', url: 'https://example.com/p.mp4', width: 1080, height: 1920, aspectRatio: '9:16', quality: 'hd', fileType: 'video/mp4' }],
    author: 'Tech Videographer',
    license: 'Free to use',
    relevanceScore: 0.9,
    queryUsed: 'maglev train',
    orientation: 'portrait',
  };

  const landscapeLowResCandidate: StockCandidate = {
    candidateId: 'cand_landscape_low',
    source: 'pixabay',
    sourceId: '102',
    title: 'Regular train track',
    tags: ['train', 'transport'],
    durationSeconds: 6.0,
    previewUrl: 'https://example.com/l.jpg',
    downloadUrl: 'https://example.com/l.mp4',
    resolution: { width: 1280, height: 720 },
    originalAspectRatio: '16:9',
    files: [{ fileId: 'f2', url: 'https://example.com/l.mp4', width: 1280, height: 720, aspectRatio: '16:9', quality: 'hd', fileType: 'video/mp4' }],
    author: 'Traveler',
    license: 'Free to use',
    relevanceScore: 0.4,
    queryUsed: 'train',
    orientation: 'landscape',
  };

  const shortDurationCandidate: StockCandidate = {
    candidateId: 'cand_too_short',
    source: 'pexels',
    sourceId: '103',
    title: 'Maglev train floating laboratory',
    tags: ['maglev', 'levitation', 'laboratory'],
    durationSeconds: 2.0, // Shorter than desired 4.5s
    previewUrl: 'https://example.com/s.jpg',
    downloadUrl: 'https://example.com/s.mp4',
    resolution: { width: 1080, height: 1920 },
    originalAspectRatio: '9:16',
    files: [{ fileId: 'f3', url: 'https://example.com/s.mp4', width: 1080, height: 1920, aspectRatio: '9:16', quality: 'hd', fileType: 'video/mp4' }],
    author: 'Scientist',
    license: 'Free to use',
    relevanceScore: 0.9,
    queryUsed: 'maglev train',
    orientation: 'portrait',
  };

  it('ranks native portrait higher than landscape for 9:16 short-form video', () => {
    const scored = ranker.rankCandidates([landscapeLowResCandidate, portraitCandidate], mockScene, 'short');
    assert.equal(scored[0].candidateId, 'cand_portrait');
    assert.ok(scored[0].relevanceScore > scored[1].relevanceScore);
    assert.equal(scored[0].rankingBreakdown?.aspectRatioScore, 1.0);
    assert.ok(scored[0].rankingBreakdown!.aspectRatioScore > scored[1].rankingBreakdown!.aspectRatioScore);
  });

  it('heavily penalizes candidates shorter than desired duration', () => {
    const scored = ranker.rankCandidates([shortDurationCandidate, portraitCandidate], mockScene, 'short');
    assert.equal(scored[0].candidateId, 'cand_portrait');

    const shortBreakdown = scored.find(s => s.candidateId === 'cand_too_short')!.rankingBreakdown!;
    assert.ok(shortBreakdown.durationScore < 0.5, 'Duration score should be penalized for short clip');
  });

  it('applies repetition penalty to previously used source IDs', () => {
    // Both identical candidates except ID
    const c1: StockCandidate = { ...portraitCandidate, candidateId: 'c1', sourceId: 'src_100' };
    const c2: StockCandidate = { ...portraitCandidate, candidateId: 'c2', sourceId: 'src_200' };

    const scored = ranker.rankCandidates([c1, c2], mockScene, 'short', new Set(['src_100']));
    assert.equal(scored[0].candidateId, 'c2');
    assert.equal(scored[0].rankingBreakdown?.repetitionPenalty, 0);
    assert.ok(scored[1].rankingBreakdown?.repetitionPenalty! > 0.2);
  });

  it('calculates crop transforms when applying landscape to portrait', () => {
    const highResLandscape: StockCandidate = {
      ...landscapeLowResCandidate,
      resolution: { width: 3840, height: 2160 }, // 4K landscape can be center-cropped to 9:16
    };
    const transforms = ranker.calculateTransforms(highResLandscape, 'short');
    assert.equal(transforms.cropRequired, true);
    assert.equal(transforms.targetAspectRatio, '9:16');
  });
});
