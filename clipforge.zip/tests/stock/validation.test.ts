import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { validateBrollArtifact } from '../../src/stock/validator.ts';
import { MediaValidator } from '../../src/stock/validator.ts';
import { BrollSelectionArtifact } from '../../src/contracts/stock.ts';
import fs from 'node:fs';
import path from 'node:path';

describe('B-Roll Artifact & Media Validator', () => {
  const validArtifact: BrollSelectionArtifact = {
    jobId: 'job_broll_val_01',
    createdAt: new Date().toISOString(),
    format: 'short',
    totalScenes: 1,
    selections: [
      {
        sceneId: 'scene_001',
        selectedCandidate: {
          candidateId: 'pexels_123',
          source: 'pexels',
          sourceId: '123',
          title: 'Quantum computer laboratory',
          tags: ['quantum', 'lab'],
          durationSeconds: 10,
          previewUrl: 'https://example.com/p.jpg',
          downloadUrl: 'https://example.com/d.mp4',
          resolution: { width: 1080, height: 1920 },
          originalAspectRatio: '9:16',
          files: [],
          author: 'Pexels Creator',
          license: 'Pexels License',
          relevanceScore: 0.95,
          queryUsed: 'quantum lab',
        },
        selectedFile: {
          fileId: 'f1',
          url: 'https://example.com/d.mp4',
          width: 1080,
          height: 1920,
          aspectRatio: '9:16',
          quality: 'hd',
          fileType: 'video/mp4',
        },
        trimStartSeconds: 0,
        trimDurationSeconds: 4.5,
        appliedTransform: 'native',
      },
    ],
    cacheStats: {
      apiQueries: 1,
      cacheHits: 0,
      bytesDownloaded: 0,
    },
  };

  it('passes a fully conforming BrollSelectionArtifact', () => {
    const result = validateBrollArtifact(validArtifact);
    assert.equal(result.isValid, true);
    assert.equal(result.errors.length, 0);
  });

  it('rejects artifact with missing selectedFile or empty downloadUrl', () => {
    const invalid: BrollSelectionArtifact = {
      ...validArtifact,
      selections: [
        {
          ...validArtifact.selections[0],
          selectedCandidate: {
            ...validArtifact.selections[0].selectedCandidate,
            downloadUrl: '',
          },
        },
      ],
    };
    const result = validateBrollArtifact(invalid);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.some(e => e.includes('missing downloadUrl')));
  });

  it('rejects exposed API key patterns in artifact metadata', () => {
    const leakedKey = 'pexels_key_v1_abcdef1234567890abcdef1234567890';
    const invalid: BrollSelectionArtifact = {
      ...validArtifact,
      selections: [
        {
          ...validArtifact.selections[0],
          selectedCandidate: {
            ...validArtifact.selections[0].selectedCandidate,
            title: `Suspicious video with key=${leakedKey}`,
          },
        },
      ],
    };
    const result = validateBrollArtifact(invalid);
    assert.equal(result.isValid, false);
    assert.ok(result.errors.some(e => e.includes('exposed API credentials')));
  });

  it('MediaValidator identifies valid media and rejects 0-byte or non-existent files', async () => {
    const validator = new MediaValidator();
    const nonExistentResult = await validator.validateMediaFile('/non/existent/path/file.mp4');
    assert.equal(nonExistentResult.isValid, false);
    assert.ok(nonExistentResult.error?.includes('does not exist'));

    const tempEmpty = path.resolve('./.cache/test_empty.mp4');
    fs.mkdirSync(path.dirname(tempEmpty), { recursive: true });
    fs.writeFileSync(tempEmpty, '');

    const emptyResult = await validator.validateMediaFile(tempEmpty);
    assert.equal(emptyResult.isValid, false);
    assert.ok(emptyResult.error?.includes('empty (0 bytes)'));

    if (fs.existsSync(tempEmpty)) fs.unlinkSync(tempEmpty);
  });
});
