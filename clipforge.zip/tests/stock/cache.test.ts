import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { PexelsStockProvider } from '../../src/stock/pexels.ts';
import { LocalStorageProvider } from '../../src/storage/local.ts';
import { CacheManager } from '../../src/storage/cache.ts';
import fs from 'node:fs';
import path from 'node:path';

describe('Stock Media Provider Caching', () => {
  const testDir = path.resolve('./.cache/test_stock_cache');

  it('caches search results in CacheManager and prevents repeated network calls', async () => {
    if (fs.existsSync(testDir)) fs.rmSync(testDir, { recursive: true, force: true });
    const storage = new LocalStorageProvider(testDir);
    const cache = new CacheManager(storage);

    let callCount = 0;
    const mockFetch = async () => {
      callCount++;
      return new Response(
        JSON.stringify({
          page: 1,
          per_page: 5,
          total_results: 1,
          videos: [
            {
              id: 999,
              width: 1080,
              height: 1920,
              duration: 10,
              url: 'https://pexels.com/999',
              image: 'https://pexels.com/preview.jpg',
              video_files: [{ id: 1, quality: 'hd', file_type: 'video/mp4', width: 1080, height: 1920, link: 'https://example.com/999.mp4' }],
              tags: [{ name: 'ai' }],
            },
          ],
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    };

    const provider = new PexelsStockProvider({
      apiKey: 'test_key',
      fetchFn: mockFetch as any,
      cache,
    });

    const firstResult = await provider.searchVideos('artificial intelligence');
    assert.equal(firstResult.length, 1);
    assert.equal(callCount, 1);

    // Second call for exact same query should hit cache
    const secondResult = await provider.searchVideos('artificial intelligence');
    assert.equal(secondResult.length, 1);
    assert.equal(callCount, 1, 'Should have used cached result without re-fetching');

    if (fs.existsSync(testDir)) fs.rmSync(testDir, { recursive: true, force: true });
  });
});
