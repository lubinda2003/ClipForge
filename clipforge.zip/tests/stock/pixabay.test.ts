import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { PixabayStockProvider } from '../../src/stock/pixabay.ts';
import { StockError } from '../../src/stock/errors.ts';

describe('Pixabay Stock Media Provider', () => {
  const mockPixabayResponse = {
    total: 100,
    totalHits: 1,
    hits: [
      {
        id: 12345,
        pageURL: 'https://pixabay.com/videos/dna-spiral-science-12345/',
        type: 'film',
        tags: 'dna, science, genetics, biology',
        duration: 12,
        videos: {
          large: {
            url: 'https://cdn.pixabay.com/video/dna_large.mp4',
            width: 1920,
            height: 1080,
            size: 15420000,
          },
          medium: {
            url: 'https://cdn.pixabay.com/video/dna_medium.mp4',
            width: 1280,
            height: 720,
            size: 8200000,
          },
          small: {
            url: 'https://cdn.pixabay.com/video/dna_small.mp4',
            width: 640,
            height: 360,
            size: 2100000,
          },
          tiny: {
            url: 'https://cdn.pixabay.com/video/dna_tiny.mp4',
            width: 320,
            height: 180,
            size: 800000,
          },
        },
        views: 12000,
        downloads: 3400,
        likes: 450,
        user: 'ScienceAnimator',
        userImageURL: 'https://pixabay.com/user.jpg',
      },
    ],
  };

  it('reports unavailable when API key is missing', async () => {
    const provider = new PixabayStockProvider({ apiKey: '' });
    const status = await provider.checkAvailability();
    assert.equal(status.available, false);
    assert.equal(status.reason, 'missing_api_key');

    const results = await provider.searchVideos('dna');
    assert.equal(results.length, 0);
  });

  it('normalizes Pixabay hits into uniform StockCandidates', async () => {
    const mockFetch = async () =>
      new Response(JSON.stringify(mockPixabayResponse), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });

    const provider = new PixabayStockProvider({
      apiKey: 'pixabay_test_key',
      fetchFn: mockFetch as any,
    });

    const candidates = await provider.searchVideos('dna genetics');
    assert.equal(candidates.length, 1);

    const c = candidates[0];
    assert.equal(c.source, 'pixabay');
    assert.equal(c.sourceId, '12345');
    assert.equal(c.candidateId, 'pixabay_12345');
    assert.equal(c.author, 'ScienceAnimator');
    assert.equal(c.durationSeconds, 12);
    assert.equal(c.resolution.width, 1920);
    assert.equal(c.resolution.height, 1080);
    assert.equal(c.originalAspectRatio, '16:9');
    assert.ok(c.tags.includes('genetics'));
    assert.equal(c.files.length, 4);
    assert.equal(c.downloadUrl, 'https://cdn.pixabay.com/video/dna_large.mp4');
  });
});
