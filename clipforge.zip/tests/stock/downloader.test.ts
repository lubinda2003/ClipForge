import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { MediaDownloader } from '../../src/stock/downloader.ts';
import fs from 'node:fs';
import path from 'node:path';

describe('Media Downloader Atomic Operations', () => {
  const testDir = path.resolve('./.cache/test_downloader');

  it('downloads data atomically with temporary file rename', async () => {
    if (fs.existsSync(testDir)) fs.rmSync(testDir, { recursive: true, force: true });
    fs.mkdirSync(testDir, { recursive: true });

    const mockContent = 'MOCK_VIDEO_DATA_BUFFER_PAYLOAD_1234567890';
    const mockFetch = async () =>
      new Response(mockContent, {
        status: 200,
        headers: { 'Content-Type': 'video/mp4' },
      });

    // Mock validator that treats non-empty file as valid
    const mockValidator = {
      validateMediaFile: async (filePath: string) => {
        const stats = fs.statSync(filePath);
        return { isValid: stats.size > 0, fileSize: stats.size, durationSeconds: 5 };
      },
    };

    const downloader = new MediaDownloader({
      fetchFn: mockFetch as any,
      validator: mockValidator as any,
      retries: 1,
    });

    const destPath = path.join(testDir, 'final_video.mp4');
    const result = await downloader.downloadMedia('https://example.com/video.mp4', destPath);

    assert.equal(result.localPath, destPath);
    assert.ok(result.bytes > 0);
    assert.ok(fs.existsSync(destPath));
    assert.equal(fs.readFileSync(destPath, 'utf-8'), mockContent);

    // Ensure temporary files are not left behind
    const tmpFiles = fs.readdirSync(testDir).filter(f => f.includes('.tmp'));
    assert.equal(tmpFiles.length, 0);

    // Second call should reuse valid file without error
    const cachedResult = await downloader.downloadMedia('https://example.com/video.mp4', destPath);
    assert.equal(cachedResult.localPath, destPath);
    assert.equal(cachedResult.bytes, result.bytes);

    if (fs.existsSync(testDir)) fs.rmSync(testDir, { recursive: true, force: true });
  });

  it('cleans up temporary file when download fails', async () => {
    if (fs.existsSync(testDir)) fs.rmSync(testDir, { recursive: true, force: true });
    fs.mkdirSync(testDir, { recursive: true });

    const mockFetch = async () =>
      new Response('Server Error', { status: 500 });

    const downloader = new MediaDownloader({
      fetchFn: mockFetch as any,
      retries: 0,
    });

    const destPath = path.join(testDir, 'failed_video.mp4');
    await assert.rejects(
      async () => downloader.downloadMedia('https://example.com/fail.mp4', destPath),
      (err: any) => err.code === 'DOWNLOAD_FAILED'
    );

    assert.equal(fs.existsSync(destPath), false);
    const tmpFiles = fs.readdirSync(testDir).filter(f => f.includes('.tmp'));
    assert.equal(tmpFiles.length, 0);

    if (fs.existsSync(testDir)) fs.rmSync(testDir, { recursive: true, force: true });
  });
});
