/**
 * ClipForge Narration Interfaces
 * Interfaces for TTS providers, duration measurement, and narration coordination.
 */

import { ScriptArtifact } from '../contracts/script.ts';
import {
  INarrationProvider,
  NarrationArtifact,
  NarrationSegmentResult,
  WordTimestamp,
} from '../contracts/narration.ts';

export type {
  INarrationProvider,
  NarrationArtifact,
  NarrationSegmentResult,
  WordTimestamp,
};

export interface NarrationOptions {
  jobId?: string;
  voice?: string;
  speed?: number;
  volume?: number;
  outputDir?: string;
  offline?: boolean;
}

export interface NarrationValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export interface INarrationEngine {
  executeNarration(
    script: ScriptArtifact,
    options?: NarrationOptions
  ): Promise<NarrationArtifact>;
}
