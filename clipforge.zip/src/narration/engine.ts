/**
 * ClipForge Narration Engine
 * Coordinates audio synthesis of script segments, measures actual audio durations,
 * and records narration.json artifact.
 */

import fs from 'node:fs';
import path from 'node:path';
import { ScriptArtifact } from '../contracts/script.ts';
import { INarrationEngine, NarrationOptions } from './interfaces.ts';
import { INarrationProvider, NarrationArtifact, NarrationSegmentResult } from '../contracts/narration.ts';
import { PiperNarrationProvider } from './piper.ts';
import { validateNarrationArtifact } from './validator.ts';
import { IStorageProvider } from '../storage/interface.ts';
import { LocalStorageProvider } from '../storage/local.ts';
import { CacheManager } from '../storage/cache.ts';

export interface NarrationEngineDependencies {
  storage?: IStorageProvider;
  cache?: CacheManager;
  provider?: INarrationProvider;
}

export class NarrationEngine implements INarrationEngine {
  private readonly storage: IStorageProvider;
  private readonly cache: CacheManager;
  private readonly provider: INarrationProvider;

  constructor(deps: NarrationEngineDependencies = {}) {
    this.storage = deps.storage || new LocalStorageProvider();
    this.cache = deps.cache || new CacheManager(this.storage);
    this.provider = deps.provider || new PiperNarrationProvider({ cache: this.cache });
  }

  async executeNarration(
    script: ScriptArtifact,
    options: NarrationOptions = {}
  ): Promise<NarrationArtifact> {
    if (!script || !Array.isArray(script.segments) || script.segments.length === 0) {
      throw new Error('Valid ScriptArtifact with at least one segment is required for narration.');
    }

    const jobId = options.jobId || script.jobId || `job_${Date.now()}`;

    // Determine audio storage folder
    let audioDir: string;
    if (options.outputDir) {
      audioDir = options.outputDir;
    } else if (this.storage instanceof LocalStorageProvider) {
      audioDir = path.join(this.storage.baseDirectory, 'inputs', 'jobs', jobId, 'audio');
    } else {
      audioDir = path.join(process.cwd(), '.cache', 'clipforge', 'jobs', jobId, 'audio');
    }

    if (!fs.existsSync(audioDir)) {
      fs.mkdirSync(audioDir, { recursive: true });
    }

    const segmentResults: NarrationSegmentResult[] = [];
    let totalDuration = 0;

    // Synthesize each segment sequentially
    for (const segment of script.segments) {
      const outputFilePath = path.join(audioDir, `${segment.segmentId}.wav`);

      const result = await this.provider.synthesizeSegment(
        segment.segmentId,
        segment.narrationText,
        outputFilePath,
        {
          voice: options.voice,
          speed: options.speed,
          volume: options.volume,
        }
      );

      segmentResults.push(result);
      totalDuration += result.actualDurationSeconds;
    }

    const narrationArtifact: NarrationArtifact = {
      jobId,
      createdAt: new Date().toISOString(),
      scriptReference: `jobs/${jobId}/script.json`,
      engine: (this.provider.providerName as 'piper' | 'elevenlabs' | 'mock') || 'piper',
      modelOrVoice: options.voice || 'en_US-lessac-medium',
      totalDurationSeconds: Number(totalDuration.toFixed(3)),
      segmentResults,
      metadata: {
        synthesizedAt: new Date().toISOString(),
        sampleRateHz: segmentResults[0]?.sampleRateHz || 22050,
        channels: segmentResults[0]?.channels || 1,
        providerStatus: 'ready',
      },
    };

    // Quality validation of generated narration artifact
    const validation = validateNarrationArtifact(narrationArtifact, { checkFilesExist: true });
    if (!validation.isValid) {
      throw new Error(`Narration validation failed:\n${validation.errors.join('\n')}`);
    }

    // Persist narration.json artifact
    const artifactKey = `jobs/${jobId}/narration.json`;
    if (this.storage instanceof LocalStorageProvider) {
      await this.storage.writeJson('inputs', artifactKey, narrationArtifact);
    }

    return narrationArtifact;
  }
}
