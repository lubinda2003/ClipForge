/**
 * ClipForge Audio Duration & Metadata Analyzer
 * Measures exact duration of generated audio files using WAV binary parsing and/or FFprobe.
 * Never assumes speaking rate, words-per-minute, or fixed durations.
 */

import fs from 'node:fs';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);

export interface AudioMetadata {
  durationSeconds: number;
  sampleRateHz: number;
  channels: number;
  bitsPerSample: number;
  format: 'wav' | 'pcm' | 'mp3';
  fileSizeBytes: number;
}

/**
 * Parses WAV file binary header directly to extract exact duration and audio specs.
 * Supports standard canonical RIFF/WAVE PCM and IEEE-float audio.
 */
export function readWavHeaderMetadata(filePath: string): AudioMetadata {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Audio file not found at path: ${filePath}`);
  }

  const stat = fs.statSync(filePath);
  if (stat.size < 44) {
    throw new Error(`Audio file at ${filePath} is too small to be a valid WAV file (${stat.size} bytes).`);
  }

  const buffer = fs.readFileSync(filePath);

  // Check RIFF header
  const riff = buffer.toString('ascii', 0, 4);
  const wave = buffer.toString('ascii', 8, 12);

  if (riff !== 'RIFF' || wave !== 'WAVE') {
    throw new Error(`Invalid audio container in ${filePath}. Expected RIFF/WAVE header, found "${riff}/${wave}".`);
  }

  // Iterate over chunks to locate 'fmt ' and 'data'
  let offset = 12;
  let channels = 1;
  let sampleRate = 22050;
  let byteRate = 44100;
  let blockAlign = 2;
  let bitsPerSample = 16;
  let dataSize = 0;
  let fmtFound = false;
  let dataFound = false;

  while (offset + 8 <= buffer.length) {
    const chunkId = buffer.toString('ascii', offset, offset + 4);
    const chunkSize = buffer.readUInt32LE(offset + 4);

    if (chunkId === 'fmt ') {
      fmtFound = true;
      channels = buffer.readUInt16LE(offset + 10);
      sampleRate = buffer.readUInt32LE(offset + 12);
      byteRate = buffer.readUInt32LE(offset + 16);
      blockAlign = buffer.readUInt16LE(offset + 20);
      bitsPerSample = buffer.readUInt16LE(offset + 22);
    } else if (chunkId === 'data') {
      dataFound = true;
      dataSize = chunkSize;
      break;
    }

    offset += 8 + chunkSize;
    // Align to word boundary if odd
    if (chunkSize % 2 !== 0) offset += 1;
  }

  if (!fmtFound) {
    throw new Error(`Missing 'fmt ' chunk in WAV file: ${filePath}`);
  }

  if (!dataFound || dataSize === 0) {
    // If data chunk header was truncated or reported 0, fallback to remaining buffer size
    dataSize = Math.max(0, buffer.length - offset - 8);
  }

  const effectiveByteRate = byteRate > 0 ? byteRate : sampleRate * channels * (bitsPerSample / 8);
  if (effectiveByteRate <= 0) {
    throw new Error(`Invalid audio byte rate in WAV file: ${filePath}`);
  }

  const durationSeconds = Number((dataSize / effectiveByteRate).toFixed(4));

  return {
    durationSeconds,
    sampleRateHz: sampleRate,
    channels,
    bitsPerSample,
    format: 'wav',
    fileSizeBytes: stat.size,
  };
}

/**
 * Measures exact duration using ffprobe when available, with automatic fallback to WAV header parsing.
 */
export async function measureAudioDuration(
  filePath: string,
  ffprobeBinPath: string = 'ffprobe'
): Promise<AudioMetadata> {
  // First, if it's a WAV file, we can verify via binary parsing
  let wavMeta: AudioMetadata | null = null;
  try {
    wavMeta = readWavHeaderMetadata(filePath);
  } catch {
    // Not a standard WAV or binary error; ffprobe will be attempted
  }

  // Attempt ffprobe for verification or compressed audio formats
  try {
    const { stdout } = await execFileAsync(ffprobeBinPath, [
      '-v', 'error',
      '-show_entries', 'format=duration:stream=sample_rate,channels',
      '-of', 'json',
      filePath,
    ]);

    const parsed = JSON.parse(stdout);
    const duration = parseFloat(parsed.format?.duration);
    const stream = parsed.streams?.[0];
    const sampleRate = parseInt(stream?.sample_rate || '22050', 10);
    const channels = parseInt(stream?.channels || '1', 10);

    if (!isNaN(duration) && duration > 0) {
      return {
        durationSeconds: Number(duration.toFixed(4)),
        sampleRateHz: wavMeta ? wavMeta.sampleRateHz : sampleRate,
        channels: wavMeta ? wavMeta.channels : channels,
        bitsPerSample: wavMeta ? wavMeta.bitsPerSample : 16,
        format: 'wav',
        fileSizeBytes: fs.statSync(filePath).size,
      };
    }
  } catch {
    // ffprobe unavailable or failed (e.g. in test container without ffprobe)
  }

  if (wavMeta && wavMeta.durationSeconds > 0) {
    return wavMeta;
  }

  throw new Error(`Failed to measure audio duration for ${filePath}: neither ffprobe nor WAV parser succeeded.`);
}

/**
 * Creates a valid, well-formed PCM WAV Buffer with exact duration for testing and offline mocks.
 */
export function createMockWavBuffer(
  durationSeconds: number,
  sampleRate: number = 22050,
  channels: number = 1,
  bitsPerSample: number = 16
): Buffer {
  const bytesPerSample = bitsPerSample / 8;
  const blockAlign = channels * bytesPerSample;
  const byteRate = sampleRate * blockAlign;
  const numSamples = Math.round(sampleRate * durationSeconds);
  const dataSize = numSamples * blockAlign;
  const bufferSize = 44 + dataSize;
  const buffer = Buffer.alloc(bufferSize);

  // RIFF Chunk
  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(bufferSize - 8, 4);
  buffer.write('WAVE', 8);

  // fmt Chunk
  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16); // Subchunk1Size for PCM
  buffer.writeUInt16LE(1, 20);  // AudioFormat 1 = PCM
  buffer.writeUInt16LE(channels, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(byteRate, 28);
  buffer.writeUInt16LE(blockAlign, 32);
  buffer.writeUInt16LE(bitsPerSample, 34);

  // data Chunk
  buffer.write('data', 36);
  buffer.writeUInt32LE(dataSize, 40);

  // Fill with silence / gentle sine tone so samples are realistic
  const sampleOffset = 44;
  for (let i = 0; i < numSamples; i++) {
    // 440 Hz gentle tone
    const t = i / sampleRate;
    const sample = Math.round(Math.sin(2 * Math.PI * 440 * t) * 1000);
    buffer.writeInt16LE(sample, sampleOffset + i * 2);
  }

  return buffer;
}
