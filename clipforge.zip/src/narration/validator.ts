/**
 * ClipForge Narration Validator
 * Validates audio file accessibility, stream metadata, duration coherence, and segment mappings.
 */

import fs from 'node:fs';
import { NarrationArtifact, NarrationSegmentResult } from '../contracts/narration.ts';
import { NarrationValidationResult } from './interfaces.ts';

export function validateNarrationArtifact(
  artifact: NarrationArtifact,
  options: { checkFilesExist?: boolean } = { checkFilesExist: true }
): NarrationValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!artifact) {
    return {
      isValid: false,
      errors: ['Narration artifact is null or undefined.'],
      warnings: [],
    };
  }

  if (!artifact.engine || !['piper', 'elevenlabs', 'mock'].includes(artifact.engine)) {
    errors.push(`Invalid narration engine: "${artifact.engine}". Must be "piper", "elevenlabs", or "mock".`);
  }

  if (!artifact.modelOrVoice || !artifact.modelOrVoice.trim()) {
    errors.push('modelOrVoice is required.');
  }

  if (typeof artifact.totalDurationSeconds !== 'number' || artifact.totalDurationSeconds <= 0) {
    errors.push('totalDurationSeconds must be a positive number.');
  }

  if (!Array.isArray(artifact.segmentResults) || artifact.segmentResults.length === 0) {
    errors.push('Narration artifact must contain at least one segment result.');
    return { isValid: false, errors, warnings };
  }

  let sumDurations = 0;
  const segmentIds = new Set<string>();

  for (let i = 0; i < artifact.segmentResults.length; i++) {
    const seg = artifact.segmentResults[i];
    const prefix = `Segment ${i} (${seg.segmentId || 'unknown'}):`;

    if (!seg.segmentId || !seg.segmentId.trim()) {
      errors.push(`${prefix} Missing segmentId.`);
    } else if (segmentIds.has(seg.segmentId)) {
      errors.push(`${prefix} Duplicate segmentId "${seg.segmentId}".`);
    } else {
      segmentIds.add(seg.segmentId);
    }

    if (!seg.audioFilePath || !seg.audioFilePath.trim()) {
      errors.push(`${prefix} audioFilePath is missing.`);
    } else if (options.checkFilesExist) {
      if (!fs.existsSync(seg.audioFilePath)) {
        errors.push(`${prefix} Audio file does not exist at path: ${seg.audioFilePath}`);
      } else {
        const size = fs.statSync(seg.audioFilePath).size;
        if (size < 44) {
          errors.push(`${prefix} Audio file is truncated or invalid (${size} bytes).`);
        }
      }
    }

    if (typeof seg.actualDurationSeconds !== 'number' || seg.actualDurationSeconds <= 0) {
      errors.push(`${prefix} actualDurationSeconds must be a positive number.`);
    } else {
      sumDurations += seg.actualDurationSeconds;
    }

    if (typeof seg.sampleRateHz !== 'number' || seg.sampleRateHz <= 0) {
      errors.push(`${prefix} sampleRateHz must be greater than zero.`);
    }

    if (typeof seg.channels !== 'number' || seg.channels <= 0) {
      errors.push(`${prefix} channels must be greater than zero.`);
    }
  }

  // Duration consistency check
  const delta = Math.abs(artifact.totalDurationSeconds - sumDurations);
  if (delta > 0.05) {
    warnings.push(
      `Total duration (${artifact.totalDurationSeconds}s) differs from sum of segment durations (${sumDurations.toFixed(2)}s) by ${delta.toFixed(2)}s.`
    );
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
  };
}
