/**
 * ClipForge Piper Narration Provider
 * Invokes local Piper TTS executable to synthesize natural spoken narration.
 * Measures exact duration from generated audio without assuming speaking speed.
 */

import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { INarrationProvider, NarrationSegmentResult } from '../contracts/narration.ts';
import { measureAudioDuration, createMockWavBuffer } from './duration.ts';
import { CacheManager } from '../storage/cache.ts';

export type CommandRunnerFn = (
  command: string,
  args: string[],
  stdinText?: string
) => Promise<{ code: number; stdout: string; stderr: string }>;

export interface PiperProviderConfig {
  binPath?: string;
  modelPath?: string;
  modelsDir?: string;
  cache?: CacheManager;
  commandRunner?: CommandRunnerFn;
  mockMode?: boolean; // If true, generates valid test WAVs for unit testing without Piper installed
}

export class PiperNarrationProvider implements INarrationProvider {
  readonly providerName = 'piper';
  private readonly binPath: string;
  private readonly defaultModel: string;
  private readonly modelsDir?: string;
  private readonly cache?: CacheManager;
  private readonly customRunner?: CommandRunnerFn;
  private readonly mockMode: boolean;

  constructor(config: PiperProviderConfig = {}) {
    this.binPath = config.binPath || process.env.PIPER_BIN_PATH || 'piper';
    this.defaultModel = config.modelPath || process.env.PIPER_DEFAULT_MODEL || 'en_US-lessac-medium';
    this.modelsDir = config.modelsDir || process.env.PIPER_MODELS_DIR;
    this.cache = config.cache;
    this.customRunner = config.commandRunner;
    this.mockMode = config.mockMode ?? (process.env.CLIPFORGE_MOCK_TTS === 'true');
  }

  /**
   * Resolves the full path or name for a voice model.
   */
  resolveModel(voice?: string): string {
    const selected = voice || this.defaultModel;
    if (this.modelsDir && !path.isAbsolute(selected) && !selected.includes('/') && !selected.includes('\\')) {
      const candidate = path.join(this.modelsDir, selected.endsWith('.onnx') ? selected : `${selected}.onnx`);
      if (fs.existsSync(candidate)) {
        return candidate;
      }
    }
    return selected;
  }

  /**
   * Validates whether Piper executable is accessible.
   */
  async validateEngine(): Promise<{ available: boolean; error?: string }> {
    if (this.mockMode) {
      return { available: true };
    }

    try {
      const res = await this.executeProcess(this.binPath, ['--help']);
      if (res.code === 0 || res.stdout.includes('piper') || res.stderr.includes('piper')) {
        return { available: true };
      }
      return { available: false, error: `Piper returned non-zero exit code: ${res.code}` };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      return {
        available: false,
        error: `Piper executable not found or not executable at "${this.binPath}": ${msg}`,
      };
    }
  }

  /**
   * Synthesizes a single segment of spoken text into a WAV file.
   */
  async synthesizeSegment(
    segmentId: string,
    text: string,
    outputFilePath: string,
    options: {
      voice?: string;
      speed?: number;
      volume?: number;
    } = {}
  ): Promise<NarrationSegmentResult> {
    const cleanText = (text || '').trim();
    if (!cleanText) {
      throw new Error(`Cannot synthesize segment ${segmentId}: Narration text is empty.`);
    }

    const voiceModel = this.resolveModel(options.voice);
    const speed = options.speed ?? 1.0;

    // Check segment cache if CacheManager is available
    const cacheKey = this.cache?.generateKey('narration_audio', {
      text: cleanText,
      voice: voiceModel,
      speed,
    });

    // Ensure output directory exists
    const dir = path.dirname(outputFilePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    // Check if cached audio exists and can be reused
    if (this.cache && cacheKey) {
      const cached = await this.cache.get<{ audioHex: string; metadata: NarrationSegmentResult }>(cacheKey);
      if (cached && cached.audioHex) {
        fs.writeFileSync(outputFilePath, Buffer.from(cached.audioHex, 'hex'));
        const meta = await measureAudioDuration(outputFilePath);
        return {
          segmentId,
          audioFilePath: outputFilePath,
          audioFormat: 'wav',
          sampleRateHz: meta.sampleRateHz,
          channels: meta.channels,
          actualDurationSeconds: meta.durationSeconds,
        };
      }
    }

    // If mock mode is enabled or Piper is mocked
    if (this.mockMode) {
      // Generate a realistic WAV file with accurate duration proportional to text length
      const wordCount = cleanText.split(/\s+/).length;
      // Natural speaking rate ~ 2.4 words per second, adjusted by speed
      const realisticDuration = Math.max(1.5, Number((wordCount / (2.4 * speed)).toFixed(3)));
      const wavBuffer = createMockWavBuffer(realisticDuration, 22050, 1, 16);
      fs.writeFileSync(outputFilePath, wavBuffer);

      const meta = await measureAudioDuration(outputFilePath);
      const result: NarrationSegmentResult = {
        segmentId,
        audioFilePath: outputFilePath,
        audioFormat: 'wav',
        sampleRateHz: meta.sampleRateHz,
        channels: meta.channels,
        actualDurationSeconds: meta.durationSeconds,
      };

      if (this.cache && cacheKey) {
        await this.cache.set('narration_audio', cacheKey, {
          audioHex: wavBuffer.toString('hex'),
          metadata: result,
        });
      }

      return result;
    }

    // Execute real Piper
    const args = ['--model', voiceModel, '--output_file', outputFilePath];
    if (options.speed && options.speed !== 1.0) {
      // Piper uses --length_scale where 1.0 / speed adjusts rate
      args.push('--length_scale', (1.0 / options.speed).toFixed(2));
    }

    const { code, stderr } = await this.executeProcess(this.binPath, args, cleanText);

    if (code !== 0) {
      throw new Error(`Piper synthesis failed for segment ${segmentId} (exit code ${code}): ${stderr.trim()}`);
    }

    if (!fs.existsSync(outputFilePath)) {
      throw new Error(`Piper synthesis reported success but output file does not exist: ${outputFilePath}`);
    }

    const stat = fs.statSync(outputFilePath);
    if (stat.size < 44) {
      throw new Error(`Piper output audio file is empty or corrupted: ${outputFilePath} (${stat.size} bytes)`);
    }

    // Measure exact actual audio duration from the resulting WAV file
    const audioMeta = await measureAudioDuration(outputFilePath);

    const result: NarrationSegmentResult = {
      segmentId,
      audioFilePath: outputFilePath,
      audioFormat: 'wav',
      sampleRateHz: audioMeta.sampleRateHz,
      channels: audioMeta.channels,
      actualDurationSeconds: audioMeta.durationSeconds,
    };

    // Cache the synthesized audio buffer for deterministic reuse
    if (this.cache && cacheKey) {
      const fileData = fs.readFileSync(outputFilePath);
      await this.cache.set('narration_audio', cacheKey, {
        audioHex: fileData.toString('hex'),
        metadata: result,
      });
    }

    return result;
  }

  /**
   * Synthesizes multiple segments in sequential order.
   */
  async synthesizeBatch(
    segments: Array<{ segmentId: string; text: string; outputFilePath: string }>,
    options: { voice?: string; speed?: number } = {}
  ): Promise<NarrationSegmentResult[]> {
    const results: NarrationSegmentResult[] = [];
    for (const seg of segments) {
      const res = await this.synthesizeSegment(seg.segmentId, seg.text, seg.outputFilePath, options);
      results.push(res);
    }
    return results;
  }

  private async executeProcess(
    bin: string,
    args: string[],
    stdinText?: string
  ): Promise<{ code: number; stdout: string; stderr: string }> {
    if (this.customRunner) {
      return this.customRunner(bin, args, stdinText);
    }

    return new Promise((resolve, reject) => {
      const proc = spawn(bin, args, {
        stdio: ['pipe', 'pipe', 'pipe'],
      });

      let stdout = '';
      let stderr = '';

      proc.stdout.on('data', (d) => {
        stdout += d.toString();
      });

      proc.stderr.on('data', (d) => {
        stderr += d.toString();
      });

      proc.on('error', (err) => {
        reject(err);
      });

      proc.on('close', (code) => {
        resolve({
          code: code ?? -1,
          stdout,
          stderr,
        });
      });

      if (stdinText !== undefined) {
        proc.stdin.write(stdinText);
        proc.stdin.end();
      }
    });
  }
}
