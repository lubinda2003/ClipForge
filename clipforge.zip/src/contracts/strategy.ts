/**
 * ClipForge Content Strategy Contracts
 * High-retention narrative framing and strategic architecture.
 */

export interface HookStrategy {
  hookText: string;
  hookType: 'curiosity_gap' | 'bold_claim' | 'shocking_stat' | 'contrarian' | 'relatable_pain_point';
  visualCue: string;
  durationTargetSeconds: number; // e.g. 2.5 - 4.5 seconds
}

export interface RetentionMechanism {
  timestampTargetSeconds?: number;
  mechanism: 'pattern_interrupt' | 'curiosity_loop_open' | 'curiosity_loop_close' | 'pacing_shift' | 'key_takeaway';
  description: string;
}

export interface ContentStrategyArtifact {
  jobId?: string;
  createdAt?: string;
  topic: string;
  format: 'short' | 'long';
  targetAudience: {
    primarySegment: string;
    familiarityLevel: 'beginner' | 'intermediate' | 'expert';
    primaryMotivation: string;
  };
  angle: {
    coreThesis: string;
    whyNow: string;
    contrarianOrUniquePerspective: string;
  };
  hook: HookStrategy;
  titleConcepts: string[];
  narrativeStructure: {
    actOrSection: string;
    objective: string;
    approxPercentageOfVideo: number;
  }[];
  emotionalTriggers: string[];
  retentionPlan: RetentionMechanism[];
  callToAction?: {
    type: 'comment_prompt' | 'subscribe' | 'share' | 'none';
    promptText: string;
  };
  estimatedDurationRangeSeconds: {
    min: number;
    max: number;
    target: number;
  };
}
