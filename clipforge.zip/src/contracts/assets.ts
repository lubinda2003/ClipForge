/**
 * ClipForge Audio Asset Library Contracts
 * Curated reusable background music and SFX assets stored in R2 / local cache.
 */

export type MusicCategory =
  | 'energetic'
  | 'cinematic'
  | 'documentary'
  | 'suspense'
  | 'technology'
  | 'inspirational'
  | 'neutral';

export type SfxCategory =
  | 'whoosh'
  | 'impact'
  | 'riser'
  | 'hit'
  | 'transition'
  | 'click'
  | 'glitch';

export interface AudioAssetMetadata {
  assetId: string;
  filename: string;
  title?: string;
  type: 'music' | 'sfx';
  category: MusicCategory | SfxCategory;
  mood: string; // e.g., "dark", "uplifting", "subtle", "dramatic"
  energyLevel: 'low' | 'medium' | 'high';
  durationSeconds: number;
  bpm?: number;
  license: string; // e.g., "CC0", "Royalty-Free", "Purchased Commercial"
  source: string; // Source repository or catalog
  commercialUsePermitted: boolean;
  attributionRequired: boolean;
  attributionText?: string;
  r2Path: string; // e.g. "assets/music/cinematic/epic_build_01.mp3"
  checksumSha256: string;
  loopable?: boolean;
  introDurationSeconds?: number;
  outroDurationSeconds?: number;
  peakDb?: number;
  integratedLufs?: number;
  tags?: string[];
  tempo?: 'slow' | 'medium' | 'fast';
  description?: string;
}

export interface SelectedAudioAsset {
  purpose: 'background_music' | 'sfx';
  asset: AudioAssetMetadata;
  localPath: string;
  targetTimestampSeconds: number;
  targetDurationSeconds: number;
  volumeLevel: number; // 0.0 to 1.0 (e.g. 0.12 for background music during narration)
  fadeInSeconds?: number;
  fadeOutSeconds?: number;
  associatedSceneId?: string;
  score?: number;
  loopCount?: number;
}

export interface AssetsArtifact {
  jobId?: string;
  createdAt?: string;
  musicTrack?: SelectedAudioAsset;
  musicTracks?: SelectedAudioAsset[];
  sfxTracks: SelectedAudioAsset[];
  attributionsRequired: string[];
  warnings?: string[];
}
