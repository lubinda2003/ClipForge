/**
 * ClipForge Scripting Contracts
 * High-retention narrative script broken into spoken narration segments and visual intent.
 */

export interface ScriptSegment {
  segmentId: string;
  sectionIndex: number;
  sectionName: string; // e.g., "Hook", "Problem", "Context", "Point 1", "Payoff"
  narrationText: string; // Text to be spoken by Piper TTS
  estimatedDurationSeconds: number; // Approximate, overridden once synthesized
  emphasisKeywords: string[]; // Words to visually highlight in captions
  visualIntentDescription: string; // Guidance for Scene Planner & B-roll selector
  onScreenText?: {
    primaryText: string;
    secondaryText?: string;
    intent: 'hook' | 'statistic' | 'takeaway' | 'lower_third' | 'chapter_title';
  };
  sourceReference?: string;
  verificationRequired?: boolean;
}

export interface ChapterMetadata {
  chapterIndex: number;
  title: string;
  startSegmentId: string;
}

export interface ScriptArtifact {
  jobId?: string;
  createdAt?: string;
  title: string;
  topic: string;
  format: 'short' | 'long';
  totalWordCount: number;
  estimatedTotalDurationSeconds: number;
  segments: ScriptSegment[];
  chapters?: ChapterMetadata[]; // Specifically used for long-form videos
}
