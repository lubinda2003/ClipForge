/**
 * ClipForge Timeline & Editing Contracts
 * Multi-track timeline model with retention optimization, transitions, ducking, and safe zone text overlays.
 */

import { VideoFormat, SafeZone, AspectRatio } from './common.ts';

export type TransitionType =
  | 'cut'
  | 'crossfade'
  | 'dip_to_black'
  | 'zoom_in'
  | 'slide_left'
  | 'glitch';

export type MotionEffect =
  | 'none'
  | 'ken_burns_zoom_in'
  | 'ken_burns_zoom_out'
  | 'slow_pan_right'
  | 'slow_pan_left';

export interface VideoClipElement {
  elementId: string;
  sceneId: string;
  sourceFilePath: string;
  startTimelineSeconds: number;
  durationSeconds: number;
  sourceTrimStartSeconds: number;
  motionEffect: MotionEffect;
  transitionIn?: {
    type: TransitionType;
    durationSeconds: number;
  };
  transitionOut?: {
    type: TransitionType;
    durationSeconds: number;
  };
  cropOrScale: {
    scaleMode: 'fit' | 'fill' | 'smart_center_crop';
    aspectRatio: AspectRatio;
  };
}

export interface NarrationClipElement {
  elementId: string;
  segmentId: string;
  audioFilePath: string;
  startTimelineSeconds: number;
  durationSeconds: number;
  volume: number; // 1.0 default
}

export interface AudioClipElement {
  elementId: string;
  type: 'music' | 'sfx';
  audioFilePath: string;
  startTimelineSeconds: number;
  durationSeconds: number;
  volume: number;
  loop?: boolean;
  duckingEnvelope?: Array<{
    timestampSeconds: number;
    volumeMultiplier: number;
  }>;
  fadeInSeconds?: number;
  fadeOutSeconds?: number;
}

export interface TextOverlayElement {
  elementId: string;
  sceneId?: string;
  primaryText: string;
  highlightWords?: string[];
  styleVariant: 'hero_hook' | 'bold_caption' | 'lower_third' | 'statistic_card' | 'chapter_title';
  positioning: {
    horizontalAlign: 'center' | 'left' | 'right';
    verticalAlign: 'center' | 'top' | 'bottom';
    safeZoneMargins: SafeZone;
  };
  startTimelineSeconds: number;
  durationSeconds: number;
  inAnimation?: 'fade' | 'pop' | 'typewriter' | 'none';
  outAnimation?: 'fade' | 'none';
}

export interface TimelineArtifact {
  jobId?: string;
  createdAt?: string;
  format: VideoFormat;
  aspectRatio: AspectRatio;
  totalDurationSeconds: number;
  tracks: {
    video: VideoClipElement[];
    narration: NarrationClipElement[];
    music: AudioClipElement[];
    sfx: AudioClipElement[];
    textOverlays: TextOverlayElement[];
  };
  retentionAnnotations: Array<{
    timestampSeconds: number;
    event: 'hook' | 'pattern_interrupt' | 'payoff' | 'sfx_accent' | 'pacing_change';
    description: string;
  }>;
  safeZone?: SafeZone;
  metadata?: Record<string, unknown>;
}
