/**
 * ClipForge Rendering Contracts
 * Profiles and FFmpeg execution parameters for Short-Form (9:16) and Long-Form (16:9).
 */

import { VideoFormat, Resolution, SafeZone } from './common.ts';
import { TimelineArtifact } from './timeline.ts';

export type RenderStatus =
  | 'pending'
  | 'preparing'
  | 'rendering'
  | 'validating'
  | 'passed'
  | 'completed'
  | 'failed'
  | 'unavailable';

export interface RenderProfile {
  name: string;
  format: VideoFormat;
  resolution: Resolution;
  frameRate: number; // e.g. 30 or 60
  videoCodec: 'libx264' | 'h264_nvenc' | 'hevc';
  audioCodec: 'aac' | 'libmp3lame';
  videoBitrateKbps: number;
  audioBitrateKbps: number;
  pixelFormat: 'yuv420p';
  safeZone: SafeZone;
  crf: number; // Constant Rate Factor (18 - 23)
  preset: 'ultrafast' | 'fast' | 'medium' | 'slow';
  subtitlesBurnIn: boolean;
}

export const SHORT_FORM_PROFILE: RenderProfile = {
  name: 'short_vertical_1080x1920',
  format: 'short',
  resolution: { width: 1080, height: 1920 },
  frameRate: 30,
  videoCodec: 'libx264',
  audioCodec: 'aac',
  videoBitrateKbps: 6000,
  audioBitrateKbps: 192,
  pixelFormat: 'yuv420p',
  safeZone: {
    topPercent: 15,    // Platform top bar / search icon
    bottomPercent: 20, // TikTok/Reels description, audio bar
    leftPercent: 8,    // Left padding
    rightPercent: 18,  // TikTok/Reels right action icons (like, comment, bookmark, share)
  },
  crf: 20,
  preset: 'fast',
  subtitlesBurnIn: true,
};

export const LONG_FORM_PROFILE: RenderProfile = {
  name: 'long_horizontal_1920x1080',
  format: 'long',
  resolution: { width: 1920, height: 1080 },
  frameRate: 30,
  videoCodec: 'libx264',
  audioCodec: 'aac',
  videoBitrateKbps: 10000,
  audioBitrateKbps: 256,
  pixelFormat: 'yuv420p',
  safeZone: {
    topPercent: 8,
    bottomPercent: 10, // YouTube progress bar & player controls
    leftPercent: 8,
    rightPercent: 8,
  },
  crf: 19,
  preset: 'medium',
  subtitlesBurnIn: true,
};

export interface RenderJobRequest {
  jobId: string;
  timelineArtifactPath?: string;
  timeline?: TimelineArtifact;
  profile?: RenderProfile;
  outputFilePath?: string;
  tempDirectory?: string;
}

export type RenderRequest = RenderJobRequest;

export interface RenderJobProgress {
  jobId: string;
  stage: 'prepare_assets' | 'generate_filters' | 'encode_pass' | 'mux_audio' | 'complete';
  percentage: number;
  currentFps?: number;
  estimatedTimeRemainingSeconds?: number;
}

export type RenderProgress = RenderJobProgress;

export interface RenderError {
  code: string;
  message: string;
  stage?: string;
  assetId?: string;
  assetType?: string;
  expectedPath?: string;
  sceneOrTrack?: string;
  details?: Record<string, unknown>;
}

export interface RenderValidationResult {
  jobId: string;
  status: 'passed' | 'failed';
  output: {
    path: string;
    duration: number;
    width: number;
    height: number;
    fps: number;
    videoCodec?: string;
    audioCodec?: string;
    fileSizeBytes?: number;
  };
  checks: {
    fileExists: boolean;
    nonEmpty: boolean;
    containerValid: boolean;
    videoStreamValid: boolean;
    audioStreamValid: boolean;
    dimensionsValid: boolean;
    durationValid: boolean;
    fpsValid?: boolean;
    videoCodecValid?: boolean;
    audioCodecValid?: boolean;
  };
  warnings: string[];
  errors: string[];
}

export interface RenderJob {
  jobId: string;
  status: RenderStatus;
  profile: RenderProfile;
  timelineArtifactPath?: string;
  outputPath: string;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  progress?: RenderProgress;
  error?: RenderError;
}

export interface RenderResult {
  jobId: string;
  status: 'passed' | 'failed' | 'unavailable' | 'completed';
  inputTimeline: string | TimelineArtifact;
  outputPath: string;
  outputFormat: VideoFormat;
  duration: number;
  width: number;
  height: number;
  fps: number;
  videoCodec: string;
  audioCodec: string;
  fileSize: number;
  renderTime: number; // in seconds
  warnings: string[];
  errors: string[];
  validation: RenderValidationResult;

  // Backward compatibility fields with RenderJobResult
  outputFilePath: string;
  actualDurationSeconds: number;
  fileSizeBytes: number;
  resolution: Resolution;
  encodingTimeSeconds: number;
  ffmpegLogSummary: string;
}

export type RenderJobResult = RenderResult;

export interface RenderArtifact {
  jobId: string;
  createdAt: string;
  timelineInput: string;
  renderProfile: RenderProfile;
  outputPath: string;
  renderStatus: 'passed' | 'failed' | 'unavailable' | 'completed';
  actualDuration: number;
  encodingInformation: {
    videoCodec: string;
    audioCodec: string;
    width: number;
    height: number;
    fps: number;
    crf: number;
    preset: string;
    bitrateKbps: number;
    renderTimeSeconds: number;
  };
  validationResult: RenderValidationResult;
  warnings: string[];
  errors: string[];
}
