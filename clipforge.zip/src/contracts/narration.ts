/**
 * ClipForge Narration Contracts
 * Abstraction for TTS engines with Piper TTS as primary local engine.
 */

export interface WordTimestamp {
  word: string;
  startSeconds: number;
  endSeconds: number;
}

export interface NarrationSegmentResult {
  segmentId: string;
  audioFilePath: string; // Path to generated WAV/PCM audio
  audioFormat: 'wav' | 'pcm' | 'mp3';
  sampleRateHz: number;
  channels: number;
  actualDurationSeconds: number; // Measured accurately via ffprobe
  wordTimestamps?: WordTimestamp[];
}

export interface NarrationArtifact {
  jobId?: string;
  createdAt?: string;
  scriptReference?: string;
  engine: 'piper' | 'elevenlabs' | 'mock';
  modelOrVoice: string;
  totalDurationSeconds: number;
  segmentResults: NarrationSegmentResult[];
  combinedAudioPath?: string; // Optional merged track
  metadata?: {
    sampleRateHz?: number;
    channels?: number;
    synthesizedAt?: string;
    cacheHits?: number;
    providerStatus?: string;
  };
}

/**
 * Provider interface: allows Piper TTS now and ElevenLabs later without redesign
 */
export interface INarrationProvider {
  readonly providerName: string;
  synthesizeSegment(
    segmentId: string,
    text: string,
    outputFilePath: string,
    options?: {
      voice?: string;
      speed?: number;
      volume?: number;
    }
  ): Promise<NarrationSegmentResult>;

  synthesizeBatch(
    segments: Array<{ segmentId: string; text: string; outputFilePath: string }>,
    options?: { voice?: string; speed?: number }
  ): Promise<NarrationSegmentResult[]>;

  validateEngine(): Promise<{ available: boolean; error?: string }>;
}
