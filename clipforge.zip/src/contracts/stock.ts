/**
 * ClipForge Stock Media & B-Roll Contracts
 * Interfaces for Pexels, Pixabay, and candidate ranking algorithms.
 */

import { AspectRatio, Resolution, VideoFormat } from './common.ts';

export interface StockVideoFile {
  fileId: string;
  url: string;
  width: number;
  height: number;
  aspectRatio: AspectRatio;
  fps?: number;
  quality?: 'hd' | 'uhd' | 'sd';
  fileType: string;
}

export interface StockCandidate {
  candidateId: string;
  source: 'pexels' | 'pixabay' | 'local_cache';
  sourceId: string;
  title?: string;
  tags: string[];
  durationSeconds: number;
  previewUrl: string;
  downloadUrl: string;
  resolution: Resolution;
  originalAspectRatio: AspectRatio;
  files: StockVideoFile[];
  author?: string;
  license: string;
  relevanceScore: number; // 0.0 - 1.0 calculated by ranking model
  rankingBreakdown?: {
    keywordMatch: number;
    resolutionScore: number;
    aspectRatioScore: number;
    durationScore: number;
    continuityScore: number;
    subjectMatch?: number;
    actionMatch?: number;
    formatSuitability?: number;
    cropSuitability?: number;
    repetitionPenalty?: number;
    [key: string]: number | undefined;
  };
  queryUsed?: string;
  orientation?: 'portrait' | 'landscape' | 'square';
}

export interface SceneStockSelection {
  sceneId: string;
  selectedCandidate: StockCandidate;
  selectedFile: StockVideoFile;
  downloadedLocalPath?: string;
  cachedUrl?: string;
  trimStartSeconds: number;
  trimDurationSeconds: number;
  appliedTransform: 'native' | 'center_crop' | 'pan_zoom';
  selectionReason?: string;
  alternativeCandidates?: StockCandidate[];
  validationStatus?: 'valid' | 'invalid' | 'skipped';
  downloadStatus?: 'downloaded' | 'cached' | 'failed' | 'skipped';
}

export interface BrollSelectionArtifact {
  jobId?: string;
  createdAt?: string;
  format?: VideoFormat;
  totalScenes: number;
  selections: SceneStockSelection[];
  cacheStats: {
    cacheHits: number;
    apiQueries: number;
    bytesDownloaded: number;
  };
  unresolvedScenes?: string[];
  metadata?: {
    selectedAt?: string;
    scenesReference?: string;
    providersQueried?: string[];
    selectionStrategy?: string;
  };
}

export interface IStockMediaProvider {
  readonly providerName: string;
  searchVideos(
    query: string,
    options: {
      orientation?: 'portrait' | 'landscape';
      minDurationSeconds?: number;
      minResolution?: Resolution;
      perPage?: number;
      page?: number;
      timeoutMs?: number;
    }
  ): Promise<StockCandidate[]>;
  checkAvailability?(): Promise<{ available: boolean; reason?: string }>;
}
