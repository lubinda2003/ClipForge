/**
 * ClipForge Quality Validation Contracts
 * Automated pre-flight and post-render validation checks.
 */

import { Resolution, AspectRatio } from './common.ts';

export interface ValidationCheckItem {
  checkId: string;
  name: string;
  category: 'container' | 'video_stream' | 'audio_sync' | 'safe_zone' | 'duration' | 'loudness';
  status: 'passed' | 'warning' | 'failed';
  message: string;
  expectedValue?: string | number;
  actualValue?: string | number;
}

export interface VideoQualityValidationReport {
  jobId: string;
  videoFilePath: string;
  isValid: boolean; // True only if zero 'failed' checks
  analyzedAt: string;
  actualMetrics: {
    durationSeconds: number;
    fileSizeBytes: number;
    resolution: Resolution;
    aspectRatio: AspectRatio;
    videoCodec: string;
    audioCodec: string;
    audioSampleRateHz: number;
    audioChannels: number;
    meanVolumeDb?: number;
    maxVolumeDb?: number;
  };
  checks: ValidationCheckItem[];
}
