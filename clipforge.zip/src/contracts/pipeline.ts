/**
 * ClipForge Pipeline & Job Execution Contracts
 * Structured stage artifacts, execution lifecycle, and inspectable outputs.
 */

import { VideoFormat } from './common.ts';
import { ResearchArtifact } from './research.ts';
import { ContentStrategyArtifact } from './strategy.ts';
import { ScriptArtifact } from './script.ts';
import { NarrationArtifact } from './narration.ts';
import { ScenesArtifact } from './scenes.ts';
import { BrollSelectionArtifact } from './stock.ts';
import { AssetsArtifact } from './assets.ts';
import { TimelineArtifact } from './timeline.ts';
import { RenderJobResult } from './rendering.ts';
import { VideoQualityValidationReport } from './validation.ts';

export type PipelineStageName =
  | 'research'
  | 'strategy'
  | 'scripting'
  | 'narration'
  | 'scene_planning'
  | 'broll_selection'
  | 'asset_selection'
  | 'timeline_composition'
  | 'retention_optimization'
  | 'rendering'
  | 'validation';

export interface StageExecutionRecord {
  stage: PipelineStageName;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'skipped';
  startedAt?: string;
  completedAt?: string;
  durationMs?: number;
  artifactPath?: string;
  error?: {
    code: string;
    message: string;
    stack?: string;
    retryable: boolean;
  };
}

export interface PipelineArtifactManifest {
  research?: ResearchArtifact;
  strategy?: ContentStrategyArtifact;
  script?: ScriptArtifact;
  narration?: NarrationArtifact;
  scenes?: ScenesArtifact;
  brollSelection?: BrollSelectionArtifact;
  assets?: AssetsArtifact;
  timeline?: TimelineArtifact;
  rendering?: RenderJobResult;
  validation?: VideoQualityValidationReport;
}

export interface VideoProductionJob {
  jobId: string;
  topic: string;
  format: VideoFormat;
  createdAt: string;
  updatedAt: string;
  status: 'queued' | 'processing' | 'succeeded' | 'failed';
  workingDirectory: string;
  targetDurationCategory?: 'concise' | 'standard' | 'deep_dive';
  stageRecords: Record<PipelineStageName, StageExecutionRecord>;
  finalVideoPath?: string;
  finalArtifactPaths: {
    researchJson?: string;
    strategyJson?: string;
    scriptJson?: string;
    narrationJson?: string;
    scenesJson?: string;
    brollSelectionJson?: string;
    assetsJson?: string;
    timelineJson?: string;
    jobResultJson?: string;
  };
}
