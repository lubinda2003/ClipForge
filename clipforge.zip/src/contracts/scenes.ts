/**
 * ClipForge Scene Planner Contracts
 * Translates spoken narration & strategic intent into concrete visual scene requirements.
 */

import { VideoFormat, AspectRatio } from './common.ts';

export type PreferredVisualType = 'realistic_video' | 'animation' | 'macro' | 'aerial' | 'screen_recording' | 'any';

export type VisualMood = 'energetic' | 'serious' | 'contemplative' | 'tense' | 'inspiring' | 'neutral';

export type SceneType =
  | 'talking_head'
  | 'person_action'
  | 'environment'
  | 'technology'
  | 'product'
  | 'location'
  | 'event'
  | 'abstract_concept'
  | 'data_visual'
  | 'process'
  | 'reaction'
  | 'establishing_shot'
  | 'detail_shot'
  | 'transition_visual';

export type VisualPurpose =
  | 'establish_context'
  | 'illustrate_claim'
  | 'demonstrate_process'
  | 'introduce_entity'
  | 'emphasize_statistic'
  | 'create_emotional_shift'
  | 'provide_pattern_interrupt'
  | 'maintain_visual_continuity'
  | 'support_hook'
  | 'reinforce_payoff';

export interface SceneVisualRequirement {
  sceneId: string;
  correspondingSegmentId: string;
  sequenceOrder: number;
  narrationExcerpt: string;
  visualConcept: string; // The core idea depicted
  searchKeywords: string[]; // Targeted queries for stock APIs
  preferredVisualType: PreferredVisualType;
  desiredDurationSeconds: number; // Derived from narration timing
  targetAspectRatio: AspectRatio;
  format: VideoFormat;
  visualMood: VisualMood;
  visualContinuityGroup?: string; // Group scenes that should share color palette/style
  allowCropping: boolean; // Whether 16:9 stock can be center/smart-cropped to 9:16
  cameraMovementHint?: 'static' | 'slow_pan' | 'slow_zoom' | 'dynamic';
  // Phase 4 timing and semantic metadata
  startTimeSeconds?: number;
  endTimeSeconds?: number;
  sceneType?: SceneType;
  visualPurpose?: VisualPurpose | string;
  visualImportance?: 'critical' | 'high' | 'medium' | 'background';
  pacingIntent?: 'fast' | 'moderate' | 'slow' | 'impact';
  preferredOrientation?: 'portrait' | 'landscape';
  transitionIntent?: string;
  requiredEntities?: string[];
  requiredSubjects?: string[];
  requiredActions?: string[];
  stockFootageAppropriate?: boolean;
  nonStockFallbackNeeded?: boolean;
  alternateQueries?: string[];
}

export type PlannedScene = SceneVisualRequirement;

export interface ScenesArtifact {
  jobId?: string;
  createdAt?: string;
  topic?: string;
  format: VideoFormat;
  totalScenes: number;
  totalDurationSeconds: number;
  scenes: SceneVisualRequirement[];
  metadata?: {
    plannedAt?: string;
    narrationReference?: string;
    scriptReference?: string;
    pacingProfile?: string;
    provider?: string;
  };
}
