/**
 * ClipForge Common Types & Enumerations
 */

export type VideoFormat = 'short' | 'long';

export type AspectRatio = '9:16' | '16:9';

export interface Resolution {
  width: number;
  height: number;
}

export interface TimeRange {
  startSeconds: number;
  endSeconds: number;
  durationSeconds: number;
}

export interface SafeZone {
  topPercent: number;
  bottomPercent: number;
  leftPercent: number;
  rightPercent: number;
}

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}
