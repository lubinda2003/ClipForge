/**
 * ClipForge Research Contracts
 * Distinguishes strictly between OBSERVED DATA and INFERRED STRATEGY.
 */

export interface YouTubePublicVideoMetadata {
  videoId: string;
  title: string;
  description: string;
  publishedAt: string;
  channelId: string;
  channelTitle: string;
  viewCount?: number;
  likeCount?: number;
  commentCount?: number;
  durationIso?: string;
  tags?: string[];
  thumbnailUrl?: string;
}

export interface YouTubePublicChannelMetadata {
  channelId: string;
  title: string;
  subscriberCount?: number;
  videoCount?: number;
  viewCount?: number;
}

export interface ObservedResearchData {
  topic: string;
  collectedAt: string;
  sources: Array<{
    type: 'youtube_public' | 'web_search' | 'news';
    url?: string;
    title: string;
    snippet: string;
    observedDate?: string;
  }>;
  youtubePublicVideos: YouTubePublicVideoMetadata[];
  competitorTitles: string[];
  commonQuestions: string[];
  verifiableFacts: Array<{
    claim: string;
    source: string;
    confidence: 'high' | 'medium' | 'unverified';
  }>;
}

export type TrendStatus = 'emerging' | 'active' | 'stable' | 'declining' | 'insufficient_data';

export interface TrendAssessment {
  trendStatus: TrendStatus;
  confidence: 'high' | 'medium' | 'low';
  evidence: string[];
  analysis: string;
}

export interface VerificationRequirement {
  claim: string;
  reason: string;
  verificationRequired: boolean;
}

export interface InferredResearchInsights {
  audienceInterestLevel: 'niche' | 'broad' | 'viral_potential';
  audienceDemographicsInference?: string;
  saturationLevel: 'underserved' | 'moderate' | 'oversaturated';
  promisingContentAngles: string[];
  contentGapsIdentified: string[];
  potentialHooks: string[];
  trendAssessment?: TrendAssessment;
  curiosityGaps?: string[];
  narrativeAngles?: string[];
  factualRisks?: string[];
  claimsRequiringVerification?: VerificationRequirement[];
}

export interface ResearchArtifact {
  jobId?: string;
  topic: string;
  createdAt: string;
  formatTarget: 'short' | 'long';
  searchQueries?: string[];
  observedData: ObservedResearchData;
  inferredInsights: InferredResearchInsights;
  providerMetadata?: {
    youtubeConfigured: boolean;
    geminiModel: string;
    queriesExecuted: number;
    cacheHits: number;
  };
  errors?: string[];
}
