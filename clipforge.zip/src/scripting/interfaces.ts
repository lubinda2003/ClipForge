/**
 * ClipForge Scripting Interfaces
 * Provider abstractions and engine contracts for script generation.
 */

import { ResearchArtifact } from '../contracts/research.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';
import { ScriptArtifact } from '../contracts/script.ts';
import { VideoFormat } from '../contracts/common.ts';

export interface ScriptOptions {
  jobId?: string;
  format?: VideoFormat;
  targetDurationCategory?: 'concise' | 'standard' | 'deep_dive';
  offline?: boolean;
}

export interface ScriptValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export interface IScriptProvider {
  readonly providerName: string;
  generateScript(
    research: ResearchArtifact,
    strategy: ContentStrategyArtifact,
    options?: ScriptOptions
  ): Promise<ScriptArtifact>;
}

export interface IScriptEngine {
  executeScripting(
    research: ResearchArtifact,
    strategy: ContentStrategyArtifact,
    options?: ScriptOptions
  ): Promise<ScriptArtifact>;
}
