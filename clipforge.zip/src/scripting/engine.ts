/**
 * ClipForge Script Engine
 * Coordinates script generation from research.json and strategy.json, validation, and artifact persistence.
 */

import { ResearchArtifact } from '../contracts/research.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';
import { ScriptArtifact } from '../contracts/script.ts';
import { IScriptEngine, IScriptProvider, ScriptOptions } from './interfaces.ts';
import { GeminiScriptProvider } from './gemini.ts';
import { validateScriptArtifact } from './validator.ts';
import { IStorageProvider } from '../storage/interface.ts';
import { LocalStorageProvider } from '../storage/local.ts';
import { CacheManager } from '../storage/cache.ts';

export interface ScriptEngineDependencies {
  storage?: IStorageProvider;
  cache?: CacheManager;
  scriptProvider?: IScriptProvider;
}

export class ScriptEngine implements IScriptEngine {
  private readonly storage: IStorageProvider;
  private readonly cache: CacheManager;
  private readonly scriptProvider: IScriptProvider;

  constructor(deps: ScriptEngineDependencies = {}) {
    this.storage = deps.storage || new LocalStorageProvider();
    this.cache = deps.cache || new CacheManager(this.storage);
    this.scriptProvider = deps.scriptProvider || new GeminiScriptProvider({ cache: this.cache });
  }

  async executeScripting(
    research: ResearchArtifact,
    strategy: ContentStrategyArtifact,
    options: ScriptOptions = {}
  ): Promise<ScriptArtifact> {
    if (!research || !research.topic) {
      throw new Error('Valid ResearchArtifact is required to generate script.');
    }
    if (!strategy || !strategy.topic) {
      throw new Error('Valid ContentStrategyArtifact is required to generate script.');
    }

    const jobId = options.jobId || strategy.jobId || research.jobId || `job_${Date.now()}`;
    const format = options.format || strategy.format || research.formatTarget || 'short';

    // 1. Generate script via provider
    const script = await this.scriptProvider.generateScript(research, strategy, {
      ...options,
      jobId,
      format,
    });

    // Ensure alignment of core attributes
    script.jobId = jobId;
    script.topic = research.topic;
    script.format = format;

    // 2. Quality validation
    const validation = validateScriptArtifact(script);
    if (!validation.isValid) {
      throw new Error(`Script validation failed:\n${validation.errors.join('\n')}`);
    }

    // 3. Persist script.json
    const artifactKey = `jobs/${jobId}/script.json`;
    if (this.storage instanceof LocalStorageProvider) {
      await this.storage.writeJson('inputs', artifactKey, script);
    }

    return script;
  }
}
