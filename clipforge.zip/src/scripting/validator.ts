/**
 * ClipForge Script Validator
 * Enforces schema compliance, narrative completeness, factual integrity, and rejects fixed-30s anti-patterns.
 */

import { ScriptArtifact, ScriptSegment, ChapterMetadata } from '../contracts/script.ts';
import { ScriptValidationResult } from './interfaces.ts';

export function validateScriptArtifact(script: ScriptArtifact): ScriptValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!script) {
    return {
      isValid: false,
      errors: ['Script artifact is null or undefined.'],
      warnings: [],
    };
  }

  // Basic required fields
  if (!script.title || !script.title.trim()) {
    errors.push('Script title is required and cannot be empty.');
  }

  if (!script.topic || !script.topic.trim()) {
    errors.push('Script topic is required and cannot be empty.');
  }

  if (script.format !== 'short' && script.format !== 'long') {
    errors.push(`Invalid format "${script.format}". Format must be "short" or "long".`);
  }

  // Segments validation
  if (!Array.isArray(script.segments) || script.segments.length === 0) {
    errors.push('Script must contain at least one segment.');
    return { isValid: false, errors, warnings };
  }

  const segmentIds = new Set<string>();
  let calculatedWordCount = 0;
  let calculatedDuration = 0;
  let hasHook = false;
  let hasPayoff = false;

  for (let i = 0; i < script.segments.length; i++) {
    const segment = script.segments[i];
    const prefix = `Segment ${i} (${segment.segmentId || 'unknown'}):`;

    if (!segment.segmentId || !segment.segmentId.trim()) {
      errors.push(`${prefix} Missing segmentId.`);
    } else if (segmentIds.has(segment.segmentId)) {
      errors.push(`${prefix} Duplicate segmentId "${segment.segmentId}".`);
    } else {
      segmentIds.add(segment.segmentId);
    }

    if (typeof segment.sectionIndex !== 'number' || segment.sectionIndex < 0) {
      errors.push(`${prefix} sectionIndex must be a non-negative integer.`);
    }

    if (!segment.sectionName || !segment.sectionName.trim()) {
      errors.push(`${prefix} sectionName is required.`);
    }

    if (!segment.narrationText || !segment.narrationText.trim()) {
      errors.push(`${prefix} narrationText is required and cannot be empty.`);
    } else {
      const words = segment.narrationText.trim().split(/\s+/).length;
      calculatedWordCount += words;
    }

    if (typeof segment.estimatedDurationSeconds !== 'number' || segment.estimatedDurationSeconds <= 0) {
      errors.push(`${prefix} estimatedDurationSeconds must be a positive number.`);
    } else {
      calculatedDuration += segment.estimatedDurationSeconds;
    }

    if (!segment.visualIntentDescription || !segment.visualIntentDescription.trim()) {
      warnings.push(`${prefix} visualIntentDescription is empty.`);
    }

    // Check hook in first segments
    const nameLower = (segment.sectionName || '').toLowerCase();
    if (i === 0 || nameLower.includes('hook') || nameLower.includes('intro')) {
      hasHook = true;
    }

    if (nameLower.includes('payoff') || nameLower.includes('conclusion') || nameLower.includes('verdict') || nameLower.includes('loop')) {
      hasPayoff = true;
    }
  }

  if (!hasHook) {
    errors.push('Script must include an identifiable hook or opening section.');
  }

  if (!hasPayoff && script.segments.length >= 3) {
    warnings.push('Script lacks an explicitly marked payoff or conclusion segment.');
  }

  // Word count & total duration checks
  if (typeof script.totalWordCount !== 'number' || script.totalWordCount <= 0) {
    errors.push('totalWordCount must be a positive number.');
  }

  if (typeof script.estimatedTotalDurationSeconds !== 'number' || script.estimatedTotalDurationSeconds <= 0) {
    errors.push('estimatedTotalDurationSeconds must be a positive number.');
  }

  // Check against arbitrary fixed-30s behavior
  if (script.estimatedTotalDurationSeconds === 30 && script.segments.length <= 2) {
    warnings.push('Script duration is artificially fixed to exactly 30s. ClipForge requires narrative-driven flexible duration.');
  }

  // Long-form chapter integrity
  if (script.format === 'long') {
    if (script.segments.length < 3) {
      errors.push(`Long-form script requires at least 3 segments (found ${script.segments.length}).`);
    }

    if (script.chapters && script.chapters.length > 0) {
      const chapterTitles = new Set<string>();
      for (const chapter of script.chapters) {
        if (!chapter.title || !chapter.title.trim()) {
          errors.push(`Chapter ${chapter.chapterIndex} has an empty title.`);
        }
        if (!chapter.startSegmentId || !segmentIds.has(chapter.startSegmentId)) {
          errors.push(`Chapter "${chapter.title}" references non-existent startSegmentId "${chapter.startSegmentId}".`);
        }
        if (chapterTitles.has(chapter.title)) {
          warnings.push(`Duplicate chapter title "${chapter.title}".`);
        }
        chapterTitles.add(chapter.title);
      }
    }
  } else {
    // Short-form checks
    if (script.segments.length < 2) {
      errors.push('Short-form script requires at least 2 segments (hook + development/payoff).');
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
  };
}
