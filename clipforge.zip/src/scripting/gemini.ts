/**
 * ClipForge Gemini Script Provider
 * Generates structured, high-retention video scripts from research and strategy artifacts.
 * Distinguishes strictly between observed facts and strategic inferences.
 */

import { GoogleGenAI } from '@google/genai';
import { ResearchArtifact } from '../contracts/research.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';
import { ScriptArtifact, ScriptSegment, ChapterMetadata } from '../contracts/script.ts';
import { IScriptProvider, ScriptOptions } from './interfaces.ts';
import { CacheManager } from '../storage/cache.ts';

export interface GeminiScriptConfig {
  apiKey?: string;
  model?: string;
  cache?: CacheManager;
}

export class GeminiScriptProvider implements IScriptProvider {
  readonly providerName = 'gemini_script';
  private readonly apiKey: string;
  private readonly modelName: string;
  private readonly cache?: CacheManager;

  constructor(config: GeminiScriptConfig = {}) {
    this.apiKey = (config.apiKey !== undefined ? config.apiKey : process.env.GEMINI_API_KEY || '').trim();
    this.modelName = config.model || process.env.GEMINI_MODEL || 'gemini-3.6-flash';
    this.cache = config.cache;
  }

  isAvailable(): boolean {
    return Boolean(this.apiKey && this.apiKey.length > 5);
  }

  private redactKey(msg: string): string {
    if (!this.apiKey) return msg;
    return msg.split(this.apiKey).join('[REDACTED]');
  }

  async generateScript(
    research: ResearchArtifact,
    strategy: ContentStrategyArtifact,
    options: ScriptOptions = {}
  ): Promise<ScriptArtifact> {
    const format = options.format || strategy.format || research.formatTarget || 'short';
    const isShort = format === 'short';

    // Deterministic cache key
    const cacheKey = this.cache?.generateKey('gemini_script', {
      topic: research.topic.toLowerCase().trim(),
      format,
      thesis: strategy.angle?.coreThesis || '',
      hookText: strategy.hook?.hookText || '',
    });

    if (this.cache && cacheKey) {
      const cached = await this.cache.get<ScriptArtifact>(cacheKey);
      if (cached) {
        return cached;
      }
    }

    if (!this.isAvailable()) {
      return this.buildHeuristicScript(research, strategy, format, options);
    }

    try {
      const ai = new GoogleGenAI({ apiKey: this.apiKey });

      // Verifiable facts and claims requiring verification
      const verifiableFacts = research.observedData?.verifiableFacts || [];
      const verificationReqs = research.inferredInsights?.claimsRequiringVerification || [];

      const prompt = `You are the Lead Video Scriptwriter for ClipForge, an automated high-retention video production pipeline.
Write a production-ready, spoken narration script based STRICTLY on the provided Research and Content Strategy artifacts.

CRITICAL ARCHITECTURAL RULES:
1. DO NOT RE-RESEARCH. Use only the provided research facts and strategic framing.
2. SPOKEN NARRATION:
   - Must be natural, punchy, conversational, and designed specifically for text-to-speech (Piper TTS).
   - Avoid markdown links, URLs, parentheticals, or unpronounceable characters in "narrationText".
   - Break narration into logical segments (each 3 to 10 seconds of speech).
3. FACTUAL INTEGRITY & ATTRIBUTION:
   - Preserve source citations where available in "sourceReference".
   - If a claim has verification_required: true, DO NOT state it as established fact. Qualify it clearly (e.g., "Preliminary tests suggest...", "Early analysis indicates...") and set "verificationRequired": true on that segment.
   - DO NOT fabricate citations, statistics, quotations, or events.
4. NO FIXED 30-SECOND CONSTRAINT:
   - For SHORT-FORM: Focus on immediate hook (matches strategy hook), rapid information escalation, pattern interrupts, and conclusive payoff. Let the word count and natural delivery dictate duration.
   - For LONG-FORM: Create chaptered multi-act narrative ("chapters" list with startSegmentId), progressive evidence buildup, context, deep explanations, and comprehensive synthesis.
5. VISUAL & RETENTION COUPLING:
   - Provide concrete "visualIntentDescription" for each segment (camera moves, b-roll descriptions, screen graphics).
   - Provide "emphasisKeywords" for captions highlighting.
   - Provide "onScreenText" where impactful.

INPUT TOPIC: "${research.topic}"
FORMAT: ${format}
STRATEGY THESIS: "${strategy.angle?.coreThesis}"
STRATEGY HOOK: "${strategy.hook?.hookText}"
AUDIENCE: "${strategy.targetAudience?.primarySegment}" (Motivation: "${strategy.targetAudience?.primaryMotivation}")
VERIFIABLE FACTS: ${JSON.stringify(verifiableFacts)}
CLAIMS REQUIRING VERIFICATION: ${JSON.stringify(verificationReqs)}
NARRATIVE STRUCTURE: ${JSON.stringify(strategy.narrativeStructure)}
RETENTION PLAN: ${JSON.stringify(strategy.retentionPlan)}

Output a valid JSON object strictly conforming to this schema:
{
  "title": "string (Compelling, accurate title)",
  "topic": "${research.topic}",
  "format": "${format}",
  "totalWordCount": number,
  "estimatedTotalDurationSeconds": number,
  "chapters": ${isShort ? '[]' : '[{ "chapterIndex": 0, "title": "string", "startSegmentId": "seg_001" }]'},
  "segments": [
    {
      "segmentId": "seg_001",
      "sectionIndex": 0,
      "sectionName": "Hook",
      "narrationText": "Exact text spoken by voice",
      "estimatedDurationSeconds": number,
      "emphasisKeywords": ["word1", "word2"],
      "visualIntentDescription": "Exact visual b-roll or animation description",
      "onScreenText": {
        "primaryText": "Key takeaway text",
        "secondaryText": "Optional supporting text",
        "intent": "hook" | "statistic" | "takeaway" | "lower_third" | "chapter_title"
      },
      "sourceReference": "Optional verifiable source citation",
      "verificationRequired": boolean
    }
  ]
}`;

      const response = await ai.models.generateContent({
        model: this.modelName,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.3,
        },
      });

      const responseText = response.text || '{}';
      const parsed = JSON.parse(responseText) as ScriptArtifact;

      const sanitized = this.sanitizeScript(parsed, research, strategy, format, options.jobId);

      if (this.cache && cacheKey) {
        await this.cache.set('gemini_script', cacheKey, sanitized);
      }

      return sanitized;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      throw new Error(this.redactKey(`Gemini script generation failed: ${msg}`));
    }
  }

  private sanitizeScript(
    raw: Partial<ScriptArtifact>,
    research: ResearchArtifact,
    strategy: ContentStrategyArtifact,
    format: 'short' | 'long',
    jobId?: string
  ): ScriptArtifact {
    const rawSegments = Array.isArray(raw.segments) && raw.segments.length > 0
      ? raw.segments
      : this.buildHeuristicSegments(research, strategy, format);

    let totalWords = 0;
    let totalDuration = 0;

    const segments: ScriptSegment[] = rawSegments.map((seg, idx) => {
      const id = seg.segmentId || `seg_${String(idx + 1).padStart(3, '0')}`;
      const text = (seg.narrationText || '').trim();
      const words = text.length > 0 ? text.split(/\s+/).length : 0;
      totalWords += words;

      // Estimate speaking duration: ~150 words per minute => ~2.5 words per second
      const estimatedSec = seg.estimatedDurationSeconds && seg.estimatedDurationSeconds > 0
        ? Number(seg.estimatedDurationSeconds.toFixed(2))
        : Math.max(2.0, Number((words / 2.5).toFixed(2)));

      totalDuration += estimatedSec;

      return {
        segmentId: id,
        sectionIndex: typeof seg.sectionIndex === 'number' ? seg.sectionIndex : idx,
        sectionName: seg.sectionName || (idx === 0 ? 'Hook' : `Section ${idx + 1}`),
        narrationText: text,
        estimatedDurationSeconds: estimatedSec,
        emphasisKeywords: Array.isArray(seg.emphasisKeywords) ? seg.emphasisKeywords : [],
        visualIntentDescription: seg.visualIntentDescription || `Cinematic visual illustrating ${research.topic}`,
        onScreenText: seg.onScreenText || (idx === 0 ? {
          primaryText: strategy.hook?.hookText?.slice(0, 45) || research.topic,
          intent: 'hook',
        } : undefined),
        sourceReference: seg.sourceReference,
        verificationRequired: Boolean(seg.verificationRequired),
      };
    });

    const chapters: ChapterMetadata[] | undefined = format === 'long'
      ? (Array.isArray(raw.chapters) && raw.chapters.length > 0
          ? raw.chapters
          : this.deriveChaptersFromSegments(segments))
      : undefined;

    return {
      jobId: jobId || strategy.jobId || research.jobId,
      createdAt: new Date().toISOString(),
      title: raw.title || strategy.titleConcepts?.[0] || `The Truth About ${research.topic}`,
      topic: research.topic,
      format,
      totalWordCount: totalWords,
      estimatedTotalDurationSeconds: Number(totalDuration.toFixed(2)),
      segments,
      chapters,
    };
  }

  buildHeuristicScript(
    research: ResearchArtifact,
    strategy: ContentStrategyArtifact,
    format: 'short' | 'long',
    options: ScriptOptions = {}
  ): ScriptArtifact {
    const segments = this.buildHeuristicSegments(research, strategy, format);
    let totalWords = 0;
    let totalDuration = 0;

    for (const seg of segments) {
      totalWords += seg.narrationText.split(/\s+/).length;
      totalDuration += seg.estimatedDurationSeconds;
    }

    const chapters: ChapterMetadata[] | undefined = format === 'long'
      ? this.deriveChaptersFromSegments(segments)
      : undefined;

    return {
      jobId: options.jobId || strategy.jobId || research.jobId,
      createdAt: new Date().toISOString(),
      title: strategy.titleConcepts?.[0] || `The Reality of ${research.topic}`,
      topic: research.topic,
      format,
      totalWordCount: totalWords,
      estimatedTotalDurationSeconds: Number(totalDuration.toFixed(2)),
      segments,
      chapters,
    };
  }

  private buildHeuristicSegments(
    research: ResearchArtifact,
    strategy: ContentStrategyArtifact,
    format: 'short' | 'long'
  ): ScriptSegment[] {
    const isShort = format === 'short';
    const topic = research.topic;
    const hookText = strategy.hook?.hookText || `If you think ${topic} is just hype, look closer.`;
    const coreThesis = strategy.angle?.coreThesis || `The real breakthrough in ${topic} is fundamentally changing how the industry operates.`;

    const verifiableFacts = research.observedData?.verifiableFacts || [];
    const firstFact = verifiableFacts[0];
    const factText = firstFact ? firstFact.claim : `Verified benchmarks demonstrate rapid real-world adoption.`;
    const factSource = firstFact ? firstFact.source : undefined;

    const unverifiedClaims = research.inferredInsights?.claimsRequiringVerification || [];
    const hasUnverified = unverifiedClaims.length > 0;
    const unverifiedNote = hasUnverified
      ? `Preliminary reports suggest further exponential scaling, though industry verification remains ongoing.`
      : `While widespread enthusiasm continues, practical validation is the metric that matters.`;

    if (isShort) {
      return [
        {
          segmentId: 'seg_001',
          sectionIndex: 0,
          sectionName: 'Hook',
          narrationText: hookText,
          estimatedDurationSeconds: 3.5,
          emphasisKeywords: [topic, 'hype', 'closer'],
          visualIntentDescription: `Dynamic close-up sequence with bold typography punch-in regarding ${topic}.`,
          onScreenText: {
            primaryText: hookText.length > 40 ? `${hookText.slice(0, 38)}...` : hookText,
            intent: 'hook',
          },
          verificationRequired: false,
        },
        {
          segmentId: 'seg_002',
          sectionIndex: 1,
          sectionName: 'Evidence & Mechanism',
          narrationText: `${coreThesis} Here is the verifiable reality: ${factText}`,
          estimatedDurationSeconds: 8.5,
          emphasisKeywords: ['verifiable', 'reality', 'breakthrough'],
          visualIntentDescription: 'Clean data visualization overlay showing concrete benchmark metrics over live footage.',
          onScreenText: {
            primaryText: 'Verified Data',
            secondaryText: firstFact ? firstFact.source : undefined,
            intent: 'statistic',
          },
          sourceReference: factSource,
          verificationRequired: false,
        },
        {
          segmentId: 'seg_003',
          sectionIndex: 2,
          sectionName: 'Pattern Interrupt & Caveat',
          narrationText: `${unverifiedNote} That distinction changes everything.`,
          estimatedDurationSeconds: 6.5,
          emphasisKeywords: ['distinction', 'everything'],
          visualIntentDescription: 'Rapid cut to split screen comparing speculative claims against proven physical constraints.',
          onScreenText: {
            primaryText: hasUnverified ? 'Preliminary Finding' : 'Key Distinction',
            intent: 'takeaway',
          },
          sourceReference: hasUnverified ? unverifiedClaims[0].claim : undefined,
          verificationRequired: hasUnverified,
        },
        {
          segmentId: 'seg_004',
          sectionIndex: 3,
          sectionName: 'Payoff & Closing',
          narrationText: `The real shift is already happening right in front of us. Pay attention to the infrastructure, not the noise.`,
          estimatedDurationSeconds: 5.5,
          emphasisKeywords: ['infrastructure', 'noise', 'shift'],
          visualIntentDescription: 'Wide cinematic concluding shot fading into looping visual transition.',
          onScreenText: {
            primaryText: 'Watch The Infrastructure',
            intent: 'takeaway',
          },
          verificationRequired: false,
        },
      ];
    }

    // Long-form segments
    return [
      {
        segmentId: 'seg_001',
        sectionIndex: 0,
        sectionName: 'Act 1: The Paradox Hook',
        narrationText: `${hookText} Over the past few months, discussion around ${topic} has reached a fever pitch, yet the critical mechanism remains obscured.`,
        estimatedDurationSeconds: 12.0,
        emphasisKeywords: [topic, 'critical', 'mechanism'],
        visualIntentDescription: 'Fast-paced documentary montage establishing current cultural and technical buzz around the topic.',
        onScreenText: {
          primaryText: `The Truth About ${topic}`,
          intent: 'chapter_title',
        },
        verificationRequired: false,
      },
      {
        segmentId: 'seg_002',
        sectionIndex: 1,
        sectionName: 'Act 2: Foundational Reality',
        narrationText: `To understand where this leads, we must examine what is actually documented. Specifically, ${factText}`,
        estimatedDurationSeconds: 15.0,
        emphasisKeywords: ['documented', 'reality'],
        visualIntentDescription: 'Detailed schematic animation breaking down the core principles with source attribution.',
        onScreenText: {
          primaryText: 'Empirical Evidence',
          secondaryText: factSource,
          intent: 'statistic',
        },
        sourceReference: factSource,
        verificationRequired: false,
      },
      {
        segmentId: 'seg_003',
        sectionIndex: 2,
        sectionName: 'Act 3: The Hidden Bottleneck',
        narrationText: `${coreThesis} Most analysts focus on surface adoption metrics, but the engineering bottleneck reveals where real value concentrates.`,
        estimatedDurationSeconds: 18.0,
        emphasisKeywords: ['bottleneck', 'engineering', 'value'],
        visualIntentDescription: 'Flowchart graphic highlighting resource constraints and structural bottlenecks.',
        onScreenText: {
          primaryText: 'The Structural Bottleneck',
          intent: 'takeaway',
        },
        verificationRequired: false,
      },
      {
        segmentId: 'seg_004',
        sectionIndex: 3,
        sectionName: 'Act 4: Critical Scrutiny & Verification',
        narrationText: `We also have to separate verified breakthroughs from speculative projections. ${unverifiedNote}`,
        estimatedDurationSeconds: 16.0,
        emphasisKeywords: ['projections', 'verification'],
        visualIntentDescription: 'Side-by-side comparative table separating peer-reviewed milestones from speculative roadmap announcements.',
        onScreenText: {
          primaryText: hasUnverified ? 'Pending Independent Verification' : 'Verified vs Speculative',
          intent: 'lower_third',
        },
        sourceReference: hasUnverified ? unverifiedClaims[0].claim : undefined,
        verificationRequired: hasUnverified,
      },
      {
        segmentId: 'seg_005',
        sectionIndex: 4,
        sectionName: 'Act 5: Synthesis & Strategic Verdict',
        narrationText: `When you filter out the superficial speculation, the trajectory is unmistakable. The future of ${topic} belongs to those who build on verified foundations.`,
        estimatedDurationSeconds: 14.0,
        emphasisKeywords: ['trajectory', 'foundations', topic],
        visualIntentDescription: 'High-production cinematic drone footage resolving into summary graphic with central takeaway.',
        onScreenText: {
          primaryText: 'The Strategic Verdict',
          intent: 'takeaway',
        },
        verificationRequired: false,
      },
    ];
  }

  private deriveChaptersFromSegments(segments: ScriptSegment[]): ChapterMetadata[] {
    const chapters: ChapterMetadata[] = [];
    segments.forEach((seg, idx) => {
      if (idx === 0 || seg.sectionName.toLowerCase().startsWith('act') || seg.sectionName.toLowerCase().includes('chapter')) {
        chapters.push({
          chapterIndex: chapters.length,
          title: seg.sectionName,
          startSegmentId: seg.segmentId,
        });
      }
    });
    return chapters;
  }
}
