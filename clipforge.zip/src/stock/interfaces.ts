/**
 * ClipForge Stock Media & B-Roll Interfaces
 */

import { VideoFormat, AspectRatio, Resolution } from '../contracts/common.ts';
import {
  StockCandidate,
  StockVideoFile,
  SceneStockSelection,
  BrollSelectionArtifact,
  IStockMediaProvider,
} from '../contracts/stock.ts';
import { ScenesArtifact, SceneVisualRequirement } from '../contracts/scenes.ts';

export type {
  StockCandidate,
  StockVideoFile,
  SceneStockSelection,
  BrollSelectionArtifact,
  IStockMediaProvider,
};

export interface StockSearchOptions {
  orientation?: 'portrait' | 'landscape' | 'square';
  minDurationSeconds?: number;
  minResolution?: Resolution;
  perPage?: number;
  page?: number;
  timeoutMs?: number;
  signal?: AbortSignal;
}

export interface CandidateRankingWeights {
  keywordMatch: number;
  subjectMatch: number;
  actionMatch: number;
  formatSuitability: number;
  resolutionScore: number;
  durationScore: number;
  cropSuitability: number;
  continuityScore: number;
}

export interface BrollSelectionOptions {
  jobId?: string;
  format?: VideoFormat;
  minRelevanceScore?: number;
  downloadMedia?: boolean;
  outputDir?: string;
  maxCandidatesPerScene?: number;
  maxQueriesPerScene?: number;
  maxResultsPerQuery?: number;
  timeoutMs?: number;
}

export interface IBrollSelectionEngine {
  executeBrollSelection(
    scenes: ScenesArtifact,
    options?: BrollSelectionOptions
  ): Promise<BrollSelectionArtifact>;
}
