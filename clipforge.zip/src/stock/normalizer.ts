/**
 * ClipForge Stock Media Normalizer
 * Transforms vendor-specific API structures (Pexels, Pixabay) into canonical StockCandidate contracts.
 */

import { AspectRatio, Resolution } from '../contracts/common.ts';
import { StockCandidate, StockVideoFile } from '../contracts/stock.ts';

export interface PexelsRawVideoFile {
  id: number | string;
  quality?: string;
  file_type?: string;
  width?: number;
  height?: number;
  fps?: number;
  link: string;
}

export interface PexelsRawVideoItem {
  id: number | string;
  width: number;
  height: number;
  url: string;
  image: string;
  duration: number;
  user?: {
    id?: number | string;
    name?: string;
    url?: string;
  };
  video_files?: PexelsRawVideoFile[];
  video_pictures?: Array<{ id: number | string; picture: string; nr: number }>;
  tags?: Array<{ id?: number | string; name: string } | string>;
}

export interface PixabayRawVideoItem {
  id: number | string;
  pageURL?: string;
  type?: string;
  tags?: string;
  duration?: number;
  picture_id?: string;
  user?: string;
  videos?: {
    large?: { url: string; width: number; height: number; size?: number };
    medium?: { url: string; width: number; height: number; size?: number };
    small?: { url: string; width: number; height: number; size?: number };
    tiny?: { url: string; width: number; height: number; size?: number };
  };
}

export function normalizePexelsVideo(
  raw: PexelsRawVideoItem,
  queryUsed: string
): StockCandidate {
  const sourceId = String(raw.id);
  const candidateId = `pexels_${sourceId}`;

  const files: StockVideoFile[] = [];
  if (Array.isArray(raw.video_files)) {
    for (const f of raw.video_files) {
      if (!f.link) continue;
      const w = Number(f.width) || raw.width || 1920;
      const h = Number(f.height) || raw.height || 1080;
      const aspect: AspectRatio = h > w ? '9:16' : '16:9';
      files.push({
        fileId: String(f.id || `f_${files.length}`),
        url: f.link,
        width: w,
        height: h,
        aspectRatio: aspect,
        fps: typeof f.fps === 'number' ? f.fps : undefined,
        quality: f.quality === 'uhd' ? 'uhd' : f.quality === 'hd' ? 'hd' : 'sd',
        fileType: f.file_type || 'video/mp4',
      });
    }
  }

  // Sort files by resolution descending (highest quality first)
  files.sort((a, b) => b.width * b.height - a.width * a.height);

  const mainWidth = Number(raw.width) || 1920;
  const mainHeight = Number(raw.height) || 1080;
  const originalAspectRatio: AspectRatio = mainHeight > mainWidth ? '9:16' : '16:9';
  const orientation: 'portrait' | 'landscape' | 'square' =
    mainHeight > mainWidth ? 'portrait' : mainHeight === mainWidth ? 'square' : 'landscape';

  const bestFile = files[0];
  const downloadUrl = bestFile ? bestFile.url : '';
  const previewUrl = raw.image || (raw.video_pictures?.[0]?.picture) || '';

  // Normalize tags
  const tags: string[] = [];
  if (Array.isArray(raw.tags)) {
    for (const t of raw.tags) {
      if (typeof t === 'string') tags.push(t.toLowerCase().trim());
      else if (t && typeof t.name === 'string') tags.push(t.name.toLowerCase().trim());
    }
  }
  // Add query terms if tags are sparse
  if (tags.length === 0 && queryUsed) {
    tags.push(...queryUsed.toLowerCase().split(/\s+/).filter(w => w.length > 2));
  }

  const resolution: Resolution = {
    width: bestFile?.width || mainWidth,
    height: bestFile?.height || mainHeight,
  };

  return {
    candidateId,
    source: 'pexels',
    sourceId,
    title: `Pexels Video ${sourceId}`,
    tags,
    durationSeconds: Number(raw.duration) || 5,
    previewUrl,
    downloadUrl,
    resolution,
    originalAspectRatio,
    files,
    author: raw.user?.name || 'Pexels Creator',
    license: 'Pexels License (Free to use)',
    relevanceScore: 0.5,
    queryUsed,
    orientation,
  };
}

export function normalizePixabayVideo(
  raw: PixabayRawVideoItem,
  queryUsed: string
): StockCandidate {
  const sourceId = String(raw.id);
  const candidateId = `pixabay_${sourceId}`;

  const files: StockVideoFile[] = [];
  if (raw.videos) {
    const qualities: Array<'large' | 'medium' | 'small' | 'tiny'> = ['large', 'medium', 'small', 'tiny'];
    for (const q of qualities) {
      const v = raw.videos[q];
      if (v && v.url) {
        const aspect: AspectRatio = v.height > v.width ? '9:16' : '16:9';
        files.push({
          fileId: `pixabay_${sourceId}_${q}`,
          url: v.url,
          width: v.width,
          height: v.height,
          aspectRatio: aspect,
          quality: q === 'large' ? 'uhd' : q === 'medium' ? 'hd' : 'sd',
          fileType: 'video/mp4',
        });
      }
    }
  }

  files.sort((a, b) => b.width * b.height - a.width * a.height);
  const bestFile = files[0];

  const w = bestFile?.width || 1920;
  const h = bestFile?.height || 1080;
  const originalAspectRatio: AspectRatio = h > w ? '9:16' : '16:9';
  const orientation: 'portrait' | 'landscape' | 'square' =
    h > w ? 'portrait' : h === w ? 'square' : 'landscape';

  const tags: string[] = typeof raw.tags === 'string'
    ? raw.tags.split(',').map(t => t.trim().toLowerCase()).filter(Boolean)
    : [];

  const previewUrl = raw.picture_id
    ? `https://i.vimeocdn.com/video/${raw.picture_id}_640x360.jpg`
    : '';

  return {
    candidateId,
    source: 'pixabay',
    sourceId,
    title: `Pixabay Video ${sourceId}`,
    tags,
    durationSeconds: Number(raw.duration) || 5,
    previewUrl,
    downloadUrl: bestFile?.url || '',
    resolution: { width: w, height: h },
    originalAspectRatio,
    files,
    author: raw.user || 'Pixabay Creator',
    license: 'Pixabay Content License (Free for commercial use)',
    relevanceScore: 0.5,
    queryUsed,
    orientation,
  };
}
