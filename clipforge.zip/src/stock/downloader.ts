/**
 * ClipForge Media Downloader
 * Downloads remote stock media assets with streaming, atomic moves, media validation, and retries.
 */

import fs from 'node:fs';
import path from 'node:path';
import { StockError } from './errors.ts';
import { MediaValidator, MediaValidationResult } from './validator.ts';

export interface MediaDownloaderConfig {
  fetchFn?: typeof fetch;
  timeoutMs?: number;
  retries?: number;
  validator?: { validateMediaFile: (filePath: string) => Promise<MediaValidationResult> };
}

export class MediaDownloader {
  private readonly fetchFn: typeof fetch;
  private readonly timeoutMs: number;
  private readonly retries: number;
  private readonly validator?: { validateMediaFile: (filePath: string) => Promise<MediaValidationResult> };

  constructor(config: MediaDownloaderConfig = {}) {
    this.fetchFn = config.fetchFn || globalThis.fetch;
    this.timeoutMs = config.timeoutMs ?? 30000;
    this.retries = config.retries ?? 2;
    this.validator = config.validator;
  }

  /**
   * Downloads a media URL to destinationPath atomically and validates it.
   */
  async downloadMedia(
    url: string,
    destinationPath: string,
    options: { timeoutMs?: number; skipIfValid?: boolean } = {}
  ): Promise<{ localPath: string; bytes: number }> {
    if (!url) {
      throw new StockError('DOWNLOAD_FAILED', 'Download URL is empty.');
    }

    const validator = this.validator || MediaValidator;

    // If file already exists and is valid, reuse it (cache hit)
    if (options.skipIfValid !== false && fs.existsSync(destinationPath)) {
      const check = await validator.validateMediaFile(destinationPath);
      if (check.isValid) {
        const stats = fs.statSync(destinationPath);
        return { localPath: destinationPath, bytes: stats.size };
      }
    }

    const dir = path.dirname(destinationPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    const tempPath = `${destinationPath}.tmp_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const maxAttempts = 1 + this.retries;
    let lastError: Error | null = null;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), options.timeoutMs ?? this.timeoutMs);

      try {
        const response = await this.fetchFn(url, {
          method: 'GET',
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          throw new StockError(
            'DOWNLOAD_FAILED',
            `Failed to download media file: HTTP ${response.status}`,
            { details: { status: response.status } }
          );
        }

        // Stream or buffer to temp file
        if (response.body && typeof (response.body as any).getReader === 'function') {
          const reader = (response.body as any).getReader();
          const writeStream = fs.createWriteStream(tempPath);

          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              if (value) {
                writeStream.write(Buffer.from(value));
              }
            }
          } finally {
            await new Promise((resolve) => writeStream.end(resolve));
          }
        } else {
          const arrayBuf = await response.arrayBuffer();
          fs.writeFileSync(tempPath, Buffer.from(arrayBuf));
        }

        // Validate downloaded file
        const validation = await validator.validateMediaFile(tempPath);
        if (!validation.isValid) {
          if (fs.existsSync(tempPath)) {
            fs.unlinkSync(tempPath);
          }
          throw new StockError(
            'MEDIA_VALIDATION_FAILED',
            `Downloaded media failed validation: ${validation.error}`,
            { details: { validationError: validation.error } }
          );
        }

        // Atomically rename temp file to destination
        fs.renameSync(tempPath, destinationPath);
        const stats = fs.statSync(destinationPath);

        return { localPath: destinationPath, bytes: stats.size };
      } catch (err: unknown) {
        clearTimeout(timeoutId);

        // Cleanup temp file on failure
        if (fs.existsSync(tempPath)) {
          try {
            fs.unlinkSync(tempPath);
          } catch {
            // ignore
          }
        }

        if (err instanceof StockError) {
          lastError = err;
        } else {
          const isAbort = (err as { name?: string }).name === 'AbortError';
          lastError = new StockError(
            isAbort ? 'STOCK_TIMEOUT' : 'DOWNLOAD_FAILED',
            `Download failed on attempt ${attempt}: ${(err as Error).message}`
          );
        }

        if (attempt < maxAttempts) {
          await new Promise(r => setTimeout(r, 300 * Math.pow(2, attempt)));
        }
      }
    }

    throw lastError || new StockError('DOWNLOAD_FAILED', 'Download failed after all retry attempts.');
  }
}
