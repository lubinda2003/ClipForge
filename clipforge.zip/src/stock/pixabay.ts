/**
 * ClipForge Pixabay Stock Media Provider
 * Integrates with Pixabay Video API with optional availability and graceful degradation.
 */

import { StockCandidate, IStockMediaProvider } from '../contracts/stock.ts';
import { StockSearchOptions } from './interfaces.ts';
import { normalizePixabayVideo, PixabayRawVideoItem } from './normalizer.ts';
import { StockError } from './errors.ts';
import { CacheManager } from '../storage/cache.ts';

export interface PixabayProviderConfig {
  apiKey?: string;
  cache?: CacheManager;
  fetchFn?: typeof fetch;
  timeoutMs?: number;
  retries?: number;
}

export class PixabayStockProvider implements IStockMediaProvider {
  readonly providerName = 'pixabay';
  private readonly apiKey: string;
  private readonly cache?: CacheManager;
  private readonly fetchFn: typeof fetch;
  private readonly timeoutMs: number;
  private readonly retries: number;

  constructor(config: PixabayProviderConfig = {}) {
    this.apiKey = config.apiKey || process.env.PIXABAY_API_KEY || '';
    this.cache = config.cache;
    this.fetchFn = config.fetchFn || globalThis.fetch;
    this.timeoutMs = config.timeoutMs ?? 10000;
    this.retries = config.retries ?? 2;
  }

  async checkAvailability(): Promise<{ available: boolean; reason?: string }> {
    if (!this.apiKey || this.apiKey.trim().length === 0) {
      return { available: false, reason: 'missing_api_key' };
    }
    return { available: true };
  }

  async searchVideos(query: string, options: StockSearchOptions = {}): Promise<StockCandidate[]> {
    if (!this.apiKey || this.apiKey.trim().length === 0) {
      // Pixabay is an optional secondary provider
      return [];
    }

    const cleanQuery = query.trim();
    if (!cleanQuery) {
      return [];
    }

    const perPage = options.perPage ?? 10;
    const page = options.page ?? 1;

    // Cache lookup
    const cacheKey = this.cache?.generateKey('pixabay_search', {
      query: cleanQuery,
      perPage,
      page,
    });

    if (this.cache && cacheKey) {
      const cached = await this.cache.get<StockCandidate[]>(cacheKey);
      if (cached) {
        return cached;
      }
    }

    const url = `https://pixabay.com/api/videos/?key=${encodeURIComponent(this.apiKey)}&q=${encodeURIComponent(cleanQuery)}&per_page=${perPage}&page=${page}`;

    let lastError: Error | null = null;
    const maxAttempts = 1 + this.retries;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), options.timeoutMs ?? this.timeoutMs);

      try {
        const response = await this.fetchFn(url, {
          method: 'GET',
          headers: {
            Accept: 'application/json',
          },
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (response.status === 400 || response.status === 401) {
          throw new StockError(
            'STOCK_AUTH_FAILED',
            `Pixabay authentication rejected request with HTTP ${response.status}.`,
            { provider: this.providerName }
          );
        }

        if (response.status === 429) {
          throw new StockError(
            'STOCK_RATE_LIMITED',
            'Pixabay API rate limit exceeded.',
            { provider: this.providerName }
          );
        }

        if (!response.ok) {
          if (response.status >= 500 && attempt < maxAttempts) {
            await new Promise(r => setTimeout(r, 200 * Math.pow(2, attempt)));
            continue;
          }
          throw new StockError(
            'STOCK_PROVIDER_UNAVAILABLE',
            `Pixabay API request failed with HTTP ${response.status}.`,
            { provider: this.providerName }
          );
        }

        let data: { hits?: PixabayRawVideoItem[] };
        try {
          data = await response.json();
        } catch {
          throw new StockError(
            'STOCK_MALFORMED_RESPONSE',
            'Failed to parse Pixabay API response JSON.',
            { provider: this.providerName }
          );
        }

        const hits = Array.isArray(data.hits) ? data.hits : [];
        const candidates = hits.map(h => normalizePixabayVideo(h, cleanQuery));

        if (this.cache && cacheKey) {
          await this.cache.set('pixabay_search', cacheKey, candidates, 86400 * 7);
        }

        return candidates;
      } catch (err: unknown) {
        clearTimeout(timeoutId);

        if (err instanceof StockError) {
          throw err;
        }

        const isAbort = (err as { name?: string }).name === 'AbortError';
        if (isAbort) {
          lastError = new StockError(
            'STOCK_TIMEOUT',
            `Pixabay search request timed out after ${this.timeoutMs}ms.`,
            { provider: this.providerName }
          );
        } else {
          lastError = err as Error;
        }

        if (attempt < maxAttempts) {
          await new Promise(r => setTimeout(r, 200 * Math.pow(2, attempt)));
        }
      }
    }

    throw lastError || new StockError(
      'STOCK_PROVIDER_UNAVAILABLE',
      'Pixabay search request failed after all attempts.',
      { provider: this.providerName }
    );
  }
}
