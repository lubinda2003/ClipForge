/**
 * ClipForge Stock Media & B-Roll Typed Errors
 */

export type StockErrorCode =
  | 'STOCK_PROVIDER_UNAVAILABLE'
  | 'STOCK_AUTH_FAILED'
  | 'STOCK_RATE_LIMITED'
  | 'STOCK_TIMEOUT'
  | 'STOCK_MALFORMED_RESPONSE'
  | 'NO_STOCK_RESULTS'
  | 'NO_SUITABLE_CANDIDATE'
  | 'DOWNLOAD_FAILED'
  | 'MEDIA_VALIDATION_FAILED'
  | 'CACHE_ERROR'
  | 'BROLL_ARTIFACT_INVALID';

export class StockError extends Error {
  readonly code: StockErrorCode;
  readonly provider?: string;
  readonly details?: Record<string, unknown>;

  constructor(
    code: StockErrorCode,
    message: string,
    options?: { provider?: string; details?: Record<string, unknown> }
  ) {
    // Redact potential secrets before assigning message
    const sanitizedMessage = sanitizeErrorString(message);
    super(`[${code}] ${sanitizedMessage}`);
    this.name = 'StockError';
    this.code = code;
    this.provider = options?.provider;
    this.details = options?.details ? sanitizeDetails(options.details) : undefined;
  }
}

function sanitizeErrorString(str: string): string {
  return str
    .replace(/(?:key|token|auth|bearer|secret)[=:]\s*([a-zA-Z0-9_\-.]{8,})/gi, '$1=***REDACTED***')
    .replace(/Bearer\s+[a-zA-Z0-9_\-.]+/gi, 'Bearer ***REDACTED***');
}

function sanitizeDetails(details: Record<string, unknown>): Record<string, unknown> {
  const sanitized: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(details)) {
    if (/key|token|secret|auth|password/i.test(k)) {
      sanitized[k] = '***REDACTED***';
    } else if (typeof v === 'string') {
      sanitized[k] = sanitizeErrorString(v);
    } else {
      sanitized[k] = v;
    }
  }
  return sanitized;
}
