/**
 * ClipForge Pexels Stock Media Provider
 * Integrates with Pexels Video Search API with retries, timeout, and caching.
 */

import { StockCandidate, IStockMediaProvider } from '../contracts/stock.ts';
import { StockSearchOptions } from './interfaces.ts';
import { normalizePexelsVideo, PexelsRawVideoItem } from './normalizer.ts';
import { StockError } from './errors.ts';
import { CacheManager } from '../storage/cache.ts';

export interface PexelsProviderConfig {
  apiKey?: string;
  cache?: CacheManager;
  fetchFn?: typeof fetch;
  timeoutMs?: number;
  retries?: number;
}

export class PexelsStockProvider implements IStockMediaProvider {
  readonly providerName = 'pexels';
  private readonly apiKey: string;
  private readonly cache?: CacheManager;
  private readonly fetchFn: typeof fetch;
  private readonly timeoutMs: number;
  private readonly retries: number;

  constructor(config: PexelsProviderConfig = {}) {
    this.apiKey = config.apiKey || process.env.PEXELS_API_KEY || '';
    this.cache = config.cache;
    this.fetchFn = config.fetchFn || globalThis.fetch;
    this.timeoutMs = config.timeoutMs ?? 10000;
    this.retries = config.retries ?? 2;
  }

  async checkAvailability(): Promise<{ available: boolean; reason?: string }> {
    if (!this.apiKey || this.apiKey.trim().length === 0) {
      return { available: false, reason: 'missing_api_key' };
    }
    return { available: true };
  }

  async searchVideos(query: string, options: StockSearchOptions = {}): Promise<StockCandidate[]> {
    if (!this.apiKey || this.apiKey.trim().length === 0) {
      throw new StockError('STOCK_AUTH_FAILED', 'Pexels API key is not configured.', {
        provider: this.providerName,
      });
    }

    const cleanQuery = query.trim();
    if (!cleanQuery) {
      return [];
    }

    const perPage = options.perPage ?? 10;
    const page = options.page ?? 1;
    const orientation = options.orientation;

    // Cache lookup
    const cacheKey = this.cache?.generateKey('pexels_search', {
      query: cleanQuery,
      orientation,
      perPage,
      page,
    });

    if (this.cache && cacheKey) {
      const cached = await this.cache.get<StockCandidate[]>(cacheKey);
      if (cached) {
        return cached;
      }
    }

    let url = `https://api.pexels.com/videos/search?query=${encodeURIComponent(cleanQuery)}&per_page=${perPage}&page=${page}`;
    if (orientation) {
      url += `&orientation=${orientation}`;
    }

    let lastError: Error | null = null;
    const maxAttempts = 1 + this.retries;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), options.timeoutMs ?? this.timeoutMs);

      try {
        const response = await this.fetchFn(url, {
          method: 'GET',
          headers: {
            Authorization: this.apiKey,
            Accept: 'application/json',
          },
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (response.status === 401 || response.status === 403) {
          throw new StockError(
            'STOCK_AUTH_FAILED',
            `Pexels authentication failed with HTTP ${response.status}.`,
            { provider: this.providerName, details: { status: response.status } }
          );
        }

        if (response.status === 429) {
          throw new StockError(
            'STOCK_RATE_LIMITED',
            'Pexels API rate limit exceeded.',
            { provider: this.providerName, details: { status: 429 } }
          );
        }

        if (!response.ok) {
          if (response.status >= 500 && attempt < maxAttempts) {
            await new Promise(r => setTimeout(r, 200 * Math.pow(2, attempt)));
            continue;
          }
          throw new StockError(
            'STOCK_PROVIDER_UNAVAILABLE',
            `Pexels search request failed with HTTP ${response.status}.`,
            { provider: this.providerName, details: { status: response.status } }
          );
        }

        let data: { videos?: PexelsRawVideoItem[] };
        try {
          data = await response.json();
        } catch (jsonErr) {
          throw new StockError(
            'STOCK_MALFORMED_RESPONSE',
            'Failed to parse Pexels API response JSON.',
            { provider: this.providerName }
          );
        }

        const videos = Array.isArray(data.videos) ? data.videos : [];
        const candidates = videos.map(v => normalizePexelsVideo(v, cleanQuery));

        if (this.cache && cacheKey) {
          await this.cache.set('pexels_search', cacheKey, candidates, 86400 * 7); // 7 days
        }

        return candidates;
      } catch (err: unknown) {
        clearTimeout(timeoutId);

        if (err instanceof StockError) {
          throw err;
        }

        const isAbort = (err as { name?: string }).name === 'AbortError';
        if (isAbort) {
          lastError = new StockError(
            'STOCK_TIMEOUT',
            `Pexels search request timed out after ${this.timeoutMs}ms.`,
            { provider: this.providerName }
          );
        } else {
          lastError = err as Error;
        }

        if (attempt < maxAttempts) {
          await new Promise(r => setTimeout(r, 200 * Math.pow(2, attempt)));
        }
      }
    }

    throw lastError || new StockError(
      'STOCK_PROVIDER_UNAVAILABLE',
      'Pexels search request failed after all attempts.',
      { provider: this.providerName }
    );
  }
}
