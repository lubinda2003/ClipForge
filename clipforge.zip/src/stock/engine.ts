/**
 * ClipForge B-Roll Selection Engine
 * Coordinates stock queries, candidate normalization, multi-factor ranking, media downloading,
 * caching, and persistence of broll_selection.json.
 */

import path from 'node:path';
import fs from 'node:fs';
import { ScenesArtifact, SceneVisualRequirement } from '../contracts/scenes.ts';
import {
  StockCandidate,
  StockVideoFile,
  SceneStockSelection,
  BrollSelectionArtifact,
  IStockMediaProvider,
} from '../contracts/stock.ts';
import { IBrollSelectionEngine, BrollSelectionOptions } from './interfaces.ts';
import { CandidateRanker } from './ranker.ts';
import { MediaDownloader } from './downloader.ts';
import { validateBrollSelectionArtifact } from './validator.ts';
import { StockError } from './errors.ts';
import { PexelsStockProvider } from './pexels.ts';
import { PixabayStockProvider } from './pixabay.ts';
import { IStorageProvider } from '../storage/interface.ts';
import { LocalStorageProvider } from '../storage/local.ts';
import { CacheManager } from '../storage/cache.ts';

export interface BrollEngineDependencies {
  storage?: IStorageProvider;
  cache?: CacheManager;
  providers?: IStockMediaProvider[];
  downloader?: MediaDownloader;
  ranker?: CandidateRanker;
}

export class BrollSelectionEngine implements IBrollSelectionEngine {
  private readonly storage: IStorageProvider;
  private readonly cache: CacheManager;
  private readonly providers: IStockMediaProvider[];
  private readonly downloader: MediaDownloader;
  private readonly ranker: CandidateRanker;

  constructor(deps: BrollEngineDependencies = {}) {
    this.storage = deps.storage || new LocalStorageProvider();
    this.cache = deps.cache || new CacheManager(this.storage);
    this.downloader = deps.downloader || new MediaDownloader();
    this.ranker = deps.ranker || new CandidateRanker();

    if (deps.providers && deps.providers.length > 0) {
      this.providers = deps.providers;
    } else {
      this.providers = [
        new PexelsStockProvider({ cache: this.cache }),
        new PixabayStockProvider({ cache: this.cache }),
      ];
    }
  }

  async executeBrollSelection(
    scenes: ScenesArtifact,
    options: BrollSelectionOptions = {}
  ): Promise<BrollSelectionArtifact> {
    if (!scenes || !Array.isArray(scenes.scenes) || scenes.scenes.length === 0) {
      throw new StockError('BROLL_ARTIFACT_INVALID', 'Valid ScenesArtifact with at least one scene is required.');
    }

    const jobId = options.jobId || scenes.jobId || `job_${Date.now()}`;
    const format = options.format || scenes.format || 'short';
    const minRelevance = options.minRelevanceScore ?? 0.25;
    const maxQueriesPerScene = options.maxQueriesPerScene ?? 3;
    const maxResultsPerQuery = options.maxResultsPerQuery ?? 8;
    const downloadMedia = options.downloadMedia !== false;

    // Determine media download folder
    let mediaDir: string;
    if (options.outputDir) {
      mediaDir = options.outputDir;
    } else if (this.storage instanceof LocalStorageProvider) {
      mediaDir = path.join(this.storage.baseDirectory, 'inputs', 'jobs', jobId, 'media');
    } else {
      mediaDir = path.join(process.cwd(), '.cache', 'clipforge', 'jobs', jobId, 'media');
    }

    if (downloadMedia && !fs.existsSync(mediaDir)) {
      fs.mkdirSync(mediaDir, { recursive: true });
    }

    // Filter available providers
    const availableProviders: IStockMediaProvider[] = [];
    for (const p of this.providers) {
      if (p.checkAvailability) {
        const status = await p.checkAvailability();
        if (status.available) {
          availableProviders.push(p);
        }
      } else {
        availableProviders.push(p);
      }
    }

    const previouslySelectedSourceIds = new Set<string>();
    const selections: SceneStockSelection[] = [];
    const unresolvedScenes: string[] = [];

    let totalCacheHits = 0;
    let totalApiQueries = 0;
    let totalBytesDownloaded = 0;

    for (const scene of scenes.scenes) {
      const candidatesBySource = new Map<string, StockCandidate>();
      const searchQueries = (scene.searchKeywords || []).slice(0, maxQueriesPerScene);

      // Search across available providers
      for (const query of searchQueries) {
        for (const provider of availableProviders) {
          try {
            totalApiQueries++;
            const results = await provider.searchVideos(query, {
              orientation: format === 'short' ? 'portrait' : 'landscape',
              perPage: maxResultsPerQuery,
              timeoutMs: options.timeoutMs,
            });

            for (const cand of results) {
              const key = `${cand.source}:${cand.sourceId}`;
              if (!candidatesBySource.has(key)) {
                candidatesBySource.set(key, cand);
              }
            }
          } catch (err) {
            // Non-fatal search warning for individual query
            console.warn(`[BrollSelectionEngine] Provider ${provider.providerName} query "${query}" failed:`, err);
          }
        }
      }

      const allCandidates = Array.from(candidatesBySource.values());

      // If no providers returned candidates (or offline without keys), generate fallback candidate for continuity
      if (allCandidates.length === 0) {
        if (availableProviders.length === 0) {
          allCandidates.push(this.generateOfflineFallbackCandidate(scene, format));
        } else {
          unresolvedScenes.push(scene.sceneId);
          continue;
        }
      }

      // Rank candidates deterministically
      const ranked = this.ranker.rankCandidates(
        allCandidates,
        scene,
        format,
        previouslySelectedSourceIds
      );

      const viableCandidates = ranked.filter(c => c.relevanceScore >= minRelevance);
      const candidatesToTry = viableCandidates.length > 0 ? viableCandidates : ranked;

      let selectedCandidate: StockCandidate | null = null;
      let selectedFile: StockVideoFile | null = null;
      let downloadedLocalPath: string | undefined;

      // Select candidate and download with fallback
      for (const candidate of candidatesToTry) {
        const file = this.selectBestFile(candidate, format);
        if (!file) continue;

        if (downloadMedia && candidate.downloadUrl) {
          const ext = file.fileType?.includes('webm') ? 'webm' : 'mp4';
          const destPath = path.join(mediaDir, `${scene.sceneId}_${candidate.candidateId}.${ext}`);

          try {
            const dlResult = await this.downloader.downloadMedia(candidate.downloadUrl, destPath);
            downloadedLocalPath = dlResult.localPath;
            totalBytesDownloaded += dlResult.bytes;
            selectedCandidate = candidate;
            selectedFile = file;
            break;
          } catch (dlErr) {
            console.warn(`[BrollSelectionEngine] Candidate ${candidate.candidateId} download failed, trying alternative:`, dlErr);
            continue;
          }
        } else {
          // No download requested or mock file
          selectedCandidate = candidate;
          selectedFile = file;
          break;
        }
      }

      if (!selectedCandidate || !selectedFile) {
        unresolvedScenes.push(scene.sceneId);
        continue;
      }

      previouslySelectedSourceIds.add(selectedCandidate.sourceId);

      // Determine transform
      const isShort = format === 'short';
      const isPortrait = selectedFile.aspectRatio === '9:16' || selectedCandidate.orientation === 'portrait';
      let appliedTransform: 'native' | 'center_crop' | 'pan_zoom' = 'native';
      if (isShort && !isPortrait) {
        appliedTransform = 'center_crop';
      } else if (!isShort && isPortrait) {
        appliedTransform = 'pan_zoom';
      }

      // Determine trimming offsets
      const desiredDuration = scene.desiredDurationSeconds;
      const candidateDuration = selectedCandidate.durationSeconds;
      let trimStart = 0;
      if (candidateDuration > desiredDuration + 1.0) {
        // Pick stable middle section, starting 1.0s in
        trimStart = Number(Math.min(2.0, (candidateDuration - desiredDuration) / 2).toFixed(2));
      }

      const alternativeCandidates = candidatesToTry
        .filter(c => c.candidateId !== selectedCandidate!.candidateId)
        .slice(0, 3);

      selections.push({
        sceneId: scene.sceneId,
        selectedCandidate,
        selectedFile,
        downloadedLocalPath,
        trimStartSeconds: trimStart,
        trimDurationSeconds: desiredDuration,
        appliedTransform,
        selectionReason: `Selected for query "${scene.searchKeywords[0]}" with score ${selectedCandidate.relevanceScore} (${appliedTransform})`,
        alternativeCandidates,
        validationStatus: 'valid',
        downloadStatus: downloadedLocalPath ? 'downloaded' : 'skipped',
      });
    }

    const artifact: BrollSelectionArtifact = {
      jobId,
      createdAt: new Date().toISOString(),
      format,
      totalScenes: scenes.totalScenes,
      selections,
      cacheStats: {
        cacheHits: totalCacheHits,
        apiQueries: totalApiQueries,
        bytesDownloaded: totalBytesDownloaded,
      },
      unresolvedScenes: unresolvedScenes.length > 0 ? unresolvedScenes : undefined,
      metadata: {
        selectedAt: new Date().toISOString(),
        scenesReference: `jobs/${jobId}/scenes.json`,
        providersQueried: availableProviders.map(p => p.providerName),
        selectionStrategy: 'multi_factor_deterministic_ranking',
      },
    };

    // Quality validation of generated artifact
    const validation = validateBrollSelectionArtifact(artifact);
    if (!validation.isValid) {
      throw new StockError(
        'BROLL_ARTIFACT_INVALID',
        `B-Roll selection validation failed:\n${validation.errors.join('\n')}`,
        { details: { errors: validation.errors } }
      );
    }

    // Persist broll_selection.json artifact
    const artifactKey = `jobs/${jobId}/broll_selection.json`;
    if (this.storage instanceof LocalStorageProvider) {
      await this.storage.writeJson('inputs', artifactKey, artifact);
    }

    return artifact;
  }

  private selectBestFile(candidate: StockCandidate, format: string): StockVideoFile | null {
    if (!candidate.files || candidate.files.length === 0) {
      return {
        fileId: `${candidate.candidateId}_f0`,
        url: candidate.downloadUrl,
        width: candidate.resolution.width,
        height: candidate.resolution.height,
        aspectRatio: candidate.originalAspectRatio,
        quality: 'hd',
        fileType: 'video/mp4',
      };
    }

    const isShort = format === 'short';
    // If short, prefer 9:16 files if available
    if (isShort) {
      const portraitFiles = candidate.files.filter(f => f.height > f.width);
      if (portraitFiles.length > 0) {
        portraitFiles.sort((a, b) => b.width * b.height - a.width * a.height);
        return portraitFiles[0];
      }
    }

    // Otherwise pick highest resolution
    const sorted = [...candidate.files].sort((a, b) => b.width * b.height - a.width * a.height);
    return sorted[0];
  }

  private generateOfflineFallbackCandidate(
    scene: SceneVisualRequirement,
    format: string
  ): StockCandidate {
    const isShort = format === 'short';
    const width = isShort ? 1080 : 1920;
    const height = isShort ? 1920 : 1080;
    const aspect = isShort ? '9:16' : '16:9';

    return {
      candidateId: `fallback_${scene.sceneId}`,
      source: 'local_cache',
      sourceId: `fallback_${scene.sceneId}`,
      title: `Offline Fallback: ${scene.visualConcept}`,
      tags: scene.searchKeywords,
      durationSeconds: Math.max(10, scene.desiredDurationSeconds + 2),
      previewUrl: `mock://preview/${scene.sceneId}.jpg`,
      downloadUrl: `mock://download/${scene.sceneId}.mp4`,
      resolution: { width, height },
      originalAspectRatio: aspect,
      files: [
        {
          fileId: `fallback_file_${scene.sceneId}`,
          url: `mock://download/${scene.sceneId}.mp4`,
          width,
          height,
          aspectRatio: aspect,
          quality: 'hd',
          fileType: 'video/mp4',
        },
      ],
      author: 'ClipForge Fallback Engine',
      license: 'ClipForge Internal Asset',
      relevanceScore: 0.8,
      queryUsed: scene.searchKeywords[0] || 'general',
      orientation: isShort ? 'portrait' : 'landscape',
    };
  }
}
