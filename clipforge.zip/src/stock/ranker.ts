/**
 * ClipForge Candidate Ranker
 * Multi-factor deterministic scoring and ranking for stock video candidates.
 */

import { VideoFormat } from '../contracts/common.ts';
import { StockCandidate } from '../contracts/stock.ts';
import { SceneVisualRequirement } from '../contracts/scenes.ts';

export interface ScoredCandidate {
  candidate: StockCandidate;
  totalScore: number;
  breakdown: {
    keywordMatch: number;
    subjectMatch: number;
    actionMatch: number;
    formatSuitability: number;
    resolutionScore: number;
    durationScore: number;
    cropSuitability: number;
    continuityScore: number;
    repetitionPenalty: number;
  };
}

export class CandidateRanker {
  /**
   * Ranks candidates deterministically for a scene given target format and previously selected media.
   */
  rankCandidates(
    candidates: StockCandidate[],
    scene: SceneVisualRequirement,
    targetFormat: VideoFormat,
    previouslySelectedSourceIds: Set<string> = new Set()
  ): StockCandidate[] {
    if (!candidates || candidates.length === 0) {
      return [];
    }

    const scored: ScoredCandidate[] = candidates.map(candidate =>
      this.scoreCandidate(candidate, scene, targetFormat, previouslySelectedSourceIds)
    );

    // Sort deterministically
    scored.sort((a, b) => {
      // 1. Total score descending
      if (Math.abs(b.totalScore - a.totalScore) > 0.001) {
        return b.totalScore - a.totalScore;
      }

      // 2. Resolution pixel area descending
      const aPixels = a.candidate.resolution.width * a.candidate.resolution.height;
      const bPixels = b.candidate.resolution.width * b.candidate.resolution.height;
      if (bPixels !== aPixels) {
        return bPixels - aPixels;
      }

      // 3. Duration suitability delta ascending
      const aDurDelta = Math.abs(a.candidate.durationSeconds - scene.desiredDurationSeconds);
      const bDurDelta = Math.abs(b.candidate.durationSeconds - scene.desiredDurationSeconds);
      if (Math.abs(aDurDelta - bDurDelta) > 0.01) {
        return aDurDelta - bDurDelta;
      }

      // 4. Provider priority: pexels > pixabay > local_cache
      const providerPriority: Record<string, number> = { pexels: 3, pixabay: 2, local_cache: 1 };
      const aPrio = providerPriority[a.candidate.source] || 0;
      const bPrio = providerPriority[b.candidate.source] || 0;
      if (bPrio !== aPrio) {
        return bPrio - aPrio;
      }

      // 5. Deterministic tie-breaker: candidateId alphabetical
      return a.candidate.candidateId.localeCompare(b.candidate.candidateId);
    });

    // Attach updated score and breakdown back onto candidates
    return scored.map(s => {
      s.candidate.relevanceScore = Number(s.totalScore.toFixed(3));
      s.candidate.rankingBreakdown = {
        keywordMatch: Number(s.breakdown.keywordMatch.toFixed(3)),
        resolutionScore: Number(s.breakdown.resolutionScore.toFixed(3)),
        aspectRatioScore: Number(s.breakdown.formatSuitability.toFixed(3)),
        durationScore: Number(s.breakdown.durationScore.toFixed(3)),
        continuityScore: Number(s.breakdown.continuityScore.toFixed(3)),
        subjectMatch: Number(s.breakdown.subjectMatch.toFixed(3)),
        actionMatch: Number(s.breakdown.actionMatch.toFixed(3)),
        formatSuitability: Number(s.breakdown.formatSuitability.toFixed(3)),
        cropSuitability: Number(s.breakdown.cropSuitability.toFixed(3)),
        repetitionPenalty: Number(s.breakdown.repetitionPenalty.toFixed(3)),
      };
      return s.candidate;
    });
  }

  scoreCandidate(
    candidate: StockCandidate,
    scene: SceneVisualRequirement,
    targetFormat: VideoFormat,
    previouslySelectedSourceIds: Set<string>
  ): ScoredCandidate {
    const isShort = targetFormat === 'short';
    const isPortrait = candidate.originalAspectRatio === '9:16' || candidate.orientation === 'portrait';
    const candidateTokens = new Set([
      ...(candidate.tags || []).map(t => t.toLowerCase()),
      ...(candidate.title || '').toLowerCase().split(/\s+/),
      candidate.sourceId.toLowerCase(),
    ]);

    // 1. Keyword / Semantic match
    const sceneKeywords = scene.searchKeywords.flatMap(k => k.toLowerCase().split(/\s+/));
    const conceptWords = scene.visualConcept.toLowerCase().split(/\s+/).filter(w => w.length > 3);
    const allTargetTokens = [...new Set([...sceneKeywords, ...conceptWords])];

    let matchedTokens = 0;
    for (const token of allTargetTokens) {
      if (candidateTokens.has(token)) {
        matchedTokens++;
      } else {
        // Substring match
        for (const ct of candidateTokens) {
          if (ct.includes(token) || token.includes(ct)) {
            matchedTokens += 0.5;
            break;
          }
        }
      }
    }
    const keywordMatch = Math.min(1.0, allTargetTokens.length > 0 ? (matchedTokens / allTargetTokens.length) * 1.5 : 0.5);

    // 2. Subject match
    let subjectMatch = 0.5;
    if (scene.requiredSubjects && scene.requiredSubjects.length > 0) {
      let matchedSubjects = 0;
      for (const subj of scene.requiredSubjects) {
        const lowerSubj = subj.toLowerCase();
        for (const ct of candidateTokens) {
          if (ct.includes(lowerSubj) || lowerSubj.includes(ct)) {
            matchedSubjects++;
            break;
          }
        }
      }
      subjectMatch = matchedSubjects / scene.requiredSubjects.length;
    }

    // 3. Action match
    let actionMatch = 0.5;
    if (scene.requiredActions && scene.requiredActions.length > 0) {
      let matchedActions = 0;
      for (const act of scene.requiredActions) {
        const lowerAct = act.toLowerCase();
        for (const ct of candidateTokens) {
          if (ct.includes(lowerAct)) {
            matchedActions++;
            break;
          }
        }
      }
      actionMatch = matchedActions / scene.requiredActions.length;
    }

    // 4. Format & Orientation suitability
    let formatSuitability = 0.5;
    if (isShort) {
      if (isPortrait) {
        formatSuitability = 1.0; // Native portrait match
      } else if (scene.allowCropping) {
        // Landscape can be center-cropped if resolution is adequate
        formatSuitability = candidate.resolution.width >= 1920 ? 0.85 : 0.65;
      } else {
        formatSuitability = 0.4;
      }
    } else {
      // Long format (16:9)
      if (!isPortrait) {
        formatSuitability = 1.0; // Native landscape match
      } else {
        formatSuitability = 0.3; // Portrait on 16:9 is poor
      }
    }

    // 5. Resolution score
    const minDim = Math.min(candidate.resolution.width, candidate.resolution.height);
    let resolutionScore = 0.5;
    if (minDim >= 2160) {
      resolutionScore = 1.0; // 4K UHD
    } else if (minDim >= 1080) {
      resolutionScore = 0.9; // 1080p FHD
    } else if (minDim >= 720) {
      resolutionScore = 0.65; // 720p HD
    } else {
      resolutionScore = 0.3; // SD
    }

    // 6. Duration suitability
    const desired = scene.desiredDurationSeconds;
    const dur = candidate.durationSeconds;
    let durationScore = 0.5;
    if (dur < desired) {
      // Penalize heavily if candidate is shorter than desired duration
      durationScore = Math.max(0.1, (dur / desired) * 0.45);
    } else {
      // Ideal duration is 1.2x to 3x desired duration (room for trimming stable middle)
      const ratio = dur / desired;
      if (ratio >= 1.1 && ratio <= 3.5) {
        durationScore = 1.0;
      } else if (ratio < 1.1) {
        durationScore = 0.9;
      } else {
        // Very long video (> 3.5x)
        durationScore = 0.85;
      }
    }

    // 7. Crop suitability
    let cropSuitability = 1.0;
    if (isShort && !isPortrait) {
      // Cropping landscape to 9:16
      cropSuitability = candidate.resolution.height >= 1080 ? 0.9 : 0.6;
    }

    // 8. Continuity score
    let continuityScore = 0.5;
    if (scene.visualContinuityGroup) {
      if (candidate.author) {
        continuityScore = 0.7;
      }
    }

    // 9. Repetition penalty
    let repetitionPenalty = 0.0;
    if (previouslySelectedSourceIds.has(candidate.sourceId)) {
      repetitionPenalty = 0.55; // Penalize duplicate use of the same asset
    }

    // Weighted combination
    const rawScore =
      0.25 * keywordMatch +
      0.15 * subjectMatch +
      0.10 * actionMatch +
      0.15 * formatSuitability +
      0.10 * resolutionScore +
      0.15 * durationScore +
      0.05 * cropSuitability +
      0.05 * continuityScore -
      repetitionPenalty;

    const totalScore = Math.max(0.0, Math.min(1.0, rawScore));

    return {
      candidate,
      totalScore,
      breakdown: {
        keywordMatch,
        subjectMatch,
        actionMatch,
        formatSuitability,
        resolutionScore,
        durationScore,
        cropSuitability,
        continuityScore,
        repetitionPenalty,
      },
    };
  }

  calculateTransforms(candidate: StockCandidate, format: VideoFormat) {
    const isShort = format === 'short';
    const isPortrait = candidate.originalAspectRatio === '9:16' || candidate.orientation === 'portrait';
    const cropRequired = isShort ? !isPortrait : isPortrait;
    return {
      cropRequired,
      scaleRequired: cropRequired,
      targetAspectRatio: isShort ? '9:16' : '16:9',
      originalAspectRatio: candidate.originalAspectRatio,
    };
  }
}

