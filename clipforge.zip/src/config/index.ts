/**
 * ClipForge Configuration Loader & Contract
 * Strictly reads from environment variables, provides robust defaults, and protects secrets.
 */

import { RenderProfile, SHORT_FORM_PROFILE, LONG_FORM_PROFILE } from '../contracts/rendering.ts';
import { VideoFormat } from '../contracts/common.ts';

export interface ClipForgeConfig {
  ai: {
    geminiApiKey?: string;
    model: string;
    temperature: number;
  };
  research: {
    youtubeApiKey?: string;
    maxCompetitorVideos: number;
    searchRegionCode: string;
  };
  stock: {
    pexelsApiKey?: string;
    pixabayApiKey?: string;
    preferredResolution: { width: number; height: number };
    maxCandidatesPerScene: number;
    maxQueriesPerScene?: number;
    maxResultsPerQuery?: number;
    searchTimeoutMs?: number;
    searchRetries?: number;
    downloadTimeoutMs?: number;
    downloadRetries?: number;
    cacheTtlSeconds?: number;
    minRelevanceScore?: number;
  };
  narration: {
    engine: 'piper';
    piperBinPath: string;
    piperModelPath: string;
    defaultVoice: string;
    defaultSpeed: number; // 1.0 standard
  };
  storage: {
    provider: 'local' | 'r2';
    cacheDirectory: string;
    outputDirectory: string;
    r2: {
      accountId?: string;
      accessKeyId?: string;
      secretAccessKey?: string;
      buckets: {
        inputs: string;
        assets: string;
        outputs: string;
      };
    };
  };
  rendering: {
    ffmpegBinPath: string;
    ffprobeBinPath: string;
    profiles: {
      short: RenderProfile;
      long: RenderProfile;
    };
  };
  retentionDefaults: {
    shortMaxSceneDurationSeconds: number; // Typically 2.5 - 4.5s
    longMaxSceneDurationSeconds: number;  // Typically 4.0 - 7.0s
    duckingNarrationVolumeMultiplier: number; // 0.12 (music drops to 12% during voice)
  };
}

export function loadConfig(overrides?: Partial<ClipForgeConfig>): ClipForgeConfig {
  return {
    ai: {
      geminiApiKey: process.env.GEMINI_API_KEY || '',
      model: process.env.GEMINI_MODEL || 'gemini-3.6-flash',
      temperature: 0.7,
      ...overrides?.ai,
    },
    research: {
      youtubeApiKey: process.env.YOUTUBE_API_KEY || '',
      maxCompetitorVideos: 10,
      searchRegionCode: 'US',
      ...overrides?.research,
    },
    stock: {
      pexelsApiKey: process.env.PEXELS_API_KEY || '',
      pixabayApiKey: process.env.PIXABAY_API_KEY || '',
      preferredResolution: { width: 1920, height: 1080 },
      maxCandidatesPerScene: 5,
      maxQueriesPerScene: Number(process.env.STOCK_SEARCH_MAX_QUERIES || 4),
      maxResultsPerQuery: Number(process.env.STOCK_SEARCH_MAX_RESULTS || 10),
      searchTimeoutMs: Number(process.env.STOCK_SEARCH_TIMEOUT_MS || 10000),
      searchRetries: Number(process.env.STOCK_SEARCH_RETRIES || 2),
      downloadTimeoutMs: Number(process.env.STOCK_DOWNLOAD_TIMEOUT_MS || 30000),
      downloadRetries: Number(process.env.STOCK_DOWNLOAD_RETRIES || 2),
      cacheTtlSeconds: Number(process.env.STOCK_CACHE_TTL_SECONDS || 604800),
      minRelevanceScore: Number(process.env.BROLL_MIN_RELEVANCE_SCORE || 0.25),
      ...overrides?.stock,
    },
    narration: {
      engine: 'piper',
      piperBinPath: process.env.PIPER_BIN_PATH || 'piper',
      piperModelPath: process.env.PIPER_DEFAULT_MODEL || 'en_US-lessac-medium',
      defaultVoice: 'en_US-lessac-medium',
      defaultSpeed: 1.0,
      ...overrides?.narration,
    },
    storage: {
      provider: (process.env.STORAGE_PROVIDER as 'local' | 'r2') || 'local',
      cacheDirectory: process.env.CLIPFORGE_CACHE_DIR || './.cache/clipforge',
      outputDirectory: process.env.CLIPFORGE_OUTPUT_DIR || './dist/outputs',
      r2: {
        accountId: process.env.R2_ACCOUNT_ID || '',
        accessKeyId: process.env.R2_ACCESS_KEY_ID || '',
        secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || '',
        buckets: {
          inputs: process.env.R2_BUCKET_INPUTS || 'clipforge-inputs',
          assets: process.env.R2_BUCKET_ASSETS || 'clipforge-assets',
          outputs: process.env.R2_BUCKET_OUTPUTS || 'clipforge-outputs',
        },
      },
      ...overrides?.storage,
    },
    rendering: {
      ffmpegBinPath: process.env.FFMPEG_BIN_PATH || 'ffmpeg',
      ffprobeBinPath: process.env.FFPROBE_BIN_PATH || 'ffprobe',
      profiles: {
        short: SHORT_FORM_PROFILE,
        long: LONG_FORM_PROFILE,
      },
      ...overrides?.rendering,
    },
    retentionDefaults: {
      shortMaxSceneDurationSeconds: 3.5,
      longMaxSceneDurationSeconds: 6.0,
      duckingNarrationVolumeMultiplier: 0.12,
      ...overrides?.retentionDefaults,
    },
  };
}

export function getProfileForFormat(format: VideoFormat, config: ClipForgeConfig): RenderProfile {
  return format === 'short' ? config.rendering.profiles.short : config.rendering.profiles.long;
}
