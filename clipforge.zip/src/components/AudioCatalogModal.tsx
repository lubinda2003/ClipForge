import React, { useState } from 'react';
import { Music, Volume2, Search, Check, Sparkles, Filter } from 'lucide-react';
import { DEFAULT_CURATED_AUDIO_CATALOG } from '../assets/catalog.ts';
import { AudioAssetMetadata } from '../contracts/assets.ts';

interface AudioCatalogProps {
  onSelectTrack?: (track: AudioAssetMetadata) => void;
  selectedAssetId?: string;
}

export const AudioCatalogBrowser: React.FC<AudioCatalogProps> = ({
  onSelectTrack,
  selectedAssetId,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'music' | 'sfx'>('all');
  const [search, setSearch] = useState('');
  const [playingId, setPlayingId] = useState<string | null>(null);

  const filteredAssets = DEFAULT_CURATED_AUDIO_CATALOG.filter((item) => {
    if (filterType !== 'all' && item.type !== filterType) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchTitle = item.title?.toLowerCase().includes(q) || false;
      const matchCat = item.category.toLowerCase().includes(q);
      const matchMood = item.mood.toLowerCase().includes(q);
      const matchTags = item.tags.some((t) => t.toLowerCase().includes(q));
      if (!matchTitle && !matchCat && !matchMood && !matchTags) return false;
    }
    return true;
  });

  const togglePlay = (id: string) => {
    setPlayingId(playingId === id ? null : id);
  };

  return (
    <div className="bg-neutral-900/50 border border-neutral-800 rounded-xl p-5 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-white">Royalty-Free Audio Library</h3>
            <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-purple-500/10 text-purple-400 border border-purple-500/30">
              {DEFAULT_CURATED_AUDIO_CATALOG.length} Curated Tracks &amp; SFX
            </span>
          </div>
          <p className="text-xs text-neutral-400">
            CC0 / Public Domain assets verified for unrestricted commercial monetization
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-2">
          <div className="flex bg-neutral-950 p-1 rounded-lg border border-neutral-800 text-xs">
            <button
              type="button"
              onClick={() => setFilterType('all')}
              className={`px-3 py-1 rounded font-medium ${
                filterType === 'all' ? 'bg-neutral-800 text-white' : 'text-neutral-400'
              }`}
            >
              All ({DEFAULT_CURATED_AUDIO_CATALOG.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterType('music')}
              className={`px-3 py-1 rounded font-medium ${
                filterType === 'music' ? 'bg-neutral-800 text-white' : 'text-neutral-400'
              }`}
            >
              Music (
              {DEFAULT_CURATED_AUDIO_CATALOG.filter((a) => a.type === 'music').length})
            </button>
            <button
              type="button"
              onClick={() => setFilterType('sfx')}
              className={`px-3 py-1 rounded font-medium ${
                filterType === 'sfx' ? 'bg-neutral-800 text-white' : 'text-neutral-400'
              }`}
            >
              SFX (
              {DEFAULT_CURATED_AUDIO_CATALOG.filter((a) => a.type === 'sfx').length})
            </button>
          </div>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-2.5" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Filter by mood (energetic, cinematic, lo-fi), category (whoosh, impact), or tag..."
          className="w-full bg-neutral-950 border border-neutral-800 focus:border-purple-500 text-neutral-200 text-xs pl-8 pr-3 py-2 rounded-lg outline-none"
        />
      </div>

      {/* Asset Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-72 overflow-y-auto pr-1">
        {filteredAssets.map((asset) => {
          const isSelected = selectedAssetId === asset.assetId;
          const isPlaying = playingId === asset.assetId;

          return (
            <div
              key={asset.assetId}
              className={`p-3 rounded-lg border transition-all flex flex-col justify-between ${
                isSelected
                  ? 'border-purple-500 bg-purple-950/20'
                  : 'border-neutral-800/80 bg-neutral-950/70 hover:border-neutral-700'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span
                    className={`p-1 rounded text-[10px] font-mono uppercase font-semibold flex items-center gap-1 ${
                      asset.type === 'music'
                        ? 'bg-purple-500/10 text-purple-300'
                        : 'bg-amber-500/10 text-amber-300'
                    }`}
                  >
                    {asset.type === 'music' ? (
                      <Music className="w-3 h-3" />
                    ) : (
                      <Volume2 className="w-3 h-3" />
                    )}
                    <span>{asset.category}</span>
                  </span>
                  <span className="text-[10px] font-mono text-neutral-500">
                    {asset.durationSeconds}s
                  </span>
                </div>

                <div className="text-xs font-medium text-white mt-2 truncate">
                  {asset.title || asset.filename}
                </div>
                <div className="text-[11px] text-neutral-400 capitalize mt-0.5">
                  Mood: {asset.mood} {asset.bpm ? `• ${asset.bpm} BPM` : ''}
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-neutral-800/60 flex items-center justify-between text-[10px]">
                <div className="flex items-center gap-1.5">
                  <span className="px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300 font-mono">
                    {asset.license}
                  </span>
                  {asset.energyLevel && (
                    <span className="text-neutral-500 font-mono capitalize">
                      {asset.energyLevel} energy
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => togglePlay(asset.assetId)}
                  className={`px-2 py-0.5 rounded font-medium transition-colors ${
                    isPlaying
                      ? 'bg-purple-500 text-white'
                      : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                  }`}
                >
                  {isPlaying ? 'Playing...' : 'Preview'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
