import React, { useState } from 'react';
import {
  Video,
  Mic,
  Music,
  Volume2,
  Type,
  ShieldCheck,
  Maximize2,
  TrendingDown,
  Sparkles,
} from 'lucide-react';
import { TimelineArtifact } from '../contracts/timeline.ts';
import { SelectedAudioAsset } from '../contracts/assets.ts';

interface TimelineVisualizerProps {
  timeline: TimelineArtifact;
  assets?: {
    musicTrack?: SelectedAudioAsset;
    sfxTracks?: SelectedAudioAsset[];
  };
}

export const TimelineVisualizer: React.FC<TimelineVisualizerProps> = ({
  timeline,
  assets,
}) => {
  const [activeTab, setActiveTab] = useState<'tracks' | 'safezone' | 'ducking'>('tracks');
  const [hoveredElement, setHoveredElement] = useState<string | null>(null);

  const totalDuration = timeline.totalDurationSeconds || 15;
  const isShort = timeline.format === 'short';

  // Helper to convert timestamp to percentage
  const getPercent = (time: number) => Math.min(100, Math.max(0, (time / totalDuration) * 100));

  return (
    <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-5 space-y-4">
      {/* Header & View Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-white">Multi-Track Timeline Sequence</h3>
            <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-neutral-800 text-neutral-300">
              {timeline.format.toUpperCase()} ({timeline.aspectRatio}) • {totalDuration.toFixed(1)}s Total
            </span>
          </div>
          <p className="text-xs text-neutral-400">
            Automated synchronization across video, voiceover, ducked music, sound effects, and safe-zone typography
          </p>
        </div>

        <div className="flex items-center bg-neutral-950 p-1 rounded-lg border border-neutral-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('tracks')}
            className={`px-3 py-1 rounded font-medium transition-all ${
              activeTab === 'tracks'
                ? 'bg-neutral-800 text-white'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Track View
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('safezone')}
            className={`px-3 py-1 rounded font-medium transition-all ${
              activeTab === 'safezone'
                ? 'bg-neutral-800 text-white'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Safe Zone HUD
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ducking')}
            className={`px-3 py-1 rounded font-medium transition-all ${
              activeTab === 'ducking'
                ? 'bg-neutral-800 text-white'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Audio Ducking
          </button>
        </div>
      </div>

      {activeTab === 'tracks' && (
        <div className="space-y-3 font-mono text-xs">
          {/* Time Ruler */}
          <div className="relative h-6 bg-neutral-950 rounded border border-neutral-800/80 px-2 flex items-center justify-between text-[10px] text-neutral-500 select-none">
            <span>0.0s</span>
            <span>{(totalDuration * 0.25).toFixed(1)}s</span>
            <span>{(totalDuration * 0.5).toFixed(1)}s</span>
            <span>{(totalDuration * 0.75).toFixed(1)}s</span>
            <span>{totalDuration.toFixed(1)}s</span>
          </div>

          {/* Track 1: Video Track */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[11px] text-neutral-400 px-1">
              <span className="flex items-center gap-1.5 font-medium text-neutral-300">
                <Video className="w-3.5 h-3.5 text-blue-400" />
                <span>Track 1: Video &amp; Motion</span>
              </span>
              <span>{timeline.tracks.video.length} scenes</span>
            </div>
            <div className="relative h-12 bg-neutral-950/80 rounded-lg border border-neutral-800 overflow-hidden p-1 flex">
              {timeline.tracks.video.map((v, i) => {
                const widthPercent = (v.durationSeconds / totalDuration) * 100;
                return (
                  <div
                    key={v.elementId}
                    style={{ width: `${widthPercent}%` }}
                    className="h-full bg-blue-950/40 border border-blue-600/40 rounded p-1.5 flex flex-col justify-between hover:bg-blue-900/40 transition-colors mr-0.5 last:mr-0 group cursor-default"
                    title={`Scene ${i + 1}: ${v.sceneId} (${v.durationSeconds}s, Motion: ${v.motionEffect})`}
                  >
                    <div className="flex items-center justify-between text-[10px] text-blue-300 font-semibold truncate">
                      <span>Sc {i + 1}</span>
                      <span className="text-[9px] text-blue-400/80">{v.durationSeconds}s</span>
                    </div>
                    <div className="flex items-center gap-1 text-[9px] text-neutral-400 truncate">
                      <span className="px-1 bg-blue-900/50 rounded text-blue-200">
                        {v.motionEffect.replace('ken_burns_', '')}
                      </span>
                      <span className="truncate text-neutral-500">{v.cropOrScale.scaleMode}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Track 2: Narration Voiceover */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[11px] text-neutral-400 px-1">
              <span className="flex items-center gap-1.5 font-medium text-neutral-300">
                <Mic className="w-3.5 h-3.5 text-emerald-400" />
                <span>Track 2: Voice Narration (TTS)</span>
              </span>
              <span>100% Volume • Master Audio</span>
            </div>
            <div className="relative h-10 bg-neutral-950/80 rounded-lg border border-neutral-800 overflow-hidden p-1 flex">
              {timeline.tracks.narration.map((n, i) => {
                const leftPercent = getPercent(n.startTimelineSeconds);
                const widthPercent = (n.durationSeconds / totalDuration) * 100;
                return (
                  <div
                    key={n.elementId}
                    style={{ left: `${leftPercent}%`, width: `${widthPercent}%` }}
                    className="absolute h-8 top-1 bg-emerald-950/50 border border-emerald-500/40 rounded px-2 flex items-center justify-between text-[10px] text-emerald-300 hover:bg-emerald-900/50 transition-colors"
                  >
                    <span className="font-semibold truncate">Seg {i + 1}</span>
                    <span className="text-[9px] text-emerald-400/80">{n.durationSeconds}s</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Track 3: Background Music Track */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[11px] text-neutral-400 px-1">
              <span className="flex items-center gap-1.5 font-medium text-neutral-300">
                <Music className="w-3.5 h-3.5 text-purple-400" />
                <span>Track 3: Music Bed</span>
              </span>
              <span className="text-purple-300">
                {assets?.musicTrack?.asset.title || 'Dynamic Track'} • Auto Ducking Active (15% during voice)
              </span>
            </div>
            <div className="relative h-10 bg-neutral-950/80 rounded-lg border border-neutral-800 overflow-hidden p-1">
              {timeline.tracks.music.map((m) => (
                <div
                  key={m.elementId}
                  className="h-full bg-purple-950/40 border border-purple-500/40 rounded px-2 flex items-center justify-between text-[10px] text-purple-300"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">BGM Base: {m.volume * 100}%</span>
                    <span className="px-1.5 py-0.5 bg-purple-900/60 rounded text-[9px] text-purple-200">
                      Envelope points: {m.duckingEnvelope?.length || 0}
                    </span>
                  </div>
                  <span className="text-[9px] text-purple-400">Continuous Loop</span>
                </div>
              ))}
            </div>
          </div>

          {/* Track 4: Sound Effects (SFX) */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[11px] text-neutral-400 px-1">
              <span className="flex items-center gap-1.5 font-medium text-neutral-300">
                <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Track 4: SFX Accents &amp; Impacts</span>
              </span>
              <span>{timeline.tracks.sfx.length} cues</span>
            </div>
            <div className="relative h-9 bg-neutral-950/80 rounded-lg border border-neutral-800 overflow-hidden p-1">
              {timeline.tracks.sfx.map((s, i) => {
                const left = getPercent(s.startTimelineSeconds);
                return (
                  <div
                    key={s.elementId}
                    style={{ left: `${left}%` }}
                    className="absolute top-1 h-7 px-2 bg-amber-950/60 border border-amber-500/40 rounded flex items-center gap-1 text-[9px] text-amber-300 hover:bg-amber-900/60"
                    title={`SFX ${i + 1}: ${s.audioFilePath} at ${s.startTimelineSeconds}s`}
                  >
                    <Sparkles className="w-2.5 h-2.5 text-amber-400" />
                    <span>{s.audioFilePath.split('/').pop()?.replace('.wav', '') || 'SFX'}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Track 5: Captions & Text Overlays */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[11px] text-neutral-400 px-1">
              <span className="flex items-center gap-1.5 font-medium text-neutral-300">
                <Type className="w-3.5 h-3.5 text-cyan-400" />
                <span>Track 5: Safe-Zone Typography &amp; Captions</span>
              </span>
              <span>{timeline.tracks.textOverlays.length} overlays</span>
            </div>
            <div className="relative h-10 bg-neutral-950/80 rounded-lg border border-neutral-800 overflow-hidden p-1 flex">
              {timeline.tracks.textOverlays.map((t, i) => {
                const leftPercent = getPercent(t.startTimelineSeconds);
                const widthPercent = (t.durationSeconds / totalDuration) * 100;
                return (
                  <div
                    key={t.elementId}
                    style={{ left: `${leftPercent}%`, width: `${widthPercent}%` }}
                    className="absolute h-8 top-1 bg-cyan-950/40 border border-cyan-500/40 rounded px-2 flex items-center justify-between text-[10px] text-cyan-200 truncate hover:bg-cyan-900/40"
                    title={t.primaryText}
                  >
                    <span className="truncate max-w-[80%] font-medium">"{t.primaryText}"</span>
                    <span className="text-[9px] px-1 bg-cyan-900/50 rounded text-cyan-300">
                      {t.styleVariant}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Safe Zone Visualizer View */}
      {activeTab === 'safezone' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center p-4 bg-neutral-950 rounded-lg border border-neutral-800">
          <div className="flex justify-center">
            {/* Phone Simulator Frame */}
            <div
              className={`relative border-2 border-neutral-700 bg-neutral-900 rounded-2xl shadow-xl overflow-hidden ${
                isShort ? 'w-56 h-96' : 'w-96 h-56'
              }`}
            >
              {/* Native UI Danger Zones */}
              <div className="absolute inset-x-0 top-0 h-[15%] bg-rose-950/30 border-b border-rose-500/30 flex items-center justify-center text-[9px] text-rose-300 font-mono">
                System Header Safe Margin (15%)
              </div>
              <div className="absolute inset-x-0 bottom-0 h-[20%] bg-rose-950/30 border-t border-rose-500/30 flex items-center justify-center text-[9px] text-rose-300 font-mono">
                Captions / Audio UI Margin (20%)
              </div>
              <div className="absolute right-0 inset-y-0 w-[18%] bg-amber-950/20 border-l border-amber-500/30 flex items-center justify-center text-[8px] text-amber-300 font-mono write-vertical">
                Actions UI (18%)
              </div>

              {/* Verified Safe Zone Box */}
              <div className="absolute top-[15%] bottom-[20%] left-[8%] right-[18%] border-2 border-dashed border-emerald-500/80 bg-emerald-500/5 rounded-lg flex flex-col items-center justify-center p-3 text-center">
                <ShieldCheck className="w-6 h-6 text-emerald-400 mb-1" />
                <span className="text-[11px] font-bold text-white leading-snug">
                  Safe Zone Compliant Area
                </span>
                <span className="text-[9px] text-neutral-400 mt-1">
                  All typography, badges, and focal subjects stay inside this boundary
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-3 text-xs text-neutral-300">
            <h4 className="font-semibold text-sm text-white flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Platform Safe Zone Standards ({timeline.aspectRatio})</span>
            </h4>
            <p className="text-neutral-400 leading-relaxed">
              ClipForge automatically computes UI obstructions for TikTok, Instagram Reels, and YouTube Shorts to guarantee no title, caption, or key visual element gets clipped by app chrome.
            </p>
            <ul className="space-y-2 font-mono text-[11px] text-neutral-400">
              <li className="flex justify-between py-1 border-b border-neutral-800">
                <span>Top Safe Margin:</span>
                <span className="text-white">{timeline.safeZone.topPercent}% (Avoid search / tabs)</span>
              </li>
              <li className="flex justify-between py-1 border-b border-neutral-800">
                <span>Bottom Safe Margin:</span>
                <span className="text-white">{timeline.safeZone.bottomPercent}% (Avoid captions / audio)</span>
              </li>
              <li className="flex justify-between py-1 border-b border-neutral-800">
                <span>Right Safe Margin:</span>
                <span className="text-white">{timeline.safeZone.rightPercent}% (Avoid like / share buttons)</span>
              </li>
              <li className="flex justify-between py-1 border-b border-neutral-800">
                <span>Left Safe Margin:</span>
                <span className="text-white">{timeline.safeZone.leftPercent}% (Screen edge buffer)</span>
              </li>
            </ul>
          </div>
        </div>
      )}

      {/* Audio Ducking View */}
      {activeTab === 'ducking' && (
        <div className="space-y-4 p-4 bg-neutral-950 rounded-lg border border-neutral-800">
          <div>
            <h4 className="text-xs font-semibold text-white flex items-center gap-1.5">
              <TrendingDown className="w-4 h-4 text-purple-400" />
              <span>Ducking Envelope Visualization</span>
            </h4>
            <p className="text-[11px] text-neutral-400">
              Music auto-ducks to 15% when speech is detected, smoothly rising to 100% during natural narration pauses (&gt;0.4s).
            </p>
          </div>

          <div className="relative h-24 bg-neutral-900 rounded border border-neutral-800 p-2 flex items-end">
            <div className="absolute top-2 left-2 text-[10px] font-mono text-purple-300">100% (Music Intro / Pause)</div>
            <div className="absolute bottom-6 left-2 text-[10px] font-mono text-purple-400">15% (Ducked for Voice)</div>
            <div className="w-full h-16 border-b border-purple-500/30 relative flex items-center">
              {/* Curve simulation */}
              <svg className="w-full h-full" preserveAspectRatio="none" viewBox="0 0 100 50">
                <path
                  d="M 0 5 L 8 40 L 45 40 L 50 10 L 60 10 L 65 40 L 92 40 L 100 5"
                  fill="none"
                  stroke="#a855f7"
                  strokeWidth="2"
                />
              </svg>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
