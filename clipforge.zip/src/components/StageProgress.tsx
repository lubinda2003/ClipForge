import React from 'react';
import {
  Search,
  Target,
  FileText,
  Mic,
  Clapperboard,
  Video,
  Layers,
  CheckCircle2,
  Clock,
  AlertCircle,
} from 'lucide-react';

export interface StageInfo {
  id: string;
  name: string;
  description: string;
  status: 'pending' | 'running' | 'completed' | 'error';
  executionTimeMs?: number;
  summary?: string;
  artifactKey: string;
}

interface StageProgressProps {
  stages: StageInfo[];
  activeStageId: string;
  onSelectStage: (stageId: string) => void;
}

const STAGE_ICONS: Record<string, React.ReactNode> = {
  research: <Search className="w-4 h-4" />,
  strategy: <Target className="w-4 h-4" />,
  script: <FileText className="w-4 h-4" />,
  narration: <Mic className="w-4 h-4" />,
  scenes: <Clapperboard className="w-4 h-4" />,
  broll: <Video className="w-4 h-4" />,
  timeline: <Layers className="w-4 h-4" />,
};

export const StageProgress: React.FC<StageProgressProps> = ({
  stages,
  activeStageId,
  onSelectStage,
}) => {
  return (
    <div className="bg-neutral-900/50 border border-neutral-800 rounded-xl p-4">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-sm font-semibold text-white tracking-wide">Production Pipeline Stages</h2>
          <p className="text-xs text-neutral-400">Sequential multi-stage synthesis and automated artifacts</p>
        </div>
        <div className="text-xs font-mono text-neutral-500">
          Completed: {stages.filter((s) => s.status === 'completed').length} / {stages.length}
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
        {stages.map((stage, idx) => {
          const isSelected = activeStageId === stage.id;
          const isCompleted = stage.status === 'completed';
          const isRunning = stage.status === 'running';

          return (
            <button
              key={stage.id}
              type="button"
              onClick={() => onSelectStage(stage.id)}
              className={`p-3 rounded-lg border text-left transition-all relative flex flex-col justify-between ${
                isSelected
                  ? 'border-emerald-500 bg-emerald-950/20 text-white'
                  : 'border-neutral-800/80 bg-neutral-950/60 text-neutral-300 hover:border-neutral-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span
                  className={`p-1.5 rounded-md ${
                    isCompleted
                      ? 'bg-emerald-500/10 text-emerald-400'
                      : isRunning
                      ? 'bg-amber-500/10 text-amber-400 animate-pulse'
                      : 'bg-neutral-800 text-neutral-400'
                  }`}
                >
                  {STAGE_ICONS[stage.id] || <Layers className="w-4 h-4" />}
                </span>
                <span className="text-[10px] font-mono text-neutral-500">0{idx + 1}</span>
              </div>

              <div>
                <div className="text-xs font-medium text-neutral-200 truncate">{stage.name}</div>
                <div className="text-[10px] text-neutral-400 truncate mt-0.5">{stage.description}</div>
              </div>

              <div className="mt-3 pt-2 border-t border-neutral-800/60 flex items-center justify-between text-[10px] font-mono">
                {isCompleted ? (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>{stage.executionTimeMs}ms</span>
                  </span>
                ) : isRunning ? (
                  <span className="text-amber-400 flex items-center gap-1">
                    <Clock className="w-3 h-3 animate-spin" />
                    <span>Running</span>
                  </span>
                ) : (
                  <span className="text-neutral-500">Standby</span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
