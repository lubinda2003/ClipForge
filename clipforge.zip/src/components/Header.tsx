import React from 'react';
import { Play, Sparkles, CheckCircle2, Film, Terminal } from 'lucide-react';

interface HeaderProps {
  topic: string;
  setTopic: (topic: string) => void;
  format: 'short' | 'long';
  setFormat: (format: 'short' | 'long') => void;
  isRunning: boolean;
  onRunPipeline: () => void;
  activePreset: string;
  onSelectPreset: (preset: string) => void;
}

const PRESETS = [
  'Nuclear Fusion Breakthrough 2026',
  'How Quantum Computers Actually Work',
  'Why Concorde Stopped Flying',
  'Deep Ocean Trench Exploration',
];

export const Header: React.FC<HeaderProps> = ({
  topic,
  setTopic,
  format,
  setFormat,
  isRunning,
  onRunPipeline,
  activePreset,
  onSelectPreset,
}) => {
  return (
    <header className="border-b border-neutral-800 bg-neutral-900/70 backdrop-blur sticky top-0 z-30 px-6 py-4">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Logo & Status Badge */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Film className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-bold tracking-tight text-white">ClipForge</h1>
              <span className="px-2 py-0.5 text-[11px] font-mono font-medium rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                <span>Engine Active • 94 Tests Passing</span>
              </span>
            </div>
            <p className="text-xs text-neutral-400">
              Headless AI Video Pipeline • Phases 1–5 Built &amp; Validated
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Format Toggle */}
          <div className="flex items-center bg-neutral-950 p-1 rounded-lg border border-neutral-800 text-xs">
            <button
              type="button"
              onClick={() => setFormat('short')}
              className={`px-3 py-1.5 rounded-md font-medium transition-all ${
                format === 'short'
                  ? 'bg-neutral-800 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              Short-Form (9:16)
            </button>
            <button
              type="button"
              onClick={() => setFormat('long')}
              className={`px-3 py-1.5 rounded-md font-medium transition-all ${
                format === 'long'
                  ? 'bg-neutral-800 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              Long-Form (16:9)
            </button>
          </div>

          {/* Run Button */}
          <button
            type="button"
            onClick={onRunPipeline}
            disabled={isRunning || !topic.trim()}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-neutral-950 font-semibold text-xs rounded-lg transition-all shadow-md active:scale-95 cursor-pointer"
          >
            {isRunning ? (
              <>
                <span className="w-3.5 h-3.5 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                <span>Synthesizing...</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Run Pipeline</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Topic Input Bar */}
      <div className="max-w-7xl mx-auto mt-4 pt-3 border-t border-neutral-800/60 flex flex-col md:flex-row items-start md:items-center gap-3">
        <div className="flex items-center gap-2 text-xs text-neutral-400 w-full md:w-auto">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          <span className="whitespace-nowrap font-medium text-neutral-300">Topic Prompt:</span>
        </div>
        <div className="flex-1 w-full">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="Enter any video topic..."
            className="w-full bg-neutral-950 border border-neutral-800 focus:border-emerald-500 text-neutral-200 text-xs px-3 py-2 rounded-lg outline-none transition-colors"
          />
        </div>
        <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
          <span className="text-neutral-500 text-[10px] uppercase tracking-wider font-semibold mr-1">Presets:</span>
          {PRESETS.map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => onSelectPreset(p)}
              className={`px-2 py-1 rounded border transition-colors ${
                activePreset === p
                  ? 'border-emerald-500/50 bg-emerald-500/10 text-emerald-300'
                  : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-neutral-200 hover:border-neutral-700'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};
