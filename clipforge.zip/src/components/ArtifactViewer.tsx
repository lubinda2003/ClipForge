import React, { useState } from 'react';
import { Code, Copy, Check, FileJson, Terminal } from 'lucide-react';

interface ArtifactViewerProps {
  stageId: string;
  stageName: string;
  artifactData: unknown;
  cliCommand: string;
}

export const ArtifactViewer: React.FC<ArtifactViewerProps> = ({
  stageId,
  stageName,
  artifactData,
  cliCommand,
}) => {
  const [copiedJson, setCopiedJson] = useState(false);
  const [copiedCli, setCopiedCli] = useState(false);

  const jsonString = JSON.stringify(artifactData, null, 2);

  const handleCopyJson = () => {
    navigator.clipboard.writeText(jsonString);
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  const handleCopyCli = () => {
    navigator.clipboard.writeText(cliCommand);
    setCopiedCli(true);
    setTimeout(() => setCopiedCli(false), 2000);
  };

  return (
    <div className="bg-neutral-900/50 border border-neutral-800 rounded-xl p-5 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-white">Stage Artifact Inspector</h3>
            <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              {stageName} ({stageId}.json)
            </span>
          </div>
          <p className="text-xs text-neutral-400">
            Immutable JSON output contract for automated batch rendering
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopyJson}
            className="flex items-center gap-1.5 px-3 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs rounded font-mono transition-colors"
          >
            {copiedJson ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>Copy Artifact</span>
          </button>
        </div>
      </div>

      {/* CLI Command Box */}
      <div className="bg-neutral-950 border border-neutral-800 rounded-lg p-3 flex items-center justify-between font-mono text-xs text-neutral-300">
        <div className="flex items-center gap-2 overflow-x-auto whitespace-nowrap">
          <Terminal className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="text-neutral-500">$</span>
          <span className="text-emerald-300">{cliCommand}</span>
        </div>
        <button
          type="button"
          onClick={handleCopyCli}
          className="ml-3 p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
          title="Copy CLI command"
        >
          {copiedCli ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* JSON Viewer */}
      <div className="bg-neutral-950 border border-neutral-800 rounded-lg p-4 font-mono text-[11px] text-neutral-300 max-h-80 overflow-y-auto">
        <pre className="whitespace-pre-wrap">{jsonString}</pre>
      </div>
    </div>
  );
};
