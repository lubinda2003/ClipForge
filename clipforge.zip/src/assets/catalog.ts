/**
 * ClipForge Audio Asset Catalog
 * In-memory searchable index of curated royalty-free music and SFX metadata.
 */

import { AudioAssetMetadata, MusicCategory, SfxCategory } from '../contracts/assets.ts';
import { AudioSearchCriteria, IAudioAssetProvider } from './types.ts';

export const DEFAULT_CURATED_AUDIO_CATALOG: AudioAssetMetadata[] = [
  // Energetic Music
  {
    assetId: 'mus_eng_pulse_01',
    filename: 'cybernetic_pulse.mp3',
    type: 'music',
    category: 'energetic',
    mood: 'energetic',
    energyLevel: 'high',
    durationSeconds: 120.0,
    bpm: 128,
    tempo: 'fast',
    license: 'Royalty-Free Commercial',
    source: 'ClipForge Curated Soundstage',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/music/energetic/cybernetic_pulse.mp3',
    checksumSha256: 'a1b2c3d4e5f60102030405060708090a1b2c3d4e5f6010203040506070809001',
    loopable: true,
    tags: ['synth', 'driving', 'tech', 'punchy'],
    description: 'Fast-paced cybernetic electronic beat ideal for high-retention short-form tech and science videos.',
  },
  {
    assetId: 'mus_eng_velocity_02',
    filename: 'hyper_velocity.mp3',
    type: 'music',
    category: 'energetic',
    mood: 'motivational',
    energyLevel: 'high',
    durationSeconds: 95.0,
    bpm: 135,
    tempo: 'fast',
    license: 'Royalty-Free Commercial',
    source: 'ClipForge Curated Soundstage',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/music/energetic/hyper_velocity.mp3',
    checksumSha256: 'a1b2c3d4e5f60102030405060708090a1b2c3d4e5f6010203040506070809002',
    loopable: true,
    tags: ['bass', 'adrenaline', 'action'],
    description: 'Upbeat electronic rhythm with prominent percussive drops.',
  },
  // Technology Music
  {
    assetId: 'mus_tech_silicon_01',
    filename: 'silicon_horizons.mp3',
    type: 'music',
    category: 'technology',
    mood: 'analytical',
    energyLevel: 'medium',
    durationSeconds: 150.0,
    bpm: 115,
    tempo: 'medium',
    license: 'Royalty-Free Commercial',
    source: 'ClipForge Curated Soundstage',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/music/technology/silicon_horizons.mp3',
    checksumSha256: 'a1b2c3d4e5f60102030405060708090a1b2c3d4e5f6010203040506070809003',
    loopable: true,
    tags: ['digital', 'clean', 'futuristic', 'deep'],
    description: 'Modern algorithmic synth layers suited for AI, engineering, and deep science breakthroughs.',
  },
  {
    assetId: 'mus_tech_data_02',
    filename: 'data_stream_alpha.mp3',
    type: 'music',
    category: 'technology',
    mood: 'curious',
    energyLevel: 'medium',
    durationSeconds: 180.0,
    bpm: 110,
    tempo: 'medium',
    license: 'Royalty-Free Commercial',
    source: 'ClipForge Curated Soundstage',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/music/technology/data_stream_alpha.mp3',
    checksumSha256: 'a1b2c3d4e5f60102030405060708090a1b2c3d4e5f6010203040506070809004',
    loopable: true,
    tags: ['computing', 'stream', 'precision'],
    description: 'Crisp minimal synth pulses that stay unobtrusive underneath vocal narration.',
  },
  // Cinematic Music
  {
    assetId: 'mus_cin_odyssey_01',
    filename: 'sovereign_odyssey.mp3',
    type: 'music',
    category: 'cinematic',
    mood: 'epic',
    energyLevel: 'high',
    durationSeconds: 210.0,
    bpm: 100,
    tempo: 'medium',
    license: 'Royalty-Free Commercial',
    source: 'ClipForge Curated Soundstage',
    commercialUsePermitted: true,
    attributionRequired: true,
    attributionText: 'Music by ClipForge Audio Labs (CC-BY 4.0)',
    r2Path: 'assets/music/cinematic/sovereign_odyssey.mp3',
    checksumSha256: 'a1b2c3d4e5f60102030405060708090a1b2c3d4e5f6010203040506070809005',
    loopable: false,
    tags: ['orchestral', 'strings', 'climax', 'space'],
    description: 'Expansive orchestral build designed for dramatic revelations and long-form storytelling.',
  },
  {
    assetId: 'mus_cin_horizon_02',
    filename: 'infinite_horizon.mp3',
    type: 'music',
    category: 'cinematic',
    mood: 'inspiring',
    energyLevel: 'medium',
    durationSeconds: 195.0,
    bpm: 95,
    tempo: 'medium',
    license: 'Royalty-Free Commercial',
    source: 'ClipForge Curated Soundstage',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/music/cinematic/infinite_horizon.mp3',
    checksumSha256: 'a1b2c3d4e5f60102030405060708090a1b2c3d4e5f6010203040506070809006',
    loopable: true,
    tags: ['sweeping', 'piano', 'noble'],
    description: 'Sweeping cinematic strings and gentle piano melodies.',
  },
  // Documentary Music
  {
    assetId: 'mus_doc_investigation_01',
    filename: 'the_inquiry.mp3',
    type: 'music',
    category: 'documentary',
    mood: 'serious',
    energyLevel: 'low',
    durationSeconds: 240.0,
    bpm: 85,
    tempo: 'slow',
    license: 'Royalty-Free Commercial',
    source: 'ClipForge Curated Soundstage',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/music/documentary/the_inquiry.mp3',
    checksumSha256: 'a1b2c3d4e5f60102030405060708090a1b2c3d4e5f6010203040506070809007',
    loopable: true,
    tags: ['acoustic', 'investigative', 'subtle', 'history'],
    description: 'Somber acoustic guitar and atmospheric cello for investigative journalism and historical breakdowns.',
  },
  {
    assetId: 'mus_doc_frontiers_02',
    filename: 'scientific_frontiers.mp3',
    type: 'music',
    category: 'documentary',
    mood: 'contemplative',
    energyLevel: 'medium',
    durationSeconds: 220.0,
    bpm: 90,
    tempo: 'slow',
    license: 'Royalty-Free Commercial',
    source: 'ClipForge Curated Soundstage',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/music/documentary/scientific_frontiers.mp3',
    checksumSha256: 'a1b2c3d4e5f60102030405060708090a1b2c3d4e5f6010203040506070809008',
    loopable: true,
    tags: ['organic', 'thoughtful', 'discovery'],
    description: 'Steady, contemplative rhythm that keeps audience attention focused on the narrative facts.',
  },
  // Suspense Music
  {
    assetId: 'mus_sus_tension_01',
    filename: 'tension_wire.mp3',
    type: 'music',
    category: 'suspense',
    mood: 'tense',
    energyLevel: 'medium',
    durationSeconds: 130.0,
    bpm: 105,
    tempo: 'medium',
    license: 'Royalty-Free Commercial',
    source: 'ClipForge Curated Soundstage',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/music/suspense/tension_wire.mp3',
    checksumSha256: 'a1b2c3d4e5f60102030405060708090a1b2c3d4e5f6010203040506070809009',
    loopable: true,
    tags: ['clock', 'heartbeat', 'mystery'],
    description: 'Subtle heartbeat kick and high frequency ticking creating urgent curiosity.',
  },
  // Inspirational Music
  {
    assetId: 'mus_ins_triumph_01',
    filename: 'triumphant_step.mp3',
    type: 'music',
    category: 'inspirational',
    mood: 'uplifting',
    energyLevel: 'high',
    durationSeconds: 160.0,
    bpm: 120,
    tempo: 'medium',
    license: 'Royalty-Free Commercial',
    source: 'ClipForge Curated Soundstage',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/music/inspirational/triumphant_step.mp3',
    checksumSha256: 'a1b2c3d4e5f60102030405060708090a1b2c3d4e5f6010203040506070809010',
    loopable: true,
    tags: ['anthemic', 'progress', 'bright'],
    description: 'Warm crescendo with uplifting chords, great for visionary conclusions.',
  },
  // Neutral Music
  {
    assetId: 'mus_neu_ambient_01',
    filename: 'minimal_flow.mp3',
    type: 'music',
    category: 'neutral',
    mood: 'neutral',
    energyLevel: 'low',
    durationSeconds: 300.0,
    bpm: 80,
    tempo: 'slow',
    license: 'Royalty-Free Commercial',
    source: 'ClipForge Curated Soundstage',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/music/neutral/minimal_flow.mp3',
    checksumSha256: 'a1b2c3d4e5f60102030405060708090a1b2c3d4e5f6010203040506070809011',
    loopable: true,
    tags: ['ambient', 'soft', 'subtle'],
    description: 'Transparent ambient pad texture that never clashes with spoken frequencies.',
  },

  // SFX: Whoosh
  {
    assetId: 'sfx_whoosh_clean_01',
    filename: 'fast_air_whoosh.wav',
    type: 'sfx',
    category: 'whoosh',
    mood: 'dynamic',
    energyLevel: 'medium',
    durationSeconds: 0.65,
    license: 'CC0 Universal',
    source: 'ClipForge Curated SFX Library',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/sfx/whoosh/fast_air_whoosh.wav',
    checksumSha256: 'b1c2d3e4f50102030405060708090a1b2c3d4e5f60102030405060708090001',
    tags: ['air', 'swish', 'passby'],
    description: 'Short crisp air swoosh for fast cuts and visual entrances.',
  },
  {
    assetId: 'sfx_whoosh_dramatic_02',
    filename: 'cinematic_heavy_whoosh.wav',
    type: 'sfx',
    category: 'whoosh',
    mood: 'dramatic',
    energyLevel: 'high',
    durationSeconds: 1.15,
    license: 'CC0 Universal',
    source: 'ClipForge Curated SFX Library',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/sfx/whoosh/cinematic_heavy_whoosh.wav',
    checksumSha256: 'b1c2d3e4f50102030405060708090a1b2c3d4e5f60102030405060708090002',
    tags: ['heavy', 'cinematic', 'transition'],
    description: 'Low-frequency bass whoosh for opening hooks and major scene shifts.',
  },

  // SFX: Impact
  {
    assetId: 'sfx_impact_sub_01',
    filename: 'sub_thud_impact.wav',
    type: 'sfx',
    category: 'impact',
    mood: 'punchy',
    energyLevel: 'high',
    durationSeconds: 1.4,
    license: 'CC0 Universal',
    source: 'ClipForge Curated SFX Library',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/sfx/impact/sub_thud_impact.wav',
    checksumSha256: 'b1c2d3e4f50102030405060708090a1b2c3d4e5f60102030405060708090003',
    tags: ['boom', 'sub', 'punch', 'reveal'],
    description: 'Deep cinematic impact accent for high-stakes assertions.',
  },

  // SFX: Riser
  {
    assetId: 'sfx_riser_tension_01',
    filename: 'electronic_pitch_riser.wav',
    type: 'sfx',
    category: 'riser',
    mood: 'tense',
    energyLevel: 'medium',
    durationSeconds: 2.1,
    license: 'CC0 Universal',
    source: 'ClipForge Curated SFX Library',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/sfx/riser/electronic_pitch_riser.wav',
    checksumSha256: 'b1c2d3e4f50102030405060708090a1b2c3d4e5f60102030405060708090004',
    tags: ['build', 'pitch', 'anticipation'],
    description: 'Smooth rising pitch buildup towards key punchlines.',
  },

  // SFX: Hit
  {
    assetId: 'sfx_hit_accent_01',
    filename: 'tight_hit_accent.wav',
    type: 'sfx',
    category: 'hit',
    mood: 'punchy',
    energyLevel: 'medium',
    durationSeconds: 0.45,
    license: 'CC0 Universal',
    source: 'ClipForge Curated SFX Library',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/sfx/hit/tight_hit_accent.wav',
    checksumSha256: 'b1c2d3e4f50102030405060708090a1b2c3d4e5f60102030405060708090005',
    tags: ['accent', 'staccato', 'beat'],
    description: 'Instant percussive hit for text highlights.',
  },

  // SFX: Transition
  {
    assetId: 'sfx_trans_shutter_01',
    filename: 'camera_shutter_swish.wav',
    type: 'sfx',
    category: 'transition',
    mood: 'modern',
    energyLevel: 'medium',
    durationSeconds: 0.85,
    license: 'CC0 Universal',
    source: 'ClipForge Curated SFX Library',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/sfx/transition/camera_shutter_swish.wav',
    checksumSha256: 'b1c2d3e4f50102030405060708090a1b2c3d4e5f60102030405060708090006',
    tags: ['shutter', 'whoosh', 'cut'],
    description: 'Camera click and whoosh combined for visual cut emphasis.',
  },

  // SFX: Click
  {
    assetId: 'sfx_click_tech_01',
    filename: 'digital_data_tap.wav',
    type: 'sfx',
    category: 'click',
    mood: 'crisp',
    energyLevel: 'low',
    durationSeconds: 0.25,
    license: 'CC0 Universal',
    source: 'ClipForge Curated SFX Library',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/sfx/click/digital_data_tap.wav',
    checksumSha256: 'b1c2d3e4f50102030405060708090a1b2c3d4e5f60102030405060708090007',
    tags: ['ui', 'data', 'stat', 'tap'],
    description: 'Micro UI click designed for number tickers and statistic callout appearances.',
  },

  // SFX: Glitch
  {
    assetId: 'sfx_glitch_stutter_01',
    filename: 'data_glitch_stutter.wav',
    type: 'sfx',
    category: 'glitch',
    mood: 'disruptive',
    energyLevel: 'high',
    durationSeconds: 0.6,
    license: 'CC0 Universal',
    source: 'ClipForge Curated SFX Library',
    commercialUsePermitted: true,
    attributionRequired: false,
    r2Path: 'assets/sfx/glitch/data_glitch_stutter.wav',
    checksumSha256: 'b1c2d3e4f50102030405060708090a1b2c3d4e5f60102030405060708090008',
    tags: ['glitch', 'digital', 'interrupt', 'noise'],
    description: 'Sharp digital distortion designed for pattern interrupts and contrast shifts.',
  },
];

export class AudioAssetCatalog {
  private assets: Map<string, AudioAssetMetadata> = new Map();

  constructor(initialAssets?: AudioAssetMetadata[]) {
    const list = initialAssets || DEFAULT_CURATED_AUDIO_CATALOG;
    for (const item of list) {
      this.assets.set(item.assetId, { ...item });
    }
  }

  public registerAsset(asset: AudioAssetMetadata): void {
    this.assets.set(asset.assetId, { ...asset });
  }

  public count(): number {
    return this.assets.size;
  }

  public getAll(): AudioAssetMetadata[] {
    return Array.from(this.assets.values());
  }

  public getAllAssets(): AudioAssetMetadata[] {
    return Array.from(this.assets.values());
  }

  public getAssetById(assetId: string): AudioAssetMetadata | undefined {
    return this.assets.get(assetId);
  }

  public query(criteria: AudioSearchCriteria): AudioAssetMetadata[] {
    return Array.from(this.assets.values()).filter(asset => {
      if (criteria.type && asset.type !== criteria.type) {
        return false;
      }
      if (criteria.category && asset.category !== criteria.category) {
        return false;
      }
      if (criteria.energyLevel && asset.energyLevel !== criteria.energyLevel) {
        return false;
      }
      if (criteria.commercialUseOnly && !asset.commercialUsePermitted) {
        return false;
      }
      if (criteria.loopableOnly && !asset.loopable) {
        return false;
      }
      if (criteria.minDurationSeconds !== undefined && asset.durationSeconds < criteria.minDurationSeconds) {
        return false;
      }
      if (criteria.maxDurationSeconds !== undefined && asset.durationSeconds > criteria.maxDurationSeconds) {
        return false;
      }
      if (criteria.tags && criteria.tags.length > 0) {
        const assetTags = (asset.tags || []).map(t => t.toLowerCase());
        const hasMatchingTag = criteria.tags.some(reqTag => assetTags.includes(reqTag.toLowerCase()));
        if (!hasMatchingTag) {
          return false;
        }
      }
      return true;
    }).slice(0, criteria.limit ?? 100);
  }

  public async loadFromProvider(provider: IAudioAssetProvider): Promise<number> {
    const remoteAssets = await provider.loadCatalog();
    let addedCount = 0;
    for (const asset of remoteAssets) {
      if (!this.assets.has(asset.assetId)) {
        this.assets.set(asset.assetId, asset);
        addedCount++;
      }
    }
    return addedCount;
  }
}
