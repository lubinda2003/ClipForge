/**
 * ClipForge Audio Asset Validator
 * Enforces metadata integrity, duration constraints, and commercial usage licensing.
 */

import fs from 'node:fs';
import { AudioAssetMetadata } from '../contracts/assets.ts';

export interface ValidationIssue {
  field: string;
  message: string;
  severity: 'error' | 'warning';
}

export interface AudioAssetValidationResult {
  valid: boolean;
  issues: ValidationIssue[];
}

export class AudioAssetValidator {
  public static validateMetadata(
    asset: AudioAssetMetadata,
    options?: { requireCommercialUse?: boolean }
  ): AudioAssetValidationResult {
    const issues: ValidationIssue[] = [];

    if (!asset.assetId || typeof asset.assetId !== 'string' || asset.assetId.trim() === '') {
      issues.push({ field: 'assetId', message: 'Asset ID must be a non-empty string', severity: 'error' });
    }

    if (!asset.filename || typeof asset.filename !== 'string' || asset.filename.trim() === '') {
      issues.push({ field: 'filename', message: 'Filename must be a non-empty string', severity: 'error' });
    }

    if (asset.type !== 'music' && asset.type !== 'sfx') {
      issues.push({ field: 'type', message: `Invalid asset type: ${asset.type}`, severity: 'error' });
    }

    if (!asset.category || typeof asset.category !== 'string' || asset.category.trim() === '') {
      issues.push({ field: 'category', message: 'Category must be a non-empty string', severity: 'error' });
    }

    if (!['low', 'medium', 'high'].includes(asset.energyLevel)) {
      issues.push({ field: 'energyLevel', message: `Invalid energyLevel: ${asset.energyLevel}`, severity: 'error' });
    }

    if (typeof asset.durationSeconds !== 'number' || isNaN(asset.durationSeconds) || asset.durationSeconds <= 0) {
      issues.push({ field: 'durationSeconds', message: 'durationSeconds must be a positive number', severity: 'error' });
    }

    if (!asset.license || typeof asset.license !== 'string' || asset.license.trim() === '') {
      issues.push({ field: 'license', message: 'License must be a non-empty string', severity: 'error' });
    }

    if (typeof asset.commercialUsePermitted !== 'boolean') {
      issues.push({ field: 'commercialUsePermitted', message: 'commercialUsePermitted must be a boolean', severity: 'error' });
    }

    if (options?.requireCommercialUse && !asset.commercialUsePermitted) {
      issues.push({
        field: 'commercialUsePermitted',
        message: `Asset ${asset.assetId} is not permitted for commercial use, but commercial licensing is required`,
        severity: 'error',
      });
    }

    if (asset.attributionRequired && !asset.attributionText) {
      issues.push({
        field: 'attributionText',
        message: `Asset ${asset.assetId} requires attribution, but attributionText is missing`,
        severity: 'warning',
      });
    }

    if (!asset.checksumSha256 || typeof asset.checksumSha256 !== 'string' || asset.checksumSha256.length < 16) {
      issues.push({ field: 'checksumSha256', message: 'Valid checksum SHA256 must be provided', severity: 'error' });
    }

    return {
      valid: !issues.some(i => i.severity === 'error'),
      issues,
    };
  }

  public static validateAudioFile(localFilePath: string): AudioAssetValidationResult {
    const issues: ValidationIssue[] = [];
    if (!fs.existsSync(localFilePath)) {
      issues.push({ field: 'filePath', message: `Local audio file does not exist: ${localFilePath}`, severity: 'error' });
      return { valid: false, issues };
    }

    const stats = fs.statSync(localFilePath);
    if (stats.size <= 0) {
      issues.push({ field: 'fileSize', message: `Audio file is 0 bytes: ${localFilePath}`, severity: 'error' });
    }

    return {
      valid: !issues.some(i => i.severity === 'error'),
      issues,
    };
  }
}
