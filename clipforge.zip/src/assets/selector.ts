/**
 * ClipForge Audio Asset Selector
 * Multi-factor deterministic scoring and selection for background music and SFX.
 */

import { AudioAssetMetadata, SelectedAudioAsset } from '../contracts/assets.ts';
import { AudioAssetCatalog } from './catalog.ts';
import { MusicScoringContext, SfxScoringContext, ScoredCandidate } from './types.ts';

export class AudioAssetSelector {
  private catalog: AudioAssetCatalog;

  constructor(catalog: AudioAssetCatalog) {
    this.catalog = catalog;
  }

  /**
   * Evaluates music candidates and deterministically selects the highest-scoring track.
   */
  public selectMusic(context: MusicScoringContext): SelectedAudioAsset | null {
    const musicAssets = this.catalog.query({ type: 'music' });
    if (musicAssets.length === 0) {
      return null;
    }

    const scored: ScoredCandidate[] = [];

    for (const candidate of musicAssets) {
      // Commercial check
      if (context.commercialUseRequired && !candidate.commercialUsePermitted) {
        continue;
      }

      const breakdown: Record<string, number> = {};

      // 1. Mood Compatibility (0 - 30)
      let moodScore = 15; // default baseline
      const targetMood = (context.targetMood || '').toLowerCase();
      const candidateMood = (candidate.mood || '').toLowerCase();
      const tags = (candidate.tags || []).map(t => t.toLowerCase());

      if (targetMood) {
        if (candidateMood === targetMood) {
          moodScore = 30;
        } else if (candidateMood.includes(targetMood) || targetMood.includes(candidateMood)) {
          moodScore = 25;
        } else if (tags.some(t => targetMood.includes(t) || t.includes(targetMood))) {
          moodScore = 22;
        } else {
          // Compatible pairings
          const compatiblePairs: Record<string, string[]> = {
            energetic: ['fast', 'upbeat', 'motivational', 'driving'],
            curious: ['analytical', 'contemplative', 'tech'],
            serious: ['dramatic', 'epic', 'contemplative'],
            inspiring: ['uplifting', 'epic', 'motivational'],
            tense: ['suspense', 'dark', 'heartbeat'],
          };
          const matches = compatiblePairs[targetMood] || [];
          if (matches.includes(candidateMood)) {
            moodScore = 20;
          }
        }
      }
      breakdown.moodScore = moodScore;

      // 2. Energy Level Compatibility (0 - 25)
      let energyScore = 10;
      const desiredEnergy = context.desiredEnergy || (context.format === 'short' ? 'high' : 'medium');
      if (candidate.energyLevel === desiredEnergy) {
        energyScore = 25;
      } else if (
        (desiredEnergy === 'high' && candidate.energyLevel === 'medium') ||
        (desiredEnergy === 'medium' && (candidate.energyLevel === 'high' || candidate.energyLevel === 'low'))
      ) {
        energyScore = 16;
      } else {
        energyScore = 8;
      }
      breakdown.energyScore = energyScore;

      // 3. Format & BPM Suitability (0 - 20)
      let bpmScore = 10;
      const bpm = candidate.bpm || 110;
      if (context.format === 'short') {
        // Short-form benefits from driving tempo (115 - 140 BPM)
        if (bpm >= 115 && bpm <= 140) {
          bpmScore = 20;
        } else if (bpm >= 100) {
          bpmScore = 15;
        } else {
          bpmScore = 8;
        }
      } else {
        // Long-form benefits from stable tempo (75 - 110 BPM)
        if (bpm >= 75 && bpm <= 110) {
          bpmScore = 20;
        } else if (bpm <= 125) {
          bpmScore = 14;
        } else {
          bpmScore = 8;
        }
      }
      breakdown.bpmScore = bpmScore;

      // 4. Duration & Loop Suitability (0 - 20)
      let durationScore = 10;
      if (candidate.durationSeconds >= context.totalDurationSeconds) {
        durationScore = 20;
      } else if (candidate.loopable) {
        durationScore = 18; // loopable is nearly as good as full duration
      } else {
        // Penalize non-loopable tracks that are shorter than total video duration
        const coverageRatio = candidate.durationSeconds / Math.max(context.totalDurationSeconds, 1);
        durationScore = Math.round(10 * Math.min(coverageRatio, 1));
      }
      breakdown.durationScore = durationScore;

      // 5. Category Relevance (0 - 15)
      let categoryScore = 8;
      const topic = (context.topic || '').toLowerCase();
      if (
        (topic.includes('tech') || topic.includes('ai') || topic.includes('code') || topic.includes('crispr') || topic.includes('chip')) &&
        candidate.category === 'technology'
      ) {
        categoryScore = 15;
      } else if (
        (topic.includes('history') || topic.includes('mystery') || topic.includes('investigat')) &&
        (candidate.category === 'documentary' || candidate.category === 'suspense')
      ) {
        categoryScore = 15;
      } else if (context.format === 'short' && candidate.category === 'energetic') {
        categoryScore = 14;
      }
      breakdown.categoryScore = categoryScore;

      // 6. Repetition Penalty (-30 if recently used)
      let repetitionPenalty = 0;
      if (context.recentlyUsedAssetIds?.includes(candidate.assetId)) {
        repetitionPenalty = 30;
      }
      breakdown.repetitionPenalty = -repetitionPenalty;

      const totalScore = moodScore + energyScore + bpmScore + durationScore + categoryScore - repetitionPenalty;
      scored.push({ candidate, score: totalScore, breakdown });
    }

    if (scored.length === 0) {
      return null;
    }

    // Deterministic sorting: highest score first, tie-break by stable assetId
    scored.sort((a, b) => {
      if (b.score !== a.score) {
        return b.score - a.score;
      }
      return a.candidate.assetId.localeCompare(b.candidate.assetId);
    });

    const best = scored[0];
    const loopCount = best.candidate.durationSeconds < context.totalDurationSeconds && best.candidate.loopable
      ? Math.ceil(context.totalDurationSeconds / best.candidate.durationSeconds)
      : 1;

    return {
      purpose: 'background_music',
      asset: best.candidate,
      localPath: best.candidate.filename,
      targetTimestampSeconds: 0,
      targetDurationSeconds: context.totalDurationSeconds,
      volumeLevel: context.format === 'short' ? 0.18 : 0.15,
      fadeInSeconds: 0.5,
      fadeOutSeconds: Math.min(2.0, context.totalDurationSeconds * 0.1),
      score: best.score,
      loopCount,
    };
  }

  /**
   * Deterministically selects an SFX asset for an editing landmark.
   */
  public selectSfx(context: SfxScoringContext): AudioAssetMetadata | null {
    const sfxAssets = this.catalog.query({ type: 'sfx' });
    if (sfxAssets.length === 0) {
      return null;
    }

    const scored: ScoredCandidate[] = [];

    // Preferred categories based on purpose
    const purposeCategoryMap: Record<string, string[]> = {
      hook: ['whoosh', 'impact', 'hit'],
      pattern_interrupt: ['glitch', 'whoosh', 'riser'],
      statistic_reveal: ['click', 'hit', 'transition'],
      scene_transition: ['transition', 'whoosh'],
      payoff: ['impact', 'hit', 'riser'],
      emphasis: ['hit', 'click', 'whoosh'],
    };

    const preferredCategories = purposeCategoryMap[context.purpose] || ['whoosh', 'hit'];

    for (const candidate of sfxAssets) {
      if (context.commercialUseRequired && !candidate.commercialUsePermitted) {
        continue;
      }

      const breakdown: Record<string, number> = {};

      // 1. Purpose & Category Match (0 - 50)
      let purposeScore = 15;
      const catIndex = preferredCategories.indexOf(candidate.category);
      if (catIndex === 0) {
        purposeScore = 50;
      } else if (catIndex === 1) {
        purposeScore = 40;
      } else if (catIndex > 1) {
        purposeScore = 30;
      }
      breakdown.purposeScore = purposeScore;

      // 2. Energy Level Match (0 - 30)
      let energyScore = 15;
      const desiredEnergy = context.desiredEnergy || (context.purpose === 'hook' || context.purpose === 'payoff' ? 'high' : 'medium');
      if (candidate.energyLevel === desiredEnergy) {
        energyScore = 30;
      } else {
        energyScore = 15;
      }
      breakdown.energyScore = energyScore;

      // 3. Repetition Penalty (-35 if recently used)
      let repPenalty = 0;
      if (context.recentlyUsedAssetIds?.includes(candidate.assetId)) {
        repPenalty = 35;
      }
      breakdown.repetitionPenalty = -repPenalty;

      const totalScore = purposeScore + energyScore - repPenalty;
      scored.push({ candidate, score: totalScore, breakdown });
    }

    if (scored.length === 0) {
      return null;
    }

    // Deterministic sorting: highest score first, tie-break by assetId
    scored.sort((a, b) => {
      if (b.score !== a.score) {
        return b.score - a.score;
      }
      return a.candidate.assetId.localeCompare(b.candidate.assetId);
    });

    return scored[0].candidate;
  }
}
