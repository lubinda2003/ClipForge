/**
 * ClipForge Audio Asset Types & Provider Interfaces
 */

import { AudioAssetMetadata, MusicCategory, SfxCategory, SelectedAudioAsset, AssetsArtifact } from '../contracts/assets.ts';

export interface IAudioAssetProvider {
  readonly name: string;
  loadCatalog(): Promise<AudioAssetMetadata[]>;
  getAssetFile(asset: AudioAssetMetadata, destinationDir: string): Promise<string>;
  isAvailable(): Promise<boolean>;
}

export interface AudioSearchCriteria {
  type?: 'music' | 'sfx';
  category?: MusicCategory | SfxCategory | string;
  mood?: string;
  energyLevel?: 'low' | 'medium' | 'high';
  minDurationSeconds?: number;
  maxDurationSeconds?: number;
  commercialUseOnly?: boolean;
  loopableOnly?: boolean;
  tags?: string[];
  limit?: number;
}

export interface MusicScoringContext {
  format: 'short' | 'long';
  topic?: string;
  targetMood?: string;
  desiredEnergy?: 'low' | 'medium' | 'high';
  totalDurationSeconds: number;
  commercialUseRequired?: boolean;
  recentlyUsedAssetIds?: string[];
}

export interface SfxScoringContext {
  purpose: 'hook' | 'pattern_interrupt' | 'statistic_reveal' | 'scene_transition' | 'payoff' | 'emphasis';
  sceneVisualConcept?: string;
  desiredEnergy?: 'low' | 'medium' | 'high';
  commercialUseRequired?: boolean;
  recentlyUsedAssetIds?: string[];
}

export interface ScoredCandidate<T = AudioAssetMetadata> {
  candidate: T;
  score: number;
  breakdown: Record<string, number>;
}
