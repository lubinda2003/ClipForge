/**
 * ClipForge Scene Plan Validator
 * Verifies scenes schema, timing integrity, duration calculations, and no fixed 30s clamping.
 */

import { ScenesArtifact, SceneVisualRequirement } from '../contracts/scenes.ts';

export interface SceneValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export function validateScenesArtifact(
  artifact: ScenesArtifact,
  options: { expectedTotalDuration?: number } = {}
): SceneValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!artifact) {
    return { isValid: false, errors: ['ScenesArtifact is undefined or null'], warnings: [] };
  }

  if (artifact.format !== 'short' && artifact.format !== 'long') {
    errors.push(`Invalid video format: ${artifact.format}. Must be "short" or "long".`);
  }

  if (!Array.isArray(artifact.scenes) || artifact.scenes.length === 0) {
    errors.push('ScenesArtifact must contain at least one scene in the scenes array.');
    return { isValid: false, errors, warnings };
  }

  const expectedAspect = artifact.format === 'short' ? '9:16' : '16:9';
  const seenSceneIds = new Set<string>();
  let calculatedDuration = 0;

  artifact.scenes.forEach((scene: SceneVisualRequirement, index: number) => {
    if (!scene.sceneId || typeof scene.sceneId !== 'string' || scene.sceneId.trim().length === 0) {
      errors.push(`Scene at index ${index} is missing a valid sceneId.`);
    } else {
      if (seenSceneIds.has(scene.sceneId)) {
        errors.push(`Duplicate sceneId "${scene.sceneId}" at index ${index}.`);
      }
      seenSceneIds.add(scene.sceneId);
    }

    if (!scene.correspondingSegmentId || typeof scene.correspondingSegmentId !== 'string') {
      errors.push(`Scene ${scene.sceneId || index} is missing correspondingSegmentId.`);
    }

    if (scene.sequenceOrder !== index) {
      errors.push(
        `Scene ${scene.sceneId || index} sequenceOrder ${scene.sequenceOrder} does not match index ${index}.`
      );
    }

    if (!scene.visualConcept || scene.visualConcept.trim().length === 0) {
      errors.push(`Scene ${scene.sceneId || index} is missing a visualConcept description.`);
    }

    if (!Array.isArray(scene.searchKeywords) || scene.searchKeywords.length === 0) {
      errors.push(`Scene ${scene.sceneId || index} must contain at least one search keyword/query.`);
    } else {
      for (const kw of scene.searchKeywords) {
        if (!kw || typeof kw !== 'string' || kw.trim().length === 0) {
          errors.push(`Scene ${scene.sceneId || index} contains an empty search query.`);
        }
      }
    }

    if (typeof scene.desiredDurationSeconds !== 'number' || scene.desiredDurationSeconds <= 0) {
      errors.push(
        `Scene ${scene.sceneId || index} has invalid desiredDurationSeconds: ${scene.desiredDurationSeconds}. Must be > 0.`
      );
    } else {
      calculatedDuration += scene.desiredDurationSeconds;
    }

    if (scene.targetAspectRatio !== expectedAspect) {
      errors.push(
        `Scene ${scene.sceneId || index} targetAspectRatio "${scene.targetAspectRatio}" does not match format "${artifact.format}" (expected ${expectedAspect}).`
      );
    }

    // Check optional time range consistency if specified
    if (scene.startTimeSeconds !== undefined && scene.endTimeSeconds !== undefined) {
      if (scene.endTimeSeconds < scene.startTimeSeconds) {
        errors.push(
          `Scene ${scene.sceneId || index} endTimeSeconds (${scene.endTimeSeconds}) is less than startTimeSeconds (${scene.startTimeSeconds}).`
        );
      }
      const rangeDuration = scene.endTimeSeconds - scene.startTimeSeconds;
      if (Math.abs(rangeDuration - scene.desiredDurationSeconds) > 0.05) {
        warnings.push(
          `Scene ${scene.sceneId || index} time range duration (${rangeDuration.toFixed(2)}s) differs from desiredDurationSeconds (${scene.desiredDurationSeconds.toFixed(2)}s).`
        );
      }
    }
  });

  // Verify total scenes count matches
  if (artifact.totalScenes !== artifact.scenes.length) {
    errors.push(
      `totalScenes (${artifact.totalScenes}) does not match scenes array length (${artifact.scenes.length}).`
    );
  }

  // Verify totalDurationSeconds matches sum
  if (Math.abs(artifact.totalDurationSeconds - calculatedDuration) > 0.1) {
    warnings.push(
      `totalDurationSeconds (${artifact.totalDurationSeconds}) does not match calculated sum of scenes (${calculatedDuration.toFixed(3)}s).`
    );
  }

  // Anti-slop / anti-30s-clamping check
  if (
    artifact.totalDurationSeconds === 30.0 &&
    options.expectedTotalDuration !== undefined &&
    Math.abs(options.expectedTotalDuration - 30.0) > 0.5
  ) {
    warnings.push(
      `Suspicious duration locking: Scenes total duration is exactly 30.0s while expected audio duration was ${options.expectedTotalDuration}s.`
    );
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
  };
}
