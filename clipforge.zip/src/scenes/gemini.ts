/**
 * ClipForge Gemini Scene Planning Provider
 * Generates scene requirements, visual concepts, and targeted stock search queries
 * grounded in script narration and measured audio timing.
 */

import { GoogleGenAI } from '@google/genai';
import { VideoFormat, AspectRatio } from '../contracts/common.ts';
import { ScriptArtifact, ScriptSegment } from '../contracts/script.ts';
import { NarrationArtifact } from '../contracts/narration.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';
import { ResearchArtifact } from '../contracts/research.ts';
import {
  ScenesArtifact,
  SceneVisualRequirement,
  SceneType,
  VisualPurpose,
  PreferredVisualType,
  VisualMood,
} from '../contracts/scenes.ts';
import { IScenePlanningProvider, ScenePlanningOptions } from './interfaces.ts';
import { CacheManager } from '../storage/cache.ts';

export interface GeminiSceneProviderConfig {
  apiKey?: string;
  model?: string;
  cache?: CacheManager;
}

export class GeminiScenePlanningProvider implements IScenePlanningProvider {
  readonly providerName = 'gemini_scene_planner';
  private readonly apiKey: string;
  private readonly modelName: string;
  private readonly cache?: CacheManager;

  constructor(config: GeminiSceneProviderConfig = {}) {
    this.apiKey = config.apiKey !== undefined ? config.apiKey : (process.env.GEMINI_API_KEY || '');
    this.modelName = config.model || 'gemini-3.8-flash';
    this.cache = config.cache;
  }

  async planScenes(
    script: ScriptArtifact,
    narration?: NarrationArtifact,
    strategy?: ContentStrategyArtifact,
    research?: ResearchArtifact,
    options: ScenePlanningOptions = {}
  ): Promise<ScenesArtifact> {
    const format: VideoFormat = options.format || script.format || 'short';
    const targetAspectRatio: AspectRatio = format === 'short' ? '9:16' : '16:9';
    const maxSceneDuration =
      options.maxSceneDurationSeconds ?? (format === 'short' ? 4.5 : 7.0);

    // Map narration actual measured durations per segmentId
    const segmentDurations = new Map<string, number>();
    if (narration && Array.isArray(narration.segmentResults)) {
      for (const seg of narration.segmentResults) {
        segmentDurations.set(seg.segmentId, seg.actualDurationSeconds);
      }
    }

    // Check cache if available
    const cacheKey = this.cache?.generateKey('scene_planner', {
      topic: script.topic,
      format,
      segmentCount: script.segments.length,
      narrationDuration: narration?.totalDurationSeconds,
    });

    if (this.cache && cacheKey) {
      const cached = await this.cache.get<ScenesArtifact>(cacheKey);
      if (cached) {
        return cached;
      }
    }

    let scenes: SceneVisualRequirement[];

    if (this.apiKey) {
      try {
        scenes = await this.planWithGemini(
          script,
          segmentDurations,
          strategy,
          research,
          format,
          targetAspectRatio,
          maxSceneDuration
        );
      } catch (err) {
        console.warn('[GeminiScenePlanningProvider] Gemini planning failed, using deterministic local planner:', err);
        scenes = this.planLocally(
          script,
          segmentDurations,
          strategy,
          research,
          format,
          targetAspectRatio,
          maxSceneDuration
        );
      }
    } else {
      scenes = this.planLocally(
        script,
        segmentDurations,
        strategy,
        research,
        format,
        targetAspectRatio,
        maxSceneDuration
      );
    }

    // Assign cumulative sequence timing
    let currentTime = 0;
    for (let i = 0; i < scenes.length; i++) {
      const s = scenes[i];
      s.sequenceOrder = i;
      s.startTimeSeconds = Number(currentTime.toFixed(3));
      currentTime += s.desiredDurationSeconds;
      s.endTimeSeconds = Number(currentTime.toFixed(3));
    }

    const totalDurationSeconds = Number(currentTime.toFixed(3));

    const artifact: ScenesArtifact = {
      jobId: options.jobId || script.jobId,
      createdAt: new Date().toISOString(),
      topic: script.topic,
      format,
      totalScenes: scenes.length,
      totalDurationSeconds,
      scenes,
      metadata: {
        plannedAt: new Date().toISOString(),
        narrationReference: narration?.jobId ? `jobs/${narration.jobId}/narration.json` : undefined,
        scriptReference: script.jobId ? `jobs/${script.jobId}/script.json` : undefined,
        pacingProfile: format === 'short' ? 'fast_paced_hook_driven' : 'structured_multi_act',
        provider: this.apiKey ? 'gemini' : 'deterministic_local',
      },
    };

    if (this.cache && cacheKey) {
      await this.cache.set('scene_planner', cacheKey, artifact, 86400 * 3);
    }

    return artifact;
  }

  /**
   * Deterministic local scene planner
   * Breaks narration into scenes and shots, deriving targeted queries from visual concept
   */
  private planLocally(
    script: ScriptArtifact,
    segmentDurations: Map<string, number>,
    strategy: ContentStrategyArtifact | undefined,
    _research: ResearchArtifact | undefined,
    format: VideoFormat,
    targetAspectRatio: AspectRatio,
    maxSceneDuration: number
  ): SceneVisualRequirement[] {
    const scenes: SceneVisualRequirement[] = [];
    let sceneIndex = 0;

    const continuityGroupName = `${script.topic.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_theme`;

    for (const segment of script.segments) {
      const segDuration =
        segmentDurations.get(segment.segmentId) ||
        segment.estimatedDurationSeconds ||
        3.5;

      // Determine if multi-shot is required based on duration and pacing
      const needsMultiShot = segDuration > maxSceneDuration && segDuration >= 4.0;
      const numShots = needsMultiShot ? Math.min(3, Math.ceil(segDuration / maxSceneDuration)) : 1;
      const shotDuration = Number((segDuration / numShots).toFixed(3));

      for (let shot = 0; shot < numShots; shot++) {
        const sceneId = `scene_${String(sceneIndex + 1).padStart(3, '0')}`;
        sceneIndex++;

        const isOpeningHook = segment.sectionIndex === 0 && shot === 0;
        const isClosingPayoff = segment.sectionIndex === script.segments.length - 1 && shot === numShots - 1;

        // Visual concept derived from segment intent
        let visualConcept = segment.visualIntentDescription;
        if (numShots > 1) {
          if (shot === 0) {
            visualConcept = `Establishing: ${segment.visualIntentDescription}`;
          } else {
            visualConcept = `Detail/Progression: ${segment.visualIntentDescription} focus on action`;
          }
        }

        // Targeted search keywords generation
        const searchKeywords = this.generateKeywords(
          segment,
          script.topic,
          shot,
          numShots,
          strategy
        );

        // Classify scene type & purpose
        const sceneType: SceneType = this.classifySceneType(segment, isOpeningHook, shot);
        const visualPurpose: VisualPurpose = this.classifyVisualPurpose(segment, isOpeningHook, isClosingPayoff);
        const visualMood: VisualMood = this.determineVisualMood(segment, strategy);
        const preferredVisualType: PreferredVisualType = 'realistic_video';

        const req: SceneVisualRequirement = {
          sceneId,
          correspondingSegmentId: segment.segmentId,
          sequenceOrder: sceneIndex - 1,
          narrationExcerpt: segment.narrationText.substring(0, 120),
          visualConcept,
          searchKeywords,
          preferredVisualType,
          desiredDurationSeconds: shotDuration,
          targetAspectRatio,
          format,
          visualMood,
          visualContinuityGroup: continuityGroupName,
          allowCropping: true,
          cameraMovementHint: isOpeningHook ? 'dynamic' : shot % 2 === 0 ? 'slow_zoom' : 'slow_pan',
          sceneType,
          visualPurpose,
          visualImportance: isOpeningHook ? 'critical' : 'high',
          pacingIntent: format === 'short' ? (isOpeningHook ? 'impact' : 'fast') : 'moderate',
          preferredOrientation: format === 'short' ? 'portrait' : 'landscape',
          requiredEntities: segment.emphasisKeywords.slice(0, 3),
          requiredSubjects: [script.topic],
          stockFootageAppropriate: true,
        };

        scenes.push(req);
      }
    }

    return scenes;
  }

  /**
   * Generates targeted, deduplicated queries for stock search (not just raw topic)
   */
  private generateKeywords(
    segment: ScriptSegment,
    topic: string,
    shot: number,
    totalShots: number,
    strategy?: ContentStrategyArtifact
  ): string[] {
    const rawQueries: string[] = [];

    // Clean topic keywords
    const topicWords = topic.replace(/[^a-zA-Z0-9 ]/g, '').trim();

    // 1. From emphasis keywords + topic
    if (segment.emphasisKeywords && segment.emphasisKeywords.length > 0) {
      const topKeyword = segment.emphasisKeywords[0].replace(/[^a-zA-Z0-9 ]/g, '').trim();
      if (topKeyword.length > 2) {
        rawQueries.push(`${topKeyword} ${topicWords}`.trim());
        rawQueries.push(topKeyword);
      }
      if (segment.emphasisKeywords.length > 1) {
        const secKeyword = segment.emphasisKeywords[1].replace(/[^a-zA-Z0-9 ]/g, '').trim();
        rawQueries.push(`${secKeyword} technology`.trim());
      }
    }

    // 2. From visual intent description
    const intentSnippet = segment.visualIntentDescription
      .replace(/[^a-zA-Z0-9 ]/g, '')
      .split(' ')
      .filter(w => w.length > 3 && !['showing', 'footage', 'video', 'dramatic', 'archival'].includes(w.toLowerCase()))
      .slice(0, 3)
      .join(' ');
    if (intentSnippet.length > 3) {
      rawQueries.push(intentSnippet);
    }

    // 3. For multi-shot progression
    if (totalShots > 1) {
      if (shot === 0) {
        rawQueries.push(`${topicWords} lab research`);
      } else {
        rawQueries.push(`${topicWords} microscopic close up`);
      }
    }

    // 4. Fallback contextual query
    rawQueries.push(`${topicWords} science`);

    // Clean, normalize and deduplicate
    const deduped: string[] = [];
    const seen = new Set<string>();

    for (const q of rawQueries) {
      const clean = q.replace(/\s+/g, ' ').trim().toLowerCase();
      if (clean.length >= 3 && !seen.has(clean)) {
        seen.add(clean);
        deduped.push(clean);
      }
      if (deduped.length >= 4) break;
    }

    return deduped.length > 0 ? deduped : [topic.toLowerCase()];
  }

  private classifySceneType(segment: ScriptSegment, isHook: boolean, shot: number): SceneType {
    if (isHook) return 'establishing_shot';
    const text = segment.narrationText.toLowerCase();
    if (text.includes('data') || text.includes('percent') || text.includes('number') || text.includes('chart')) {
      return 'data_visual';
    }
    if (text.includes('machine') || text.includes('computer') || text.includes('laser') || text.includes('device')) {
      return 'technology';
    }
    if (text.includes('engineer') || text.includes('scientist') || text.includes('researcher') || text.includes('people')) {
      return 'person_action';
    }
    if (shot > 0) return 'detail_shot';
    return 'environment';
  }

  private classifyVisualPurpose(segment: ScriptSegment, isHook: boolean, isPayoff: boolean): VisualPurpose {
    if (isHook) return 'support_hook';
    if (isPayoff) return 'reinforce_payoff';
    const text = segment.narrationText.toLowerCase();
    if (text.includes('because') || text.includes('proves') || text.includes('study') || text.includes('evidence')) {
      return 'illustrate_claim';
    }
    if (segment.sectionName.toLowerCase().includes('problem') || segment.sectionName.toLowerCase().includes('interrupt')) {
      return 'provide_pattern_interrupt';
    }
    return 'establish_context';
  }

  private determineVisualMood(segment: ScriptSegment, strategy?: ContentStrategyArtifact): VisualMood {
    if (strategy?.emotionalTriggers?.includes('curiosity')) return 'contemplative';
    if (segment.sectionName.toLowerCase().includes('hook')) return 'energetic';
    if (segment.sectionName.toLowerCase().includes('payoff')) return 'inspiring';
    return 'neutral';
  }

  /**
   * Gemini LLM based scene planner
   */
  private async planWithGemini(
    script: ScriptArtifact,
    segmentDurations: Map<string, number>,
    strategy: ContentStrategyArtifact | undefined,
    research: ResearchArtifact | undefined,
    format: VideoFormat,
    targetAspectRatio: AspectRatio,
    maxSceneDuration: number
  ): Promise<SceneVisualRequirement[]> {
    const ai = new GoogleGenAI({ apiKey: this.apiKey });

    const prompt = `You are the lead visual director and B-roll coordinator for a high-retention video production.
Translate the following spoken script into concrete, visual scene requirements.

TOPIC: "${script.topic}"
FORMAT: ${format} (${targetAspectRatio})
MAX SCENE DURATION: ${maxSceneDuration}s

SCRIPT SEGMENTS:
${JSON.stringify(
  script.segments.map(s => ({
    segmentId: s.segmentId,
    sectionName: s.sectionName,
    narrationText: s.narrationText,
    measuredDurationSeconds: segmentDurations.get(s.segmentId) || s.estimatedDurationSeconds,
    visualIntent: s.visualIntentDescription,
    emphasisKeywords: s.emphasisKeywords,
  })),
  null,
  2
)}

RESEARCH VERIFIABLE FACTS:
${JSON.stringify(research?.observedData.verifiableFacts?.slice(0, 3) || [], null, 2)}

STRATEGY CONTEXT:
Hook: ${strategy?.hook.hookText || 'N/A'}
Angle: ${strategy?.angle.coreThesis || 'N/A'}

REQUIREMENTS:
1. Every script segment MUST be visually represented.
2. If a segment's duration exceeds ${maxSceneDuration}s, break it into 2 logical visual shots (e.g. establishing shot -> detail shot) so visual pacing stays dynamic.
3. For each scene, output:
   - sceneId: "scene_001", "scene_002", etc.
   - correspondingSegmentId: matching segmentId
   - narrationExcerpt: concise excerpt of spoken line
   - visualConcept: concrete description of what appears on screen
   - searchKeywords: 2-4 targeted stock video search queries (DO NOT just search the overall topic, search the visual concept)
   - desiredDurationSeconds: duration matching segment (or fraction if multi-shot)
   - sceneType: one of ["talking_head","person_action","environment","technology","product","location","event","abstract_concept","data_visual","process","reaction","establishing_shot","detail_shot","transition_visual"]
   - visualPurpose: one of ["establish_context","illustrate_claim","demonstrate_process","introduce_entity","emphasize_statistic","create_emotional_shift","provide_pattern_interrupt","maintain_visual_continuity","support_hook","reinforce_payoff"]
   - visualMood: one of ["energetic","serious","contemplative","tense","inspiring","neutral"]
   - cameraMovementHint: one of ["static","slow_pan","slow_zoom","dynamic"]
4. Total sum of desiredDurationSeconds for shots of each segment MUST equal that segment's measured duration.
5. Return PURE JSON ARRAY ONLY conforming to the scene schema.`;

    const response = await ai.models.generateContent({
      model: this.modelName,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text?.trim() || '';
    const parsed = JSON.parse(text);

    if (!Array.isArray(parsed) || parsed.length === 0) {
      throw new Error('Gemini did not return an array of scenes.');
    }

    const scenes: SceneVisualRequirement[] = parsed.map((item: Record<string, unknown>, idx: number) => ({
      sceneId: String(item.sceneId || `scene_${String(idx + 1).padStart(3, '0')}`),
      correspondingSegmentId: String(item.correspondingSegmentId || script.segments[0].segmentId),
      sequenceOrder: idx,
      narrationExcerpt: String(item.narrationExcerpt || ''),
      visualConcept: String(item.visualConcept || ''),
      searchKeywords: Array.isArray(item.searchKeywords)
        ? item.searchKeywords.map(k => String(k))
        : [script.topic],
      preferredVisualType: 'realistic_video',
      desiredDurationSeconds: Number(item.desiredDurationSeconds) || 3.5,
      targetAspectRatio,
      format,
      visualMood: (item.visualMood as VisualMood) || 'neutral',
      visualContinuityGroup: `${script.topic.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_theme`,
      allowCropping: true,
      cameraMovementHint: (item.cameraMovementHint as 'static' | 'slow_pan' | 'slow_zoom' | 'dynamic') || 'slow_zoom',
      sceneType: (item.sceneType as SceneType) || 'environment',
      visualPurpose: (item.visualPurpose as VisualPurpose) || 'establish_context',
      pacingIntent: format === 'short' ? 'fast' : 'moderate',
      preferredOrientation: format === 'short' ? 'portrait' : 'landscape',
      stockFootageAppropriate: true,
    }));

    return scenes;
  }
}
