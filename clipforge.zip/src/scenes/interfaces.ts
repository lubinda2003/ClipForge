/**
 * ClipForge Scene Planning Interfaces
 */

import { VideoFormat } from '../contracts/common.ts';
import { ScriptArtifact } from '../contracts/script.ts';
import { NarrationArtifact } from '../contracts/narration.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';
import { ResearchArtifact } from '../contracts/research.ts';
import {
  ScenesArtifact,
  SceneVisualRequirement,
  SceneType,
  VisualPurpose,
  PreferredVisualType,
  VisualMood,
} from '../contracts/scenes.ts';

export type {
  ScenesArtifact,
  SceneVisualRequirement,
  SceneType,
  VisualPurpose,
  PreferredVisualType,
  VisualMood,
};

export interface ScenePlanningOptions {
  jobId?: string;
  format?: VideoFormat;
  targetPacing?: 'fast' | 'moderate' | 'slow';
  maxSceneDurationSeconds?: number;
  minSceneDurationSeconds?: number;
  allowMultiShot?: boolean;
}

export interface IScenePlanningProvider {
  readonly providerName: string;
  planScenes(
    script: ScriptArtifact,
    narration?: NarrationArtifact,
    strategy?: ContentStrategyArtifact,
    research?: ResearchArtifact,
    options?: ScenePlanningOptions
  ): Promise<ScenesArtifact>;
}

export interface IScenePlanner {
  executeScenePlanning(
    script: ScriptArtifact,
    narration?: NarrationArtifact,
    strategy?: ContentStrategyArtifact,
    research?: ResearchArtifact,
    options?: ScenePlanningOptions
  ): Promise<ScenesArtifact>;
}
