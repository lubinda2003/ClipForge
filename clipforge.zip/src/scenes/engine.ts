/**
 * ClipForge Scene Planning Engine
 * Orchestrates translation of script & narration into concrete visual scene requirements,
 * validates compliance with domain contracts, and persists scenes.json.
 */

import { ScriptArtifact } from '../contracts/script.ts';
import { NarrationArtifact } from '../contracts/narration.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';
import { ResearchArtifact } from '../contracts/research.ts';
import { ScenesArtifact } from '../contracts/scenes.ts';
import { IScenePlanner, IScenePlanningProvider, ScenePlanningOptions } from './interfaces.ts';
import { GeminiScenePlanningProvider } from './gemini.ts';
import { validateScenesArtifact } from './validator.ts';
import { ScenePlanningError } from './errors.ts';
import { IStorageProvider } from '../storage/interface.ts';
import { LocalStorageProvider } from '../storage/local.ts';
import { CacheManager } from '../storage/cache.ts';

export interface ScenePlannerDependencies {
  storage?: IStorageProvider;
  cache?: CacheManager;
  provider?: IScenePlanningProvider;
}

export class ScenePlanner implements IScenePlanner {
  private readonly storage: IStorageProvider;
  private readonly cache: CacheManager;
  private readonly provider: IScenePlanningProvider;

  constructor(deps: ScenePlannerDependencies = {}) {
    this.storage = deps.storage || new LocalStorageProvider();
    this.cache = deps.cache || new CacheManager(this.storage);
    this.provider = deps.provider || new GeminiScenePlanningProvider({ cache: this.cache });
  }

  async executeScenePlanning(
    script: ScriptArtifact,
    narration?: NarrationArtifact,
    strategy?: ContentStrategyArtifact,
    research?: ResearchArtifact,
    options: ScenePlanningOptions = {}
  ): Promise<ScenesArtifact> {
    if (!script || !Array.isArray(script.segments) || script.segments.length === 0) {
      throw new ScenePlanningError(
        'INVALID_SCRIPT_ARTIFACT',
        'Valid ScriptArtifact with at least one segment is required for scene planning.'
      );
    }

    if (narration && (!Array.isArray(narration.segmentResults) || narration.segmentResults.length === 0)) {
      throw new ScenePlanningError(
        'INVALID_NARRATION_ARTIFACT',
        'NarrationArtifact provided is missing segmentResults.'
      );
    }

    const jobId = options.jobId || script.jobId || narration?.jobId || `job_${Date.now()}`;
    const format = options.format || script.format || 'short';

    // 1. Plan scenes via provider
    let artifact: ScenesArtifact;
    try {
      artifact = await this.provider.planScenes(script, narration, strategy, research, {
        ...options,
        jobId,
        format,
      });
    } catch (err) {
      throw new ScenePlanningError(
        'SCENE_PLANNING_FAILED',
        `Failed to generate scene plan: ${(err as Error).message}`,
        { originalError: String(err) }
      );
    }

    // Ensure alignment of core attributes
    artifact.jobId = jobId;
    artifact.format = format;
    if (script.topic) {
      artifact.topic = script.topic;
    }

    // 2. Validate scenes artifact
    const validation = validateScenesArtifact(artifact, {
      expectedTotalDuration: narration?.totalDurationSeconds,
    });
    if (!validation.isValid) {
      throw new ScenePlanningError(
        'SCENE_ARTIFACT_INVALID',
        `Scene plan validation failed:\n${validation.errors.join('\n')}`,
        { errors: validation.errors, warnings: validation.warnings }
      );
    }

    // 3. Persist scenes.json
    const artifactKey = `jobs/${jobId}/scenes.json`;
    if (this.storage instanceof LocalStorageProvider) {
      await this.storage.writeJson('inputs', artifactKey, artifact);
    }

    return artifact;
  }
}
