/**
 * ClipForge Scene Planning Typed Errors
 */

export type SceneErrorCode =
  | 'SCENE_PLANNING_FAILED'
  | 'INVALID_SCRIPT_ARTIFACT'
  | 'INVALID_NARRATION_ARTIFACT'
  | 'SCENE_ARTIFACT_INVALID';

export class ScenePlanningError extends Error {
  readonly code: SceneErrorCode;
  readonly details?: Record<string, unknown>;

  constructor(code: SceneErrorCode, message: string, details?: Record<string, unknown>) {
    super(`[${code}] ${message}`);
    this.name = 'ScenePlanningError';
    this.code = code;
    this.details = details;
  }
}
