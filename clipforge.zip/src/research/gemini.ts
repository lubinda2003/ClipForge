/**
 * ClipForge Gemini Research Synthesis Provider
 * Uses Gemini API to synthesize collected public observations into verifiable facts and inferred strategic insights.
 * Strictly enforces OBSERVED vs INFERRED separation and tags claims requiring verification.
 */

import { GoogleGenAI } from '@google/genai';
import {
  IGeminiResearchProvider,
  GeminiResearchSynthesisInput,
  GeminiResearchSynthesisResult,
} from './interfaces.ts';
import { CacheManager } from '../storage/cache.ts';

export interface GeminiResearchProviderConfig {
  apiKey?: string;
  model?: string;
  cache?: CacheManager;
}

export class GeminiResearchProvider implements IGeminiResearchProvider {
  readonly providerName = 'gemini_research_synthesis';
  private readonly apiKey: string;
  private readonly modelName: string;
  private readonly cache?: CacheManager;

  constructor(config: GeminiResearchProviderConfig = {}) {
    this.apiKey = (config.apiKey !== undefined ? config.apiKey : process.env.GEMINI_API_KEY || '').trim();
    this.modelName = config.model || process.env.GEMINI_MODEL || 'gemini-3.6-flash';
    this.cache = config.cache;
  }

  isAvailable(): boolean {
    return Boolean(this.apiKey && this.apiKey.length > 5);
  }

  private redactKey(msg: string): string {
    if (!this.apiKey) return msg;
    return msg.split(this.apiKey).join('[REDACTED]');
  }

  async synthesizeResearch(
    input: GeminiResearchSynthesisInput
  ): Promise<GeminiResearchSynthesisResult> {
    const cacheKey = this.cache?.generateKey('gemini_research', {
      topic: input.topic.toLowerCase().trim(),
      format: input.format,
      videoCount: input.observedYouTubeVideos.length,
      queries: input.queriesGenerated,
    });

    if (this.cache && cacheKey) {
      const cached = await this.cache.get<GeminiResearchSynthesisResult>(cacheKey);
      if (cached) {
        return cached;
      }
    }

    if (!this.isAvailable()) {
      // Graceful fallback when Gemini key is not configured (e.g. testing / offline)
      return this.buildHeuristicFallback(input);
    }

    try {
      const ai = new GoogleGenAI({ apiKey: this.apiKey });

      const prompt = `You are the Lead Research Analyst for ClipForge, an automated video production pipeline.
Synthesize the provided topic and public research signals into structured, factual research data and strategic inferences.

CRITICAL RULES:
1. STRICTLY SEPARATE OBSERVED FACTS from INFERRED STRATEGY.
2. For "verifiableFacts": only include verifiable claims. Each must cite a specific credible source or be tagged with confidence: "unverified".
3. If a claim lacks sufficient empirical evidence, add it to "claimsRequiringVerification" with verificationRequired: true.
4. "inferredInsights" MUST be treated as analytical hypotheses, NOT empirical facts.
5. Provide actionable hooks and curiosity gaps suited for ${input.format === 'short' ? 'Short-Form (9:16 vertical fast-paced)' : 'Long-Form (16:9 structured chaptered)'} content.

TOPIC: ${input.topic}
TARGET FORMAT: ${input.format}
SEARCH QUERIES GENERATED: ${JSON.stringify(input.queriesGenerated)}
OBSERVED YOUTUBE TITLES & METRICS:
${input.observedYouTubeVideos.map(v => `- Title: "${v.title}" | Views: ${v.viewCount ?? 'N/A'} | Channel: ${v.channelTitle} | Published: ${v.publishedAt}`).join('\n') || 'None available.'}
TREND SIGNAL: ${input.trendAssessment ? `${input.trendAssessment.trendStatus} (${input.trendAssessment.analysis})` : 'Not assessed'}

Respond ONLY with a valid JSON object adhering to this schema:
{
  "topicSummary": "Concise 2-3 sentence overview of the topic and core themes",
  "verifiableFacts": [
    { "claim": "string", "source": "string", "confidence": "high" | "medium" | "unverified" }
  ],
  "commonQuestions": ["string"],
  "competitorTitles": ["string"],
  "inferredInsights": {
    "audienceInterestLevel": "niche" | "broad" | "viral_potential",
    "audienceDemographicsInference": "string",
    "saturationLevel": "underserved" | "moderate" | "oversaturated",
    "promisingContentAngles": ["string"],
    "contentGapsIdentified": ["string"],
    "potentialHooks": ["string"],
    "curiosityGaps": ["string"],
    "narrativeAngles": ["string"],
    "factualRisks": ["string"]
  },
  "claimsRequiringVerification": [
    { "claim": "string", "reason": "string", "verificationRequired": true }
  ]
}`;

      const response = await ai.models.generateContent({
        model: this.modelName,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.3,
        },
      });

      const responseText = response.text || '{}';
      const parsed = JSON.parse(responseText) as GeminiResearchSynthesisResult;

      // Validate core required fields
      const sanitizedResult: GeminiResearchSynthesisResult = {
        topicSummary: parsed.topicSummary || `Research overview on ${input.topic}`,
        verifiableFacts: Array.isArray(parsed.verifiableFacts) ? parsed.verifiableFacts : [],
        commonQuestions: Array.isArray(parsed.commonQuestions) ? parsed.commonQuestions : [],
        competitorTitles: Array.isArray(parsed.competitorTitles) ? parsed.competitorTitles : [],
        inferredInsights: {
          audienceInterestLevel: parsed.inferredInsights?.audienceInterestLevel || 'broad',
          audienceDemographicsInference: parsed.inferredInsights?.audienceDemographicsInference || 'General technology and curiosity audience',
          saturationLevel: parsed.inferredInsights?.saturationLevel || 'moderate',
          promisingContentAngles: Array.isArray(parsed.inferredInsights?.promisingContentAngles) ? parsed.inferredInsights.promisingContentAngles : [],
          contentGapsIdentified: Array.isArray(parsed.inferredInsights?.contentGapsIdentified) ? parsed.inferredInsights.contentGapsIdentified : [],
          potentialHooks: Array.isArray(parsed.inferredInsights?.potentialHooks) ? parsed.inferredInsights.potentialHooks : [],
          curiosityGaps: Array.isArray(parsed.inferredInsights?.curiosityGaps) ? parsed.inferredInsights.curiosityGaps : [],
          narrativeAngles: Array.isArray(parsed.inferredInsights?.narrativeAngles) ? parsed.inferredInsights.narrativeAngles : [],
          factualRisks: Array.isArray(parsed.inferredInsights?.factualRisks) ? parsed.inferredInsights.factualRisks : [],
        },
        claimsRequiringVerification: Array.isArray(parsed.claimsRequiringVerification) ? parsed.claimsRequiringVerification : [],
      };

      if (this.cache && cacheKey) {
        await this.cache.set('gemini_research', cacheKey, sanitizedResult);
      }

      return sanitizedResult;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      throw new Error(this.redactKey(`Gemini research synthesis failed: ${msg}`));
    }
  }

  private buildHeuristicFallback(input: GeminiResearchSynthesisInput): GeminiResearchSynthesisResult {
    const competitorTitles = input.observedYouTubeVideos.map(v => v.title).slice(0, 5);
    return {
      topicSummary: `Research baseline on "${input.topic}" formulated via public signal observations.`,
      verifiableFacts: [
        {
          claim: `Topic "${input.topic}" is discussed across public video platforms.`,
          source: 'Observed Public Metadata',
          confidence: 'high',
        },
      ],
      commonQuestions: [
        `What are the most critical aspects of ${input.topic}?`,
        `How does ${input.topic} impact viewers today?`,
      ],
      competitorTitles: competitorTitles.length > 0 ? competitorTitles : [`Understanding ${input.topic}`],
      inferredInsights: {
        audienceInterestLevel: 'broad',
        audienceDemographicsInference: 'Inferred general interest audience based on public keyword volume',
        saturationLevel: competitorTitles.length > 3 ? 'moderate' : 'underserved',
        promisingContentAngles: [
          `The counter-intuitive reality of ${input.topic}`,
          `Practical breakdown: what actually matters in ${input.topic}`,
        ],
        contentGapsIdentified: [
          `Lack of concise, actionable explanations for ${input.topic}`,
        ],
        potentialHooks: [
          `Most people misunderstand ${input.topic}—here is what actually happens.`,
          `If you thought ${input.topic} was simple, this changes everything.`,
        ],
        curiosityGaps: [
          `Why conventional wisdom about ${input.topic} is flawed`,
        ],
        narrativeAngles: [
          `Problem ➔ Surprising Evidence ➔ Actionable Takeaway`,
        ],
        factualRisks: [
          `Evolving terminology and unverified claims in secondary sources`,
        ],
      },
      claimsRequiringVerification: [
        {
          claim: `Statistical velocity of ${input.topic}`,
          reason: 'Secondary source attribution required before citing in voiceover',
          verificationRequired: true,
        },
      ],
    };
  }
}
