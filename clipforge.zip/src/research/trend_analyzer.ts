/**
 * ClipForge Public Signal Trend Analyzer
 * Evaluates public video metadata (recency, velocity, patterns) to infer trend status.
 * Strictly avoids claiming private analytics; records inferences with concrete evidence.
 */

import { YouTubePublicVideoMetadata, TrendAssessment, TrendStatus } from '../contracts/research.ts';

export function analyzePublicTrends(
  videos: YouTubePublicVideoMetadata[],
  topic: string
): TrendAssessment {
  if (!videos || videos.length === 0) {
    return {
      trendStatus: 'insufficient_data',
      confidence: 'low',
      evidence: ['No public video metadata available for analysis.'],
      analysis: `Unable to assess public interest trends for "${topic}" due to lack of public video metadata.`,
    };
  }

  const now = Date.now();
  const MS_PER_DAY = 1000 * 60 * 60 * 24;

  let videosLast30Days = 0;
  let videosLast90Days = 0;
  let totalViews = 0;
  let totalViewsInRecent = 0;
  let hasValidViews = false;

  const velocities: number[] = [];

  for (const video of videos) {
    const pubTime = new Date(video.publishedAt).getTime();
    const daysSincePublished = Math.max(1, (now - pubTime) / MS_PER_DAY);

    if (daysSincePublished <= 30) {
      videosLast30Days++;
      if (video.viewCount !== undefined) {
        totalViewsInRecent += video.viewCount;
      }
    }
    if (daysSincePublished <= 90) {
      videosLast90Days++;
    }

    if (video.viewCount !== undefined) {
      hasValidViews = true;
      totalViews += video.viewCount;
      const viewsPerDay = video.viewCount / daysSincePublished;
      velocities.push(viewsPerDay);
    }
  }

  const evidence: string[] = [];
  evidence.push(`Analyzed ${videos.length} public video results related to "${topic}".`);
  evidence.push(`${videosLast30Days} of ${videos.length} videos published within the last 30 days.`);
  evidence.push(`${videosLast90Days} of ${videos.length} videos published within the last 90 days.`);

  if (hasValidViews && velocities.length > 0) {
    const avgVelocity = Math.round(velocities.reduce((a, b) => a + b, 0) / velocities.length);
    evidence.push(`Average observed public view velocity: ~${avgVelocity.toLocaleString()} views/day.`);
  }

  let trendStatus: TrendStatus;
  let confidence: 'high' | 'medium' | 'low';
  let analysis: string;

  const recentRatio = videos.length > 0 ? videosLast30Days / videos.length : 0;

  if (videos.length < 3) {
    trendStatus = 'insufficient_data';
    confidence = 'low';
    analysis = `Sample size too small (${videos.length} videos) to determine trend status reliably.`;
  } else if (recentRatio >= 0.5 && velocities.some(v => v > 5000)) {
    trendStatus = 'emerging';
    confidence = 'high';
    analysis = `High concentration of new content (>=50% in last 30 days) with rapid initial view accumulation suggests an emerging public interest wave.`;
  } else if (recentRatio >= 0.3 || (hasValidViews && totalViewsInRecent > 50000)) {
    trendStatus = 'active';
    confidence = 'medium';
    analysis = `Steady cadence of recent video publications with consistent view velocity indicates an active, ongoing audience conversation.`;
  } else if (videosLast90Days >= 2) {
    trendStatus = 'stable';
    confidence = 'medium';
    analysis = `Content library shows long-term baseline presence across multiple months, representing an evergreen or stable interest topic.`;
  } else {
    trendStatus = 'declining';
    confidence = 'low';
    analysis = `Low volume of recent uploads in public search results suggests slower current search volume or mature topic cycle.`;
  }

  return {
    trendStatus,
    confidence,
    evidence,
    analysis,
  };
}
