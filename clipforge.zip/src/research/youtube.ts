/**
 * ClipForge YouTube Data API Provider
 * Gathers legitimate public YouTube video metadata with rate-limiting, error handling, and secret redaction.
 * If YOUTUBE_API_KEY is missing, gracefully indicates unconfigured state and never fabricates data.
 */

import { IYouTubeProvider } from './interfaces.ts';
import { YouTubePublicVideoMetadata } from '../contracts/research.ts';
import { CacheManager } from '../storage/cache.ts';

export interface YouTubeProviderConfig {
  apiKey?: string;
  cache?: CacheManager;
  timeoutMs?: number;
}

export class YouTubeResearchProvider implements IYouTubeProvider {
  readonly providerName = 'youtube_public_api_v3';
  private readonly apiKey: string;
  private readonly cache?: CacheManager;
  private readonly timeoutMs: number;

  constructor(config: YouTubeProviderConfig = {}) {
    this.apiKey = (config.apiKey !== undefined ? config.apiKey : process.env.YOUTUBE_API_KEY || '').trim();
    this.cache = config.cache;
    this.timeoutMs = config.timeoutMs ?? 8000;
  }

  isAvailable(): boolean {
    return Boolean(this.apiKey && this.apiKey.length > 5);
  }

  private redactKey(errorMsg: string): string {
    if (!this.apiKey) return errorMsg;
    return errorMsg.split(this.apiKey).join('[REDACTED]');
  }

  async searchPublicVideos(
    query: string,
    options: { maxResults?: number; regionCode?: string } = {}
  ): Promise<{
    videos: YouTubePublicVideoMetadata[];
    totalResultsEstimated?: number;
    error?: string;
  }> {
    if (!this.isAvailable()) {
      return {
        videos: [],
        error: 'YOUTUBE_API_KEY is not configured. Public YouTube research was skipped.',
      };
    }

    const maxResults = Math.min(options.maxResults ?? 5, 25);
    const regionCode = options.regionCode ?? 'US';

    // Check cache
    const cacheKey = this.cache?.generateKey('youtube_search', {
      query: query.toLowerCase().trim(),
      maxResults,
      regionCode,
    });

    if (this.cache && cacheKey) {
      const cached = await this.cache.get<{
        videos: YouTubePublicVideoMetadata[];
        totalResultsEstimated?: number;
      }>(cacheKey);
      if (cached) {
        return cached;
      }
    }

    try {
      // 1. Search endpoint
      const searchUrl = new URL('https://www.googleapis.com/youtube/v3/search');
      searchUrl.searchParams.set('part', 'snippet');
      searchUrl.searchParams.set('q', query);
      searchUrl.searchParams.set('type', 'video');
      searchUrl.searchParams.set('maxResults', String(maxResults));
      searchUrl.searchParams.set('regionCode', regionCode);
      searchUrl.searchParams.set('key', this.apiKey);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.timeoutMs);

      const searchRes = await fetch(searchUrl.toString(), {
        signal: controller.signal,
        headers: { Accept: 'application/json' },
      });
      clearTimeout(timeoutId);

      if (!searchRes.ok) {
        const errorText = await searchRes.text();
        const safeError = this.redactKey(`YouTube search failed with status ${searchRes.status}: ${errorText}`);
        return { videos: [], error: safeError };
      }

      const searchData = await searchRes.json() as {
        items?: Array<{
          id?: { videoId?: string };
          snippet?: {
            title?: string;
            description?: string;
            publishedAt?: string;
            channelId?: string;
            channelTitle?: string;
            thumbnails?: { medium?: { url?: string }; default?: { url?: string } };
          };
        }>;
        pageInfo?: { totalResults?: number };
      };

      const videoIds = (searchData.items || [])
        .map(item => item.id?.videoId)
        .filter((id): id is string => Boolean(id));

      if (videoIds.length === 0) {
        return { videos: [], totalResultsEstimated: 0 };
      }

      // 2. Fetch full video statistics and details
      const videosUrl = new URL('https://www.googleapis.com/youtube/v3/videos');
      videosUrl.searchParams.set('part', 'snippet,contentDetails,statistics');
      videosUrl.searchParams.set('id', videoIds.join(','));
      videosUrl.searchParams.set('key', this.apiKey);

      const videoController = new AbortController();
      const videoTimeoutId = setTimeout(() => videoController.abort(), this.timeoutMs);

      const videosRes = await fetch(videosUrl.toString(), {
        signal: videoController.signal,
        headers: { Accept: 'application/json' },
      });
      clearTimeout(videoTimeoutId);

      if (!videosRes.ok) {
        const errorText = await videosRes.text();
        const safeError = this.redactKey(`YouTube video details failed with status ${videosRes.status}: ${errorText}`);
        return { videos: [], error: safeError };
      }

      const videosData = await videosRes.json() as {
        items?: Array<{
          id: string;
          snippet?: {
            title?: string;
            description?: string;
            publishedAt?: string;
            channelId?: string;
            channelTitle?: string;
            tags?: string[];
            thumbnails?: { high?: { url?: string }; medium?: { url?: string }; default?: { url?: string } };
          };
          contentDetails?: {
            duration?: string;
          };
          statistics?: {
            viewCount?: string;
            likeCount?: string;
            commentCount?: string;
          };
        }>;
      };

      const normalizedVideos: YouTubePublicVideoMetadata[] = (videosData.items || []).map(item => ({
        videoId: item.id,
        title: item.snippet?.title || 'Untitled',
        description: item.snippet?.description || '',
        publishedAt: item.snippet?.publishedAt || new Date().toISOString(),
        channelId: item.snippet?.channelId || '',
        channelTitle: item.snippet?.channelTitle || 'Unknown Channel',
        viewCount: item.statistics?.viewCount !== undefined ? Number(item.statistics.viewCount) : undefined,
        likeCount: item.statistics?.likeCount !== undefined ? Number(item.statistics.likeCount) : undefined,
        commentCount: item.statistics?.commentCount !== undefined ? Number(item.statistics.commentCount) : undefined,
        durationIso: item.contentDetails?.duration,
        tags: item.snippet?.tags,
        thumbnailUrl: item.snippet?.thumbnails?.high?.url || item.snippet?.thumbnails?.medium?.url || item.snippet?.thumbnails?.default?.url,
      }));

      const result = {
        videos: normalizedVideos,
        totalResultsEstimated: searchData.pageInfo?.totalResults,
      };

      if (this.cache && cacheKey) {
        await this.cache.set('youtube_search', cacheKey, result);
      }

      return result;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      return {
        videos: [],
        error: this.redactKey(`YouTube API network/request error: ${msg}`),
      };
    }
  }
}
