/**
 * ClipForge Dynamic Research Query Generator
 * Formulates diverse search angles (explanation, recent updates, controversy, facts, future implications, questions).
 */

export interface QueryGenerationOptions {
  maxQueries?: number;
}

export function generateResearchQueries(
  topic: string,
  options: QueryGenerationOptions = {}
): string[] {
  const max = options.maxQueries ?? 6;
  const cleanTopic = topic.trim();

  if (!cleanTopic) {
    return [];
  }

  // Multi-dimensional query angles
  const potentialQueries: string[] = [
    // 1. Foundational / Direct
    cleanTopic,
    // 2. Explanatory / Mechanism
    `${cleanTopic} explained how it works`,
    // 3. Recent developments / Trending news
    `${cleanTopic} latest developments breakdown`,
    // 4. Data / Evidence / Statistics
    `${cleanTopic} key statistics facts`,
    // 5. Controversy / Debate / Counter-intuitive
    `${cleanTopic} controversy debate risks`,
    // 6. Future implications
    `future of ${cleanTopic} impact`,
    // 7. Practical audience questions / mistakes
    `${cleanTopic} what you need to know mistakes`,
    // 8. Surprising / Hidden aspects
    `${cleanTopic} surprising truth`,
  ];

  // Deduplicate and normalize
  const seen = new Set<string>();
  const deduplicated: string[] = [];

  for (const q of potentialQueries) {
    const normalized = q.toLowerCase().replace(/\s+/g, ' ').trim();
    if (!seen.has(normalized)) {
      seen.add(normalized);
      deduplicated.push(q);
      if (deduplicated.length >= max) {
        break;
      }
    }
  }

  return deduplicated;
}
