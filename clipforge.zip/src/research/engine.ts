/**
 * ClipForge Research Engine
 * Coordinates query generation, YouTube public data harvesting, trend inference, Gemini synthesis, and artifact generation.
 */

import crypto from 'node:crypto';
import path from 'node:path';
import { VideoFormat } from '../contracts/common.ts';
import { ResearchArtifact } from '../contracts/research.ts';
import {
  IResearchEngine,
  ResearchOptions,
  IYouTubeProvider,
  IGeminiResearchProvider,
} from './interfaces.ts';
import { generateResearchQueries } from './query_generator.ts';
import { analyzePublicTrends } from './trend_analyzer.ts';
import { YouTubeResearchProvider } from './youtube.ts';
import { GeminiResearchProvider } from './gemini.ts';
import { IStorageProvider } from '../storage/interface.ts';
import { LocalStorageProvider } from '../storage/local.ts';
import { CacheManager } from '../storage/cache.ts';

export interface ResearchEngineDependencies {
  storage?: IStorageProvider;
  cache?: CacheManager;
  youtubeProvider?: IYouTubeProvider;
  geminiProvider?: IGeminiResearchProvider;
}

export class ResearchEngine implements IResearchEngine {
  private readonly storage: IStorageProvider;
  private readonly cache: CacheManager;
  private readonly youtubeProvider: IYouTubeProvider;
  private readonly geminiProvider: IGeminiResearchProvider;

  constructor(deps: ResearchEngineDependencies = {}) {
    this.storage = deps.storage || new LocalStorageProvider();
    this.cache = deps.cache || new CacheManager(this.storage);
    this.youtubeProvider = deps.youtubeProvider || new YouTubeResearchProvider({ cache: this.cache });
    this.geminiProvider = deps.geminiProvider || new GeminiResearchProvider({ cache: this.cache });
  }

  async executeResearch(
    topic: string,
    options: ResearchOptions
  ): Promise<ResearchArtifact> {
    const jobId = options.jobId || `job_${crypto.randomBytes(6).toString('hex')}`;
    const format = options.format;
    const errors: string[] = [];

    // 1. Generate diverse search queries
    const queries = generateResearchQueries(topic, {
      maxQueries: options.maxQueries ?? 4,
    });

    // 2. Query YouTube Data API if configured
    const observedVideos: Array<import('../contracts/research.ts').YouTubePublicVideoMetadata> = [];
    const sources: Array<{
      type: 'youtube_public' | 'web_search' | 'news';
      url?: string;
      title: string;
      snippet: string;
      observedDate?: string;
    }> = [];

    const isYouTubeAvailable = this.youtubeProvider.isAvailable();

    if (isYouTubeAvailable) {
      for (const q of queries.slice(0, 3)) {
        const ytRes = await this.youtubeProvider.searchPublicVideos(q, {
          maxResults: options.maxResultsPerQuery ?? 5,
        });

        if (ytRes.error) {
          errors.push(ytRes.error);
        }

        for (const v of ytRes.videos) {
          if (!observedVideos.some(existing => existing.videoId === v.videoId)) {
            observedVideos.push(v);
            sources.push({
              type: 'youtube_public',
              url: `https://www.youtube.com/watch?v=${v.videoId}`,
              title: v.title,
              snippet: v.description.slice(0, 200),
              observedDate: v.publishedAt,
            });
          }
        }
      }
    } else {
      errors.push('YouTube Data API is not configured; proceeding with AI-synthesized research baseline.');
    }

    // 3. Analyze public trends (inference from public data)
    const trendAssessment = analyzePublicTrends(observedVideos, topic);

    // 4. Gemini structured research synthesis
    const synthesis = await this.geminiProvider.synthesizeResearch({
      topic,
      format,
      queriesGenerated: queries,
      observedYouTubeVideos: observedVideos,
      trendAssessment,
    });

    // 5. Assemble structured research artifact
    const artifact: ResearchArtifact = {
      jobId,
      topic,
      createdAt: new Date().toISOString(),
      formatTarget: format,
      searchQueries: queries,
      observedData: {
        topic,
        collectedAt: new Date().toISOString(),
        sources,
        youtubePublicVideos: observedVideos,
        competitorTitles: synthesis.competitorTitles.length > 0
          ? synthesis.competitorTitles
          : observedVideos.map(v => v.title),
        commonQuestions: synthesis.commonQuestions,
        verifiableFacts: synthesis.verifiableFacts,
      },
      inferredInsights: {
        ...synthesis.inferredInsights,
        trendAssessment,
        claimsRequiringVerification: synthesis.claimsRequiringVerification,
      },
      providerMetadata: {
        youtubeConfigured: isYouTubeAvailable,
        geminiModel: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
        queriesExecuted: queries.length,
        cacheHits: 0,
      },
      errors: errors.length > 0 ? errors : undefined,
    };

    // 6. Persist to job cache directory
    const artifactKey = `jobs/${jobId}/research.json`;
    if (this.storage instanceof LocalStorageProvider) {
      await this.storage.writeJson('inputs', artifactKey, artifact);
    }

    return artifact;
  }
}
