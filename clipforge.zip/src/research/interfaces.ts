/**
 * ClipForge Research Interfaces
 * Replaceable providers and data contracts for research gathering and synthesis.
 */

import { VideoFormat } from '../contracts/common.ts';
import {
  YouTubePublicVideoMetadata,
  ResearchArtifact,
  TrendAssessment,
  ObservedResearchData,
  InferredResearchInsights,
} from '../contracts/research.ts';

export interface ResearchOptions {
  jobId?: string;
  format: VideoFormat;
  maxQueries?: number;
  maxResultsPerQuery?: number;
  useCache?: boolean;
}

export interface IYouTubeProvider {
  readonly providerName: string;
  isAvailable(): boolean;
  searchPublicVideos(
    query: string,
    options?: { maxResults?: number; regionCode?: string }
  ): Promise<{
    videos: YouTubePublicVideoMetadata[];
    totalResultsEstimated?: number;
    error?: string;
  }>;
}

export interface GeminiResearchSynthesisInput {
  topic: string;
  format: VideoFormat;
  queriesGenerated: string[];
  observedYouTubeVideos: YouTubePublicVideoMetadata[];
  trendAssessment?: TrendAssessment;
}

export interface GeminiResearchSynthesisResult {
  topicSummary: string;
  verifiableFacts: Array<{
    claim: string;
    source: string;
    confidence: 'high' | 'medium' | 'unverified';
  }>;
  commonQuestions: string[];
  competitorTitles: string[];
  inferredInsights: InferredResearchInsights;
  claimsRequiringVerification: Array<{
    claim: string;
    reason: string;
    verificationRequired: boolean;
  }>;
}

export interface IGeminiResearchProvider {
  readonly providerName: string;
  isAvailable(): boolean;
  synthesizeResearch(
    input: GeminiResearchSynthesisInput
  ): Promise<GeminiResearchSynthesisResult>;
}

export interface IResearchEngine {
  executeResearch(
    topic: string,
    options: ResearchOptions
  ): Promise<ResearchArtifact>;
}
