/**
 * ClipForge Rendering Errors
 * Structured, actionable error classes for FFmpeg execution, asset resolution, and media validation.
 */

import { RenderError } from '../contracts/rendering.ts';

export class RenderException extends Error {
  readonly code: string;
  readonly stage?: string;
  readonly details?: Record<string, unknown>;

  constructor(message: string, code = 'RENDER_ERROR', stage?: string, details?: Record<string, unknown>) {
    super(message);
    this.name = 'RenderException';
    this.code = code;
    this.stage = stage;
    this.details = details;
    Object.setPrototypeOf(this, new.target.prototype);
  }

  toRenderError(): RenderError {
    return {
      code: this.code,
      message: this.message,
      stage: this.stage,
      details: this.details,
    };
  }
}

export class MissingAssetError extends RenderException {
  readonly assetId: string;
  readonly assetType: 'video' | 'narration' | 'music' | 'sfx' | 'font';
  readonly expectedPath: string;
  readonly sceneOrTrack: string;
  readonly reason: string;

  constructor(params: {
    assetId: string;
    assetType: 'video' | 'narration' | 'music' | 'sfx' | 'font';
    expectedPath: string;
    sceneOrTrack: string;
    reason?: string;
  }) {
    const reason = params.reason || 'File does not exist or is 0 bytes';
    const message = `Render failed: ${params.assetType.toUpperCase()} asset "${params.assetId}" is missing at "${params.expectedPath}" for ${params.sceneOrTrack}. (${reason})`;
    super(message, 'MISSING_ASSET', 'prepare_assets', {
      assetId: params.assetId,
      assetType: params.assetType,
      expectedPath: params.expectedPath,
      sceneOrTrack: params.sceneOrTrack,
      reason,
    });
    this.name = 'MissingAssetError';
    this.assetId = params.assetId;
    this.assetType = params.assetType;
    this.expectedPath = params.expectedPath;
    this.sceneOrTrack = params.sceneOrTrack;
    this.reason = reason;
  }

  override toRenderError(): RenderError {
    return {
      ...super.toRenderError(),
      assetId: this.assetId,
      assetType: this.assetType,
      expectedPath: this.expectedPath,
      sceneOrTrack: this.sceneOrTrack,
    };
  }
}

export class FfmpegUnavailableError extends RenderException {
  constructor(binaryPath = 'ffmpeg') {
    super(
      `FFmpeg binary not found or not executable at "${binaryPath}". Ensure ffmpeg is installed and available in system PATH.`,
      'FFMPEG_UNAVAILABLE',
      'environment_check'
    );
    this.name = 'FfmpegUnavailableError';
  }
}

export class FfprobeUnavailableError extends RenderException {
  constructor(binaryPath = 'ffprobe') {
    super(
      `FFprobe binary not found or not executable at "${binaryPath}". Ensure ffprobe is installed and available in system PATH.`,
      'FFPROBE_UNAVAILABLE',
      'environment_check'
    );
    this.name = 'FfprobeUnavailableError';
  }
}

export class FfmpegExecutionError extends RenderException {
  readonly exitCode: number | null;
  readonly stderrSnippet: string;

  constructor(message: string, exitCode: number | null, stderrSnippet: string, commandSnippet?: string) {
    super(
      `FFmpeg process failed (exit code ${exitCode}): ${message}`,
      'FFMPEG_EXECUTION_FAILED',
      'encode_pass',
      { exitCode, stderrSnippet, commandSnippet }
    );
    this.name = 'FfmpegExecutionError';
    this.exitCode = exitCode;
    this.stderrSnippet = stderrSnippet;
  }
}

export class InvalidTimelineError extends RenderException {
  readonly validationIssues: string[];

  constructor(issues: string[]) {
    super(
      `Invalid timeline artifact: ${issues.join('; ')}`,
      'INVALID_TIMELINE',
      'prepare_assets',
      { validationIssues: issues }
    );
    this.name = 'InvalidTimelineError';
    this.validationIssues = issues;
  }
}

export class OutputValidationError extends RenderException {
  readonly failedChecks: string[];

  constructor(failedChecks: string[], message?: string) {
    super(
      message || `Rendered media output failed validation checks: ${failedChecks.join(', ')}`,
      'OUTPUT_VALIDATION_FAILED',
      'validate_output',
      { failedChecks }
    );
    this.name = 'OutputValidationError';
    this.failedChecks = failedChecks;
  }
}
