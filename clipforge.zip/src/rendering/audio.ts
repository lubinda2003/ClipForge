/**
 * ClipForge Audio Filter & Mixing Engine
 * Prepares narration, background music with dynamic speech ducking, and synchronized SFX accents.
 */

import { AudioClipElement, NarrationClipElement } from '../contracts/timeline.ts';

export interface DuckingEnvelopePoint {
  timestampSeconds: number;
  volumeMultiplier: number;
}

export class AudioMixerBuilder {
  /**
   * Builds an FFmpeg volume expression for piecewise-linear ducking based on envelope points.
   */
  static buildDuckingExpression(
    envelope: DuckingEnvelopePoint[] | undefined,
    baseVolume: number
  ): string {
    const vol = Math.max(0, Math.min(2.0, baseVolume));
    if (!envelope || envelope.length === 0) {
      return `volume=${vol.toFixed(3)}`;
    }

    // Sort envelope points by timestamp
    const sorted = [...envelope].sort((a, b) => a.timestampSeconds - b.timestampSeconds);

    // Dedup adjacent identical timestamps
    const cleanPoints: DuckingEnvelopePoint[] = [];
    for (const pt of sorted) {
      if (cleanPoints.length === 0) {
        cleanPoints.push(pt);
      } else {
        const last = cleanPoints[cleanPoints.length - 1];
        if (Math.abs(last.timestampSeconds - pt.timestampSeconds) > 0.01) {
          cleanPoints.push(pt);
        }
      }
    }

    if (cleanPoints.length === 1) {
      const v = (cleanPoints[0].volumeMultiplier * vol).toFixed(3);
      return `volume=${v}`;
    }

    // Build nested if(lt(t, t_i), ...) structure
    // if t < t_0: v_0
    // for each segment [i, i+1]:
    //   if t < t_{i+1}: v_i + (v_{i+1} - v_i)*(t - t_i)/(t_{i+1} - t_i)
    // else: v_last
    let expr = (cleanPoints[cleanPoints.length - 1].volumeMultiplier).toFixed(3);

    for (let i = cleanPoints.length - 2; i >= 0; i--) {
      const p0 = cleanPoints[i];
      const p1 = cleanPoints[i + 1];
      const t0 = p0.timestampSeconds.toFixed(3);
      const t1 = p1.timestampSeconds.toFixed(3);
      const v0 = p0.volumeMultiplier.toFixed(3);
      const v1 = p1.volumeMultiplier.toFixed(3);
      const dt = (p1.timestampSeconds - p0.timestampSeconds).toFixed(3);

      const segExpr = `${v0}+(${v1}-${v0})*(t-${t0})/${dt}`;
      expr = `if(lt(t,${t1}),${segExpr},${expr})`;
    }

    const firstT0 = cleanPoints[0].timestampSeconds.toFixed(3);
    const firstV0 = cleanPoints[0].volumeMultiplier.toFixed(3);
    expr = `if(lt(t,${firstT0}),${firstV0},${expr})`;

    // Multiply by base volume
    return `volume=eval=frame:volume='(${expr})*${vol.toFixed(3)}'`;
  }

  /**
   * Builds filter chain for a narration clip.
   */
  static buildNarrationFilter(clip: NarrationClipElement, inputIndex: number): string {
    const delayMs = Math.max(0, Math.round(clip.startTimelineSeconds * 1000));
    const vol = Math.max(0.01, Math.min(2.0, clip.volume || 1.0));
    const filters = [
      `[${inputIndex}:a]`,
      `aresample=48000`,
      `aformat=channel_layouts=stereo`,
      `volume=${vol.toFixed(3)}`,
      `adelay=${delayMs}|${delayMs}`,
      `[narr_${clip.elementId}]`,
    ];
    return filters.join('');
  }

  /**
   * Builds filter chain for background music with ducking and looping.
   */
  static buildMusicFilter(
    clip: AudioClipElement,
    inputIndex: number,
    totalTimelineDurationSeconds: number
  ): string {
    const filters: string[] = [`[${inputIndex}:a]`];
    filters.push(`aresample=48000`);
    filters.push(`aformat=channel_layouts=stereo`);

    if (clip.loop) {
      filters.push(`aloop=loop=-1:size=2e+09`);
    }

    // Trim music to video timeline duration
    const dur = Math.max(1, totalTimelineDurationSeconds);
    filters.push(`atrim=0:${dur.toFixed(3)}`);
    filters.push(`asetpts=PTS-STARTPTS`);

    // Apply ducking envelope
    const duckFilter = this.buildDuckingExpression(clip.duckingEnvelope, clip.volume || 0.3);
    filters.push(duckFilter);

    // Apply smooth fade-out at the end
    const fadeOutDur = Math.min(2.0, dur * 0.15);
    const fadeOutStart = Math.max(0, dur - fadeOutDur);
    filters.push(`afade=t=out:st=${fadeOutStart.toFixed(3)}:d=${fadeOutDur.toFixed(3)}`);

    filters.push(`[mus_${clip.elementId}]`);
    return filters.join(',');
  }

  /**
   * Builds filter chain for an SFX accent clip.
   */
  static buildSfxFilter(clip: AudioClipElement, inputIndex: number): string {
    const delayMs = Math.max(0, Math.round(clip.startTimelineSeconds * 1000));
    const vol = Math.max(0.01, Math.min(2.0, clip.volume || 0.6));
    const filters = [
      `[${inputIndex}:a]`,
      `aresample=48000`,
      `aformat=channel_layouts=stereo`,
      `volume=${vol.toFixed(3)}`,
      `adelay=${delayMs}|${delayMs}`,
      `[sfx_${clip.elementId}]`,
    ];
    return filters.join('');
  }

  /**
   * Builds the final audio mixing filter combining all audio streams.
   */
  static buildFinalMixFilter(
    audioStreamTags: string[],
    outputTag = 'a_out'
  ): string {
    if (audioStreamTags.length === 0) {
      return '';
    }

    if (audioStreamTags.length === 1) {
      return `${audioStreamTags[0]}alimiter=limit=0.95[${outputTag}]`;
    }

    const inputs = audioStreamTags.join('');
    return `${inputs}amix=inputs=${audioStreamTags.length}:duration=longest:dropout_transition=0:normalize=0,alimiter=limit=0.95[${outputTag}]`;
  }
}
