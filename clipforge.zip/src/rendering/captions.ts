/**
 * ClipForge Caption & Text Overlay Filter Builder
 * Renders typographic text overlays with safe zone compliance and FFmpeg drawtext filter generation.
 */

import { TextOverlayElement } from '../contracts/timeline.ts';
import { RenderProfile } from '../contracts/rendering.ts';

export interface CaptionFilterOptions {
  overlay: TextOverlayElement;
  profile: RenderProfile;
}

export class CaptionFilterBuilder {
  /**
   * Escapes special characters for FFmpeg drawtext filter syntax.
   */
  static escapeText(text: string): string {
    return text
      .replace(/\\/g, '\\\\')
      .replace(/'/g, "'\\\\''")
      .replace(/:/g, '\\:')
      .replace(/%/g, '\\%')
      .replace(/;/g, '\\;')
      .replace(/\[/g, '\\[')
      .replace(/\]/g, '\\]')
      .replace(/\n/g, '\n');
  }

  /**
   * Wraps long text to prevent exceeding safe horizontal margins.
   */
  static wrapText(text: string, maxCharsPerLine: number): string {
    if (text.length <= maxCharsPerLine) return text;
    const words = text.split(/\s+/);
    const lines: string[] = [];
    let currentLine = '';

    for (const word of words) {
      if (!currentLine) {
        currentLine = word;
      } else if (currentLine.length + word.length + 1 <= maxCharsPerLine) {
        currentLine += ` ${word}`;
      } else {
        lines.push(currentLine);
        currentLine = word;
      }
    }
    if (currentLine) lines.push(currentLine);
    return lines.join('\n');
  }

  /**
   * Generates a drawtext filter for a single TextOverlayElement.
   */
  static buildFilter(overlay: TextOverlayElement, profile: RenderProfile): string {
    const isVertical = profile.resolution.height > profile.resolution.width;
    const maxChars = isVertical ? 28 : 50;
    const wrappedText = this.wrapText(overlay.primaryText, maxChars);
    const escapedText = this.escapeText(wrappedText);

    const startTime = Math.max(0, overlay.startTimelineSeconds);
    const endTime = startTime + Math.max(0.1, overlay.durationSeconds);
    const enableExpr = `between(t,${startTime.toFixed(2)},${endTime.toFixed(2)})`;

    // Safe zone margins from profile or overlay
    const safeZone = overlay.positioning?.safeZoneMargins || profile.safeZone;
    const topMargin = (safeZone.topPercent / 100) * profile.resolution.height;
    const bottomMargin = (safeZone.bottomPercent / 100) * profile.resolution.height;
    const leftMargin = (safeZone.leftPercent / 100) * profile.resolution.width;
    const rightMargin = (safeZone.rightPercent / 100) * profile.resolution.width;

    // Font size and styling based on variant
    let fontSize = isVertical ? 46 : 38;
    let fontColor = 'white';
    let boxColor = 'black@0.65';
    let boxBorder = isVertical ? 14 : 10;
    let borderW = 2;
    let borderColor = 'black@0.4';

    switch (overlay.styleVariant) {
      case 'hero_hook':
        fontSize = isVertical ? 54 : 44;
        fontColor = '#FACC15'; // Vibrant amber/yellow for hook curiosity
        boxColor = '#000000@0.85';
        boxBorder = 18;
        borderW = 3;
        borderColor = '#FACC15@0.3';
        break;

      case 'statistic_card':
        fontSize = isVertical ? 48 : 40;
        fontColor = '#34D399'; // Emerald accent
        boxColor = '#0F172A@0.85';
        boxBorder = 16;
        break;

      case 'lower_third':
        fontSize = isVertical ? 38 : 32;
        fontColor = '#F8FAFC';
        boxColor = '#1E293B@0.80';
        boxBorder = 12;
        break;

      case 'chapter_title':
        fontSize = isVertical ? 50 : 42;
        fontColor = '#60A5FA'; // Sky blue
        boxColor = '#000000@0.75';
        boxBorder = 16;
        break;

      case 'bold_caption':
      default:
        fontSize = isVertical ? 44 : 36;
        fontColor = '#FFFFFF';
        boxColor = '#000000@0.70';
        boxBorder = 14;
        break;
    }

    // Horizontal positioning
    let xExpr = '(w-text_w)/2';
    if (overlay.positioning?.horizontalAlign === 'left') {
      xExpr = `${Math.round(leftMargin + 20)}`;
    } else if (overlay.positioning?.horizontalAlign === 'right') {
      xExpr = `w-text_w-${Math.round(rightMargin + 20)}`;
    }

    // Vertical positioning (ensuring outside platform UI occlusions)
    let yExpr = '(h-text_h)/2';
    if (overlay.positioning?.verticalAlign === 'top') {
      yExpr = `${Math.round(topMargin + 40)}`;
    } else if (overlay.positioning?.verticalAlign === 'bottom') {
      // Keep inside safe area, above bottom platform overlay (like TikTok audio title & description)
      yExpr = `h-${Math.round(bottomMargin + 60)}-text_h`;
    } else {
      // Center placement: slightly lower than mathematical center in 9:16 for natural viewing eye level
      yExpr = isVertical ? 'h*0.58-text_h/2' : '(h-text_h)/2';
    }

    // Build FFmpeg drawtext filter string
    const filterParts: string[] = [
      `drawtext=text='${escapedText}'`,
      `fontsize=${fontSize}`,
      `fontcolor=${fontColor}`,
      `box=1`,
      `boxcolor=${boxColor}`,
      `boxborderw=${boxBorder}`,
      `borderw=${borderW}`,
      `bordercolor=${borderColor}`,
      `x=${xExpr}`,
      `y=${yExpr}`,
      `enable='${enableExpr}'`,
    ];

    return filterParts.join(':');
  }

  /**
   * Builds an array of drawtext filters for all text overlays in a timeline.
   */
  static buildAllFilters(overlays: TextOverlayElement[], profile: RenderProfile): string[] {
    return overlays
      .filter((o) => o.primaryText && o.durationSeconds > 0)
      .map((o) => this.buildFilter(o, profile));
  }
}
