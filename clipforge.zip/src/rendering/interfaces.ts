/**
 * ClipForge Rendering Interfaces
 * Core contracts and abstraction layers for the rendering subsystem.
 */

import {
  RenderProfile,
  RenderRequest,
  RenderResult,
  RenderValidationResult,
  RenderProgress,
} from '../contracts/rendering.ts';
import { TimelineArtifact, VideoClipElement, AudioClipElement, TextOverlayElement } from '../contracts/timeline.ts';

export interface FfmpegStreamInfo {
  index: number;
  codecType: 'video' | 'audio' | 'subtitle' | 'data';
  codecName: string;
  width?: number;
  height?: number;
  duration?: number;
  fps?: number;
  channels?: number;
  sampleRate?: number;
  bitRate?: number;
  pixFmt?: string;
}

export interface FfprobeData {
  format: {
    filename: string;
    formatName: string;
    duration: number;
    sizeBytes: number;
    bitRate?: number;
    tags?: Record<string, string>;
  };
  streams: FfmpegStreamInfo[];
  videoStream?: FfmpegStreamInfo;
  audioStream?: FfmpegStreamInfo;
}

export interface FfmpegRunOptions {
  timeoutMs?: number;
  onProgress?: (progress: RenderProgress) => void;
  expectedDurationSeconds?: number;
  cwd?: string;
  env?: NodeJS.ProcessEnv;
}

export interface FfmpegRunResult {
  exitCode: number;
  stdout: string;
  stderr: string;
  durationSeconds: number;
}

export interface IFfmpegRunner {
  isAvailable(): Promise<boolean>;
  getVersion(): Promise<string | null>;
  run(args: string[], outputPath?: string, options?: FfmpegRunOptions): Promise<FfmpegRunResult>;
}

export interface IFfprobeRunner {
  isAvailable(): Promise<boolean>;
  getVersion(): Promise<string | null>;
  probe(filePath: string): Promise<FfprobeData>;
}

export interface VideoClipRenderPlan {
  clip: VideoClipElement;
  resolvedSourcePath: string;
  targetWidth: number;
  targetHeight: number;
  fps: number;
}

export interface AudioMixPlan {
  narrationClips: Array<{
    clip: AudioClipElement | { elementId: string; audioFilePath: string; startTimelineSeconds: number; durationSeconds: number; volume: number };
    resolvedPath: string;
  }>;
  musicClips: Array<{
    clip: AudioClipElement;
    resolvedPath: string;
  }>;
  sfxClips: Array<{
    clip: AudioClipElement;
    resolvedPath: string;
  }>;
  totalDurationSeconds: number;
}

export interface CaptionRenderPlan {
  overlays: TextOverlayElement[];
  profile: RenderProfile;
  totalDurationSeconds: number;
}

export interface IRenderEngine {
  checkEnvironment(): Promise<{
    ffmpegAvailable: boolean;
    ffprobeAvailable: boolean;
    ffmpegVersion?: string;
    ffprobeVersion?: string;
  }>;

  executeRender(request: RenderRequest): Promise<RenderResult>;

  validateOutput(
    videoFilePath: string,
    expectedProfile?: RenderProfile,
    jobId?: string,
    timelineDurationSeconds?: number
  ): Promise<RenderValidationResult>;
}
