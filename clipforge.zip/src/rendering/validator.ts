/**
 * ClipForge Media Output Validator
 * Uses real FFprobe metadata extraction to validate containers, stream codecs, dimensions, and duration.
 */

import fs from 'node:fs';
import { RenderProfile, RenderValidationResult } from '../contracts/rendering.ts';
import { IFfprobeRunner, FfprobeData } from './interfaces.ts';
import { FfprobeRunner } from './ffprobe.ts';

export interface ValidationOptions {
  jobId?: string;
  expectedProfile?: RenderProfile;
  profile?: RenderProfile;
  expectedDurationSeconds?: number;
  targetDurationSeconds?: number;
  durationToleranceSeconds?: number;
  ffprobeRunner?: IFfprobeRunner;
}

export class MediaOutputValidator {
  private readonly ffprobe: IFfprobeRunner;

  constructor(ffprobe?: IFfprobeRunner) {
    this.ffprobe = ffprobe || new FfprobeRunner();
  }

  /**
   * Validates a rendered media file against expectations and specifications.
   */
  async validate(
    videoFilePath: string,
    options: ValidationOptions = {}
  ): Promise<RenderValidationResult> {
    const jobId = options.jobId || 'anonymous_job';
    const tolerance = options.durationToleranceSeconds ?? 1.2; // 1.2s tolerance for GOP/sample alignment
    const expectedProfile = options.expectedProfile ?? options.profile;
    const expectedDurationSeconds = options.expectedDurationSeconds ?? options.targetDurationSeconds;
    const warnings: string[] = [];
    const errors: string[] = [];

    const checks = {
      fileExists: false,
      nonEmpty: false,
      containerValid: false,
      videoStreamValid: false,
      audioStreamValid: false,
      dimensionsValid: true,
      durationValid: true,
      fpsValid: true,
      videoCodecValid: true,
      audioCodecValid: true,
    };

    const outputSummary = {
      path: videoFilePath,
      duration: 0,
      width: 0,
      height: 0,
      fps: 0,
      videoCodec: undefined as string | undefined,
      audioCodec: undefined as string | undefined,
      fileSizeBytes: 0,
    };

    // 1. Check file existence
    if (!fs.existsSync(videoFilePath)) {
      errors.push(`Rendered video file does not exist at "${videoFilePath}"`);
      return {
        jobId,
        status: 'failed',
        output: outputSummary,
        checks,
        warnings,
        errors,
      };
    }
    checks.fileExists = true;

    // 2. Check file size
    const stat = fs.statSync(videoFilePath);
    outputSummary.fileSizeBytes = stat.size;
    if (stat.size <= 0) {
      errors.push(`Rendered video file at "${videoFilePath}" is 0 bytes`);
      return {
        jobId,
        status: 'failed',
        output: outputSummary,
        checks,
        warnings,
        errors,
      };
    }
    checks.nonEmpty = true;

    // 3. Run FFprobe probe
    let probeData: FfprobeData;
    try {
      probeData = await this.ffprobe.probe(videoFilePath);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      errors.push(`FFprobe inspection failed: ${message}`);
      return {
        jobId,
        status: 'failed',
        output: outputSummary,
        checks,
        warnings,
        errors,
      };
    }

    outputSummary.duration = probeData.format.duration;

    // 4. Container validation
    const formatName = probeData.format.formatName.toLowerCase();
    if (formatName.includes('mp4') || formatName.includes('mov') || formatName.includes('quicktime')) {
      checks.containerValid = true;
    } else {
      checks.containerValid = false;
      errors.push(`Container format "${formatName}" is not a recognized MP4/MOV container`);
    }

    // 5. Video stream validation
    const vStream = probeData.videoStream;
    if (vStream) {
      checks.videoStreamValid = true;
      outputSummary.width = vStream.width || 0;
      outputSummary.height = vStream.height || 0;
      outputSummary.fps = vStream.fps || 0;
      outputSummary.videoCodec = vStream.codecName;

      // Codec check (h264 matches libx264)
      if (expectedProfile) {
        const expectedVideoCodec = expectedProfile.videoCodec;
        const actualCodec = vStream.codecName.toLowerCase();
        if (expectedVideoCodec === 'libx264' && actualCodec !== 'h264' && actualCodec !== 'avc1') {
          checks.videoCodecValid = false;
          errors.push(`Expected video codec libx264/h264, but got "${actualCodec}"`);
        }
      }

      // Dimensions check
      if (expectedProfile) {
        const expW = expectedProfile.resolution.width;
        const expH = expectedProfile.resolution.height;
        if (outputSummary.width !== expW || outputSummary.height !== expH) {
          checks.dimensionsValid = false;
          errors.push(
            `Dimensions mismatch: Expected ${expW}x${expH}, but probed video is ${outputSummary.width}x${outputSummary.height}`
          );
        }
      }

      // Frame rate check
      if (expectedProfile && expectedProfile.frameRate) {
        const expFps = expectedProfile.frameRate;
        if (outputSummary.fps > 0 && Math.abs(outputSummary.fps - expFps) > 1.5) {
          checks.fpsValid = false;
          warnings.push(
            `Frame rate slightly deviates: Expected ${expFps} fps, got ${outputSummary.fps} fps`
          );
        }
      }
    } else {
      checks.videoStreamValid = false;
      errors.push('No video stream found in rendered media file');
    }

    // 6. Audio stream validation
    const aStream = probeData.audioStream;
    if (aStream) {
      checks.audioStreamValid = true;
      outputSummary.audioCodec = aStream.codecName;

      if (expectedProfile) {
        const expectedAudioCodec = expectedProfile.audioCodec;
        const actualCodec = aStream.codecName.toLowerCase();
        if (expectedAudioCodec === 'aac' && actualCodec !== 'aac') {
          checks.audioCodecValid = false;
          errors.push(`Expected audio codec aac, but got "${actualCodec}"`);
        }
      }
    } else {
      checks.audioStreamValid = false;
      errors.push('No audio stream found in rendered media file');
    }

    // 7. Duration validation
    if (expectedDurationSeconds && expectedDurationSeconds > 0) {
      const expDur = expectedDurationSeconds;
      const actualDur = outputSummary.duration;
      const diff = Math.abs(actualDur - expDur);

      if (diff > tolerance) {
        checks.durationValid = false;
        errors.push(
          `Duration mismatch: Expected ${expDur.toFixed(2)}s (±${tolerance}s), but probed duration is ${actualDur.toFixed(2)}s (diff: ${diff.toFixed(2)}s)`
        );
      } else if (diff > 0.4) {
        warnings.push(
          `Minor duration deviation: Expected ${expDur.toFixed(2)}s, probed ${actualDur.toFixed(2)}s`
        );
      }
    }

    const allEssentialPassed =
      checks.fileExists &&
      checks.nonEmpty &&
      checks.containerValid &&
      checks.videoStreamValid &&
      checks.audioStreamValid &&
      checks.dimensionsValid &&
      checks.durationValid &&
      checks.videoCodecValid &&
      checks.audioCodecValid;

    return {
      jobId,
      status: allEssentialPassed ? 'passed' : 'failed',
      output: outputSummary,
      checks,
      warnings,
      errors,
    };
  }
}
