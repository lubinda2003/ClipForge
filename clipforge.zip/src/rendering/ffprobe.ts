/**
 * ClipForge FFprobe Media Inspector
 * Inspects generated and source media to extract precise stream data and container metadata.
 */

import { spawn } from 'node:child_process';
import fs from 'node:fs';
import { IFfprobeRunner, FfprobeData, FfmpegStreamInfo } from './interfaces.ts';
import { FfprobeUnavailableError } from './errors.ts';

export class FfprobeRunner implements IFfprobeRunner {
  readonly binaryPath: string;

  constructor(binaryPath = 'ffprobe') {
    this.binaryPath = binaryPath;
  }

  async isAvailable(): Promise<boolean> {
    try {
      const version = await this.getVersion();
      return version !== null;
    } catch {
      return false;
    }
  }

  async getVersion(): Promise<string | null> {
    return new Promise((resolve) => {
      const proc = spawn(this.binaryPath, ['-version']);
      let output = '';

      proc.stdout.on('data', (d) => {
        output += d.toString();
      });
      proc.stderr.on('data', (d) => {
        output += d.toString();
      });

      proc.on('error', () => {
        resolve(null);
      });

      proc.on('close', (code) => {
        if (code === 0 && output.includes('ffprobe version')) {
          const match = output.match(/ffprobe version ([^\s]+)/i);
          resolve(match ? match[1] : 'unknown');
        } else {
          resolve(null);
        }
      });
    });
  }

  async probe(filePath: string): Promise<FfprobeData> {
    const available = await this.isAvailable();
    if (!available) {
      throw new FfprobeUnavailableError(this.binaryPath);
    }

    if (!fs.existsSync(filePath)) {
      throw new Error(`Media file does not exist for FFprobe inspection: "${filePath}"`);
    }

    return new Promise<FfprobeData>((resolve, reject) => {
      const args = [
        '-v', 'quiet',
        '-print_format', 'json',
        '-show_format',
        '-show_streams',
        '-show_error',
        filePath,
      ];

      const proc = spawn(this.binaryPath, args);
      let stdout = '';
      let stderr = '';

      proc.stdout.on('data', (chunk) => {
        stdout += chunk.toString();
      });
      proc.stderr.on('data', (chunk) => {
        stderr += chunk.toString();
      });

      proc.on('error', (err) => {
        reject(new Error(`Failed to execute FFprobe on "${filePath}": ${err.message}`));
      });

      proc.on('close', (code) => {
        if (code !== 0) {
          reject(new Error(`FFprobe failed with exit code ${code} for "${filePath}": ${stderr}`));
          return;
        }

        try {
          const parsed = JSON.parse(stdout);
          const rawFormat = parsed.format || {};
          const rawStreams: Array<Record<string, unknown>> = parsed.streams || [];

          const streams: FfmpegStreamInfo[] = rawStreams.map((s, idx) => {
            let fps: number | undefined;
            const rFrameRate = String(s.r_frame_rate || '');
            if (rFrameRate.includes('/')) {
              const [num, den] = rFrameRate.split('/').map(Number);
              if (den > 0) fps = Math.round((num / den) * 100) / 100;
            } else if (rFrameRate) {
              fps = parseFloat(rFrameRate);
            }

            return {
              index: typeof s.index === 'number' ? s.index : idx,
              codecType: (s.codec_type as 'video' | 'audio' | 'subtitle' | 'data') || 'video',
              codecName: String(s.codec_name || 'unknown'),
              width: typeof s.width === 'number' ? s.width : undefined,
              height: typeof s.height === 'number' ? s.height : undefined,
              duration: s.duration ? parseFloat(String(s.duration)) : undefined,
              fps,
              channels: typeof s.channels === 'number' ? s.channels : undefined,
              sampleRate: s.sample_rate ? parseInt(String(s.sample_rate), 10) : undefined,
              bitRate: s.bit_rate ? parseInt(String(s.bit_rate), 10) : undefined,
              pixFmt: typeof s.pix_fmt === 'string' ? s.pix_fmt : undefined,
            };
          });

          const videoStream = streams.find((s) => s.codecType === 'video');
          const audioStream = streams.find((s) => s.codecType === 'audio');

          const data: FfprobeData = {
            format: {
              filename: String(rawFormat.filename || filePath),
              formatName: String(rawFormat.format_name || 'unknown'),
              duration: rawFormat.duration ? parseFloat(String(rawFormat.duration)) : 0,
              sizeBytes: rawFormat.size ? parseInt(String(rawFormat.size), 10) : 0,
              bitRate: rawFormat.bit_rate ? parseInt(String(rawFormat.bit_rate), 10) : undefined,
              tags: (rawFormat.tags as Record<string, string>) || {},
            },
            streams,
            videoStream,
            audioStream,
          };

          resolve(data);
        } catch (err: unknown) {
          const message = err instanceof Error ? err.message : String(err);
          reject(new Error(`Failed to parse FFprobe JSON output for "${filePath}": ${message}`));
        }
      });
    });
  }
}
