/**
 * ClipForge Video Track Filter Builder
 * Prepares video clip trimming, scaling, aspect ratio preservation, motion transforms, and concatenation.
 */

import { VideoClipElement, TextOverlayElement } from '../contracts/timeline.ts';
import { RenderProfile } from '../contracts/rendering.ts';
import { MotionTransformBuilder } from './motion.ts';
import { CaptionFilterBuilder } from './captions.ts';

export interface VideoFilterOptions {
  profile: RenderProfile;
  totalDurationSeconds: number;
}

export class VideoTrackBuilder {
  /**
   * Builds the filter chain for an individual video clip element.
   */
  static buildClipFilter(
    clip: VideoClipElement,
    inputIndex: number,
    clipTag: string,
    profile: RenderProfile
  ): string {
    const { width, height } = profile.resolution;
    const fps = profile.frameRate || 30;
    const trimStart = Math.max(0, clip.sourceTrimStartSeconds || 0);
    const duration = Math.max(0.1, clip.durationSeconds);

    const filters: string[] = [
      `[${inputIndex}:v]`,
      `trim=start=${trimStart.toFixed(3)}:duration=${duration.toFixed(3)}`,
      `setpts=PTS-STARTPTS`,
      `fps=${fps}`,
      // Fill frame without distortion: scale so the smaller dimension reaches target, then crop/motion
      `scale=${width}:${height}:force_original_aspect_ratio=increase`,
    ];

    // Apply motion transform (Ken Burns zoom / pan / centered crop)
    const motion = MotionTransformBuilder.buildFilter({
      effect: clip.motionEffect || 'none',
      width,
      height,
      durationSeconds: duration,
      fps,
    });
    filters.push(motion);

    // Transitions
    if (clip.transitionIn && clip.transitionIn.type === 'fade' && clip.transitionIn.durationSeconds > 0) {
      filters.push(`fade=t=in:st=0:d=${clip.transitionIn.durationSeconds.toFixed(3)}`);
    }
    if (clip.transitionOut && clip.transitionOut.type === 'fade' && clip.transitionOut.durationSeconds > 0) {
      const outStart = Math.max(0, duration - clip.transitionOut.durationSeconds);
      filters.push(`fade=t=out:st=${outStart.toFixed(3)}:d=${clip.transitionOut.durationSeconds.toFixed(3)}`);
    }

    // Enforce consistent 1:1 Sample Aspect Ratio so concat filter never complains
    filters.push(`setsar=1`);
    filters.push(`[${clipTag}]`);

    return filters.join(',');
  }

  /**
   * Assembles the complete video track pipeline:
   * 1. Clip filters for each video segment
   * 2. Concat filter joining all clips sequentially
   * 3. Text/caption overlays respecting safe zones and timing
   */
  static buildVideoPipeline(
    videoClips: VideoClipElement[],
    textOverlays: TextOverlayElement[],
    clipInputIndices: number[],
    profile: RenderProfile,
    totalDurationSeconds: number,
    finalOutputTag = 'v_out'
  ): { filterLines: string[]; outputTag: string } {
    const filterLines: string[] = [];
    const { width, height } = profile.resolution;
    const fps = profile.frameRate || 30;

    if (videoClips.length === 0) {
      // Fallback: generate solid dark canvas if no video clips provided
      const dur = Math.max(1, totalDurationSeconds);
      filterLines.push(
        `color=c=black:s=${width}x${height}:d=${dur.toFixed(3)}:r=${fps},format=pix_fmts=yuv420p,setsar=1[v_concat]`
      );
    } else {
      const clipTags: string[] = [];

      for (let i = 0; i < videoClips.length; i++) {
        const clip = videoClips[i];
        const inputIdx = clipInputIndices[i];
        const clipTag = `v_clip_${i}`;
        clipTags.push(clipTag);

        const filter = this.buildClipFilter(clip, inputIdx, clipTag, profile);
        filterLines.push(filter);
      }

      // Concat all video clips
      if (clipTags.length === 1) {
        filterLines.push(`[${clipTags[0]}]null[v_concat]`);
      } else {
        const inTags = clipTags.map((t) => `[${t}]`).join('');
        filterLines.push(`${inTags}concat=n=${clipTags.length}:v=1:a=0[v_concat]`);
      }
    }

    // Apply text and caption overlays
    const captionFilters = CaptionFilterBuilder.buildAllFilters(textOverlays, profile);

    if (captionFilters.length > 0) {
      const chain = captionFilters.join(',');
      filterLines.push(`[v_concat]${chain},format=pix_fmts=yuv420p[${finalOutputTag}]`);
    } else {
      filterLines.push(`[v_concat]format=pix_fmts=yuv420p[${finalOutputTag}]`);
    }

    return {
      filterLines,
      outputTag: finalOutputTag,
    };
  }
}
