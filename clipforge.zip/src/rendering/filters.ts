/**
 * ClipForge Filter Graph Assembler
 * Coordinates mapping of all visual and acoustic inputs into an optimized FFmpeg filtergraph.
 */

import { TimelineArtifact, VideoClipElement, NarrationClipElement, AudioClipElement } from '../contracts/timeline.ts';
import { RenderProfile } from '../contracts/rendering.ts';
import { VideoTrackBuilder } from './video.ts';
import { AudioMixerBuilder } from './audio.ts';

export interface PreparedInput {
  index: number;
  filePath: string;
  type: 'video' | 'narration' | 'music' | 'sfx';
  elementId: string;
}

export interface AssembledFilterGraph {
  inputs: PreparedInput[];
  ffmpegInputArgs: string[];
  filterComplexScript: string;
  videoOutputMap: string;
  audioOutputMap: string;
  durationSeconds: number;
}

export class FilterGraphAssembler {
  /**
   * Assembles inputs and complex filter graph for a given timeline and render profile.
   */
  static assemble(
    timeline: TimelineArtifact,
    profile: RenderProfile,
    resolvePath: (relPath: string) => string
  ): AssembledFilterGraph {
    const inputs: PreparedInput[] = [];
    const ffmpegInputArgs: string[] = [];

    const addInput = (filePath: string, type: 'video' | 'narration' | 'music' | 'sfx', elementId: string): number => {
      const resolved = resolvePath(filePath);
      const index = inputs.length;
      inputs.push({ index, filePath: resolved, type, elementId });
      ffmpegInputArgs.push('-i', resolved);
      return index;
    };

    // 1. Process Video Clips
    const videoClips = timeline.tracks.video || [];
    const videoInputIndices: number[] = [];
    for (const clip of videoClips) {
      const idx = addInput(clip.sourceFilePath, 'video', clip.elementId);
      videoInputIndices.push(idx);
    }

    // 2. Process Narration Clips
    const narrationClips = timeline.tracks.narration || [];
    const narrationInputs: Array<{ clip: NarrationClipElement; inputIndex: number }> = [];
    for (const clip of narrationClips) {
      const idx = addInput(clip.audioFilePath, 'narration', clip.elementId);
      narrationInputs.push({ clip, inputIndex: idx });
    }

    // 3. Process Music Clips
    const musicClips = timeline.tracks.music || [];
    const musicInputs: Array<{ clip: AudioClipElement; inputIndex: number }> = [];
    for (const clip of musicClips) {
      const idx = addInput(clip.audioFilePath, 'music', clip.elementId);
      musicInputs.push({ clip, inputIndex: idx });
    }

    // 4. Process SFX Clips
    const sfxClips = timeline.tracks.sfx || [];
    const sfxInputs: Array<{ clip: AudioClipElement; inputIndex: number }> = [];
    for (const clip of sfxClips) {
      const idx = addInput(clip.audioFilePath, 'sfx', clip.elementId);
      sfxInputs.push({ clip, inputIndex: idx });
    }

    const totalDuration = timeline.totalDurationSeconds > 0
      ? timeline.totalDurationSeconds
      : videoClips.reduce((acc, c) => Math.max(acc, c.startTimelineSeconds + c.durationSeconds), 0) || 10;

    // 5. Build Video Graph
    const textOverlays = timeline.tracks.textOverlays || [];
    const videoPipeline = VideoTrackBuilder.buildVideoPipeline(
      videoClips,
      textOverlays,
      videoInputIndices,
      profile,
      totalDuration,
      'v_out'
    );

    const allFilterLines: string[] = [...videoPipeline.filterLines];

    // 6. Build Audio Graph
    const audioTags: string[] = [];

    // Narration filters
    for (const item of narrationInputs) {
      const tag = `narr_${item.clip.elementId}`;
      const filter = AudioMixerBuilder.buildNarrationFilter(item.clip, item.inputIndex);
      allFilterLines.push(filter);
      audioTags.push(`[${tag}]`);
    }

    // Music filters
    for (const item of musicInputs) {
      const tag = `mus_${item.clip.elementId}`;
      const filter = AudioMixerBuilder.buildMusicFilter(item.clip, item.inputIndex, totalDuration);
      allFilterLines.push(filter);
      audioTags.push(`[${tag}]`);
    }

    // SFX filters
    for (const item of sfxInputs) {
      const tag = `sfx_${item.clip.elementId}`;
      const filter = AudioMixerBuilder.buildSfxFilter(item.clip, item.inputIndex);
      allFilterLines.push(filter);
      audioTags.push(`[${tag}]`);
    }

    // Mix or generate silence
    if (audioTags.length === 0) {
      allFilterLines.push(
        `anullsrc=r=48000:cl=stereo,atrim=0:${totalDuration.toFixed(3)}[a_out]`
      );
    } else {
      const mixFilter = AudioMixerBuilder.buildFinalMixFilter(audioTags, 'a_out');
      allFilterLines.push(mixFilter);
    }

    const filterComplexScript = allFilterLines.join('; ');

    return {
      inputs,
      ffmpegInputArgs,
      filterComplexScript,
      videoOutputMap: `[${videoPipeline.outputTag}]`,
      audioOutputMap: '[a_out]',
      durationSeconds: totalDuration,
    };
  }
}
