/**
 * ClipForge FFmpeg Subprocess Runner
 * Safely executes FFmpeg commands with atomic output handling, timeout protection, and progress tracking.
 */

import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import {
  IFfmpegRunner,
  FfmpegRunOptions,
  FfmpegRunResult,
} from './interfaces.ts';
import { FfmpegUnavailableError, FfmpegExecutionError } from './errors.ts';
import { RenderProgress } from '../contracts/rendering.ts';

export class FfmpegRunner implements IFfmpegRunner {
  readonly binaryPath: string;

  constructor(binaryPath = 'ffmpeg') {
    this.binaryPath = binaryPath;
  }

  async isAvailable(): Promise<boolean> {
    try {
      const version = await this.getVersion();
      return version !== null;
    } catch {
      return false;
    }
  }

  async getVersion(): Promise<string | null> {
    return new Promise((resolve) => {
      const proc = spawn(this.binaryPath, ['-version']);
      let output = '';

      proc.stdout.on('data', (d) => {
        output += d.toString();
      });
      proc.stderr.on('data', (d) => {
        output += d.toString();
      });

      proc.on('error', () => {
        resolve(null);
      });

      proc.on('close', (code) => {
        if (code === 0 && output.includes('ffmpeg version')) {
          const match = output.match(/ffmpeg version ([^\s]+)/i);
          resolve(match ? match[1] : 'unknown');
        } else {
          resolve(null);
        }
      });
    });
  }

  /**
   * Executes an FFmpeg command.
   * If outputPath is provided, FFmpeg is directed to write to a temporary file,
   * which is atomically renamed on completion to guarantee no corrupt or partial files.
   */
  async run(
    args: string[],
    outputPath?: string,
    options?: FfmpegRunOptions
  ): Promise<FfmpegRunResult> {
    const available = await this.isAvailable();
    if (!available) {
      throw new FfmpegUnavailableError(this.binaryPath);
    }

    const startTime = Date.now();
    let tempOutputPath: string | undefined;
    const finalArgs = [...args];

    if (outputPath) {
      const dir = path.dirname(outputPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      const ext = path.extname(outputPath) || '.mp4';
      const base = path.basename(outputPath, ext);
      tempOutputPath = path.join(dir, `.${base}.tmp_${Date.now()}_${Math.random().toString(36).substring(2, 8)}${ext}`);

      // If the last argument was the destination outputPath, replace it with tempOutputPath
      const lastIndex = finalArgs.length - 1;
      if (lastIndex >= 0 && finalArgs[lastIndex] === outputPath) {
        finalArgs[lastIndex] = tempOutputPath;
      } else {
        finalArgs.push(tempOutputPath);
      }
    }

    const timeoutMs = options?.timeoutMs || 300000; // 5 minute default timeout

    return new Promise<FfmpegRunResult>((resolve, reject) => {
      let stdout = '';
      let stderr = '';
      let isSettled = false;
      let timeoutHandle: NodeJS.Timeout | null = null;

      const proc = spawn(this.binaryPath, finalArgs, {
        cwd: options?.cwd,
        env: { ...process.env, ...options?.env },
      });

      const cleanupTemp = () => {
        if (tempOutputPath && fs.existsSync(tempOutputPath)) {
          try {
            fs.unlinkSync(tempOutputPath);
          } catch {
            // Best effort cleanup
          }
        }
      };

      if (timeoutMs > 0) {
        timeoutHandle = setTimeout(() => {
          if (!isSettled) {
            isSettled = true;
            proc.kill('SIGTERM');
            setTimeout(() => {
              try {
                proc.kill('SIGKILL');
              } catch {
                // Ignore
              }
            }, 2000);
            cleanupTemp();
            reject(
              new FfmpegExecutionError(
                `FFmpeg execution timed out after ${timeoutMs / 1000}s`,
                -1,
                stderr.slice(-1000)
              )
            );
          }
        }, timeoutMs);
      }

      proc.stdout.on('data', (chunk) => {
        stdout += chunk.toString();
      });

      proc.stderr.on('data', (chunk) => {
        const text = chunk.toString();
        stderr += text;

        if (options?.onProgress && options.expectedDurationSeconds && options.expectedDurationSeconds > 0) {
          // Parse time=HH:MM:SS.ss
          const timeMatch = text.match(/time=(\d{2}):(\d{2}):(\d{2}\.\d+)/);
          const fpsMatch = text.match(/fps=\s*([\d.]+)/);

          if (timeMatch) {
            const hours = parseFloat(timeMatch[1]);
            const minutes = parseFloat(timeMatch[2]);
            const seconds = parseFloat(timeMatch[3]);
            const currentSeconds = hours * 3600 + minutes * 60 + seconds;
            const percentage = Math.min(99, Math.max(1, Math.round((currentSeconds / options.expectedDurationSeconds) * 100)));
            const currentFps = fpsMatch ? parseFloat(fpsMatch[1]) : undefined;

            const progress: RenderProgress = {
              jobId: 'active_render',
              stage: 'encode_pass',
              percentage,
              currentFps,
            };
            options.onProgress(progress);
          }
        }
      });

      proc.on('error', (err) => {
        if (!isSettled) {
          isSettled = true;
          if (timeoutHandle) clearTimeout(timeoutHandle);
          cleanupTemp();
          reject(new FfmpegExecutionError(err.message, -1, stderr.slice(-1000)));
        }
      });

      proc.on('close', (exitCode) => {
        if (isSettled) return;
        isSettled = true;
        if (timeoutHandle) clearTimeout(timeoutHandle);

        const durationSeconds = (Date.now() - startTime) / 1000;

        if (exitCode !== 0) {
          cleanupTemp();
          // Extract last 15 lines of stderr for actionable diagnostics
          const errorLines = stderr.trim().split('\n').slice(-15).join('\n');
          reject(new FfmpegExecutionError(errorLines, exitCode, stderr.slice(-2000)));
          return;
        }

        // On success with outputPath, atomically move temp file to outputPath
        if (outputPath && tempOutputPath) {
          try {
            if (!fs.existsSync(tempOutputPath)) {
              reject(new FfmpegExecutionError('FFmpeg completed with exit code 0 but temporary output file was not created.', exitCode, stderr.slice(-1000)));
              return;
            }
            const stats = fs.statSync(tempOutputPath);
            if (stats.size === 0) {
              cleanupTemp();
              reject(new FfmpegExecutionError('FFmpeg produced an empty 0-byte output file.', exitCode, stderr.slice(-1000)));
              return;
            }

            if (fs.existsSync(outputPath)) {
              fs.unlinkSync(outputPath);
            }
            fs.renameSync(tempOutputPath, outputPath);
          } catch (err: unknown) {
            cleanupTemp();
            const message = err instanceof Error ? err.message : String(err);
            reject(new FfmpegExecutionError(`Failed to finalize output file: ${message}`, exitCode, stderr.slice(-1000)));
            return;
          }
        }

        resolve({
          exitCode: exitCode ?? 0,
          stdout,
          stderr,
          durationSeconds,
        });
      });
    });
  }
}
