/**
 * ClipForge Rendering Engine Orchestrator
 * Fully automated pipeline: pre-flight asset verification, FFmpeg execution, FFprobe output validation, and artifact generation.
 */

import fs from 'node:fs';
import path from 'node:path';
import {
  RenderProfile,
  RenderRequest,
  RenderResult,
  RenderValidationResult,
  RenderArtifact,
  SHORT_FORM_PROFILE,
  LONG_FORM_PROFILE,
} from '../contracts/rendering.ts';
import { TimelineArtifact } from '../contracts/timeline.ts';
import { IRenderEngine, IFfmpegRunner, IFfprobeRunner } from './interfaces.ts';
import { FfmpegRunner } from './ffmpeg.ts';
import { FfprobeRunner } from './ffprobe.ts';
import { MediaOutputValidator } from './validator.ts';
import { FilterGraphAssembler } from './filters.ts';
import {
  FfmpegUnavailableError,
  FfprobeUnavailableError,
  MissingAssetError,
  InvalidTimelineError,
} from './errors.ts';
import { IStorageProvider } from '../storage/interface.ts';
import { LocalStorageProvider } from '../storage/local.ts';

export interface RenderEngineConfig {
  ffmpeg?: IFfmpegRunner;
  ffprobe?: IFfprobeRunner;
  storage?: IStorageProvider;
  baseDirectory?: string;
}

export class RenderEngine implements IRenderEngine {
  private readonly ffmpeg: IFfmpegRunner;
  private readonly ffprobe: IFfprobeRunner;
  private readonly validator: MediaOutputValidator;
  private readonly storage: IStorageProvider;
  private readonly baseDirectory: string;

  constructor(config: RenderEngineConfig = {}) {
    this.baseDirectory = path.resolve(config.baseDirectory || './.cache/clipforge');
    this.ffmpeg = config.ffmpeg || new FfmpegRunner();
    this.ffprobe = config.ffprobe || new FfprobeRunner();
    this.storage = config.storage || new LocalStorageProvider(this.baseDirectory);
    this.validator = new MediaOutputValidator(this.ffprobe);
  }

  /**
   * Validates that FFmpeg and FFprobe binaries are installed and accessible.
   */
  async checkEnvironment(): Promise<{
    ffmpegAvailable: boolean;
    ffprobeAvailable: boolean;
    ffmpegVersion?: string;
    ffprobeVersion?: string;
  }> {
    const ffmpegVersion = await this.ffmpeg.getVersion();
    const ffprobeVersion = await this.ffprobe.getVersion();

    return {
      ffmpegAvailable: ffmpegVersion !== null,
      ffprobeAvailable: ffprobeVersion !== null,
      ffmpegVersion: ffmpegVersion || undefined,
      ffprobeVersion: ffprobeVersion || undefined,
    };
  }

  /**
   * Resolves an asset path against multiple standard locations:
   * 1. Direct / absolute path
   * 2. Working directory relative path
   * 3. Storage base directory
   * 4. Standard storage subdirectories (broll, audio, assets, outputs)
   */
  resolveAssetPath(assetPath: string, jobId?: string): string {
    if (!assetPath) return '';

    const candidates = [
      path.resolve(assetPath),
      path.resolve(process.cwd(), assetPath),
      path.resolve(this.baseDirectory, assetPath),
      path.resolve(this.baseDirectory, 'outputs', assetPath),
      path.resolve(this.baseDirectory, 'broll', assetPath),
      path.resolve(this.baseDirectory, 'audio', assetPath),
      path.resolve(this.baseDirectory, 'assets', assetPath),
    ];

    if (jobId) {
      candidates.push(
        path.resolve(this.baseDirectory, 'outputs', 'jobs', jobId, assetPath),
        path.resolve(this.baseDirectory, 'audio', 'jobs', jobId, assetPath)
      );
    }

    for (const cand of candidates) {
      if (fs.existsSync(cand)) {
        return cand;
      }
    }

    // Default to the first candidate if not found yet
    return candidates[1];
  }

  /**
   * Performs rigorous pre-flight validation on the timeline and all referenced media assets.
   * Fails immediately and cleanly with actionable errors if any asset is missing.
   */
  private preflightValidateAssets(timeline: TimelineArtifact, jobId: string): void {
    const issues: string[] = [];

    if (!timeline.tracks) {
      issues.push('Timeline tracks definition is missing');
    }

    if (issues.length > 0) {
      throw new InvalidTimelineError(issues);
    }

    // 1. Verify Video Clips
    const videoClips = timeline.tracks.video || [];
    for (const clip of videoClips) {
      const resolved = this.resolveAssetPath(clip.sourceFilePath, jobId);
      if (!fs.existsSync(resolved) || fs.statSync(resolved).size === 0) {
        throw new MissingAssetError({
          assetId: clip.elementId,
          assetType: 'video',
          expectedPath: resolved,
          sceneOrTrack: `video track clip "${clip.elementId}" (scene "${clip.sceneId}")`,
          reason: !fs.existsSync(resolved) ? 'File not found on disk' : 'File is 0 bytes (empty/corrupted)',
        });
      }
    }

    // 2. Verify Narration Clips
    const narrationClips = timeline.tracks.narration || [];
    for (const clip of narrationClips) {
      const resolved = this.resolveAssetPath(clip.audioFilePath, jobId);
      if (!fs.existsSync(resolved) || fs.statSync(resolved).size === 0) {
        throw new MissingAssetError({
          assetId: clip.elementId,
          assetType: 'narration',
          expectedPath: resolved,
          sceneOrTrack: `narration track segment "${clip.segmentId}"`,
          reason: !fs.existsSync(resolved) ? 'Audio voiceover file not found' : 'Audio voiceover file is 0 bytes',
        });
      }
    }

    // 3. Verify Music Clips
    const musicClips = timeline.tracks.music || [];
    for (const clip of musicClips) {
      const resolved = this.resolveAssetPath(clip.audioFilePath, jobId);
      if (!fs.existsSync(resolved) || fs.statSync(resolved).size === 0) {
        throw new MissingAssetError({
          assetId: clip.elementId,
          assetType: 'music',
          expectedPath: resolved,
          sceneOrTrack: `background music track "${clip.elementId}"`,
          reason: !fs.existsSync(resolved) ? 'Music track file not found' : 'Music track file is 0 bytes',
        });
      }
    }

    // 4. Verify SFX Clips
    const sfxClips = timeline.tracks.sfx || [];
    for (const clip of sfxClips) {
      const resolved = this.resolveAssetPath(clip.audioFilePath, jobId);
      if (!fs.existsSync(resolved) || fs.statSync(resolved).size === 0) {
        throw new MissingAssetError({
          assetId: clip.elementId,
          assetType: 'sfx',
          expectedPath: resolved,
          sceneOrTrack: `SFX track "${clip.elementId}"`,
          reason: !fs.existsSync(resolved) ? 'SFX sound asset not found' : 'SFX sound asset is 0 bytes',
        });
      }
    }
  }

  /**
   * Main rendering execution entry point.
   */
  async executeRender(request: RenderRequest): Promise<RenderResult> {
    const startTime = Date.now();

    // 1. Verify Environment
    const env = await this.checkEnvironment();
    if (!env.ffmpegAvailable) {
      throw new FfmpegUnavailableError();
    }
    if (!env.ffprobeAvailable) {
      throw new FfprobeUnavailableError();
    }

    // 2. Resolve Timeline
    let timeline: TimelineArtifact;
    let timelineInputDesc = '';

    if (request.timeline) {
      timeline = request.timeline;
      timelineInputDesc = 'memory_object';
    } else if (request.timelineArtifactPath) {
      const resolvedTimelinePath = this.resolveAssetPath(request.timelineArtifactPath, request.jobId);
      if (!fs.existsSync(resolvedTimelinePath)) {
        throw new Error(`Timeline artifact file not found at "${resolvedTimelinePath}"`);
      }
      const raw = fs.readFileSync(resolvedTimelinePath, 'utf8');
      timeline = JSON.parse(raw);
      timelineInputDesc = resolvedTimelinePath;
    } else {
      // Look for timeline in default job directory
      const defaultPath = path.resolve(this.baseDirectory, 'outputs', 'jobs', request.jobId, 'timeline.json');
      if (fs.existsSync(defaultPath)) {
        const raw = fs.readFileSync(defaultPath, 'utf8');
        timeline = JSON.parse(raw);
        timelineInputDesc = defaultPath;
      } else {
        throw new InvalidTimelineError([
          `No timeline artifact provided and none found at default path: "${defaultPath}"`,
        ]);
      }
    }

    const jobId = request.jobId || timeline.jobId || `job_${Date.now()}`;

    // 3. Resolve Render Profile
    let profile: RenderProfile;
    if (request.profile) {
      profile = request.profile;
    } else if (timeline.format === 'short' || timeline.aspectRatio === '9:16') {
      profile = { ...SHORT_FORM_PROFILE };
    } else {
      profile = { ...LONG_FORM_PROFILE };
    }

    // 4. Pre-flight Asset Verification
    this.preflightValidateAssets(timeline, jobId);

    // 5. Determine Destination Output File Path
    const jobOutputDir = path.resolve(this.baseDirectory, 'outputs', 'jobs', jobId);
    if (!fs.existsSync(jobOutputDir)) {
      fs.mkdirSync(jobOutputDir, { recursive: true });
    }

    const finalOutputPath = request.outputFilePath
      ? path.resolve(request.outputFilePath)
      : path.join(jobOutputDir, 'rendered.mp4');

    // 6. Assemble Inputs and Filter Graph
    const filterGraph = FilterGraphAssembler.assemble(
      timeline,
      profile,
      (rel) => this.resolveAssetPath(rel, jobId)
    );

    // 7. Assemble Complete FFmpeg Command
    const ffmpegArgs: string[] = [
      '-y', // Overwrite temp if needed
      ...filterGraph.ffmpegInputArgs,
      '-filter_complex', filterGraph.filterComplexScript,
      '-map', filterGraph.videoOutputMap,
      '-map', filterGraph.audioOutputMap,
      '-c:v', profile.videoCodec,
      '-preset', profile.preset,
      '-crf', String(profile.crf),
      '-pix_fmt', profile.pixelFormat,
      '-r', String(profile.frameRate),
      '-c:a', profile.audioCodec,
      '-b:a', `${profile.audioBitrateKbps}k`,
      '-ar', '48000',
      '-movflags', '+faststart',
      '-t', filterGraph.durationSeconds.toFixed(3),
      finalOutputPath,
    ];

    // 8. Execute FFmpeg Rendering Subprocess
    const runResult = await this.ffmpeg.run(ffmpegArgs, finalOutputPath, {
      expectedDurationSeconds: filterGraph.durationSeconds,
      cwd: process.cwd(),
    });

    const renderTime = (Date.now() - startTime) / 1000;

    // 9. Run Rigorous Output Validation with FFprobe
    const validation = await this.validator.validate(finalOutputPath, {
      jobId,
      expectedProfile: profile,
      expectedDurationSeconds: filterGraph.durationSeconds,
    });

    // 10. Write Artifacts: validation.json and render.json
    const validationArtifactPath = path.join(jobOutputDir, 'validation.json');
    fs.writeFileSync(validationArtifactPath, JSON.stringify(validation, null, 2), 'utf8');

    const renderArtifact: RenderArtifact = {
      jobId,
      createdAt: new Date().toISOString(),
      timelineInput: timelineInputDesc,
      renderProfile: profile,
      outputPath: finalOutputPath,
      renderStatus: validation.status === 'passed' ? 'passed' : 'failed',
      actualDuration: validation.output.duration,
      encodingInformation: {
        videoCodec: validation.output.videoCodec || profile.videoCodec,
        audioCodec: validation.output.audioCodec || profile.audioCodec,
        width: validation.output.width,
        height: validation.output.height,
        fps: validation.output.fps,
        crf: profile.crf,
        preset: profile.preset,
        bitrateKbps: profile.videoBitrateKbps,
        renderTimeSeconds: renderTime,
      },
      validationResult: validation,
      warnings: validation.warnings,
      errors: validation.errors,
    };

    const renderArtifactPath = path.join(jobOutputDir, 'render.json');
    fs.writeFileSync(renderArtifactPath, JSON.stringify(renderArtifact, null, 2), 'utf8');

    // 11. Return Structured Render Result
    return {
      jobId,
      status: validation.status === 'passed' ? 'passed' : 'failed',
      inputTimeline: request.timelineArtifactPath || timeline,
      outputPath: finalOutputPath,
      outputFormat: profile.format,
      duration: validation.output.duration,
      width: validation.output.width,
      height: validation.output.height,
      fps: validation.output.fps,
      videoCodec: validation.output.videoCodec || profile.videoCodec,
      audioCodec: validation.output.audioCodec || profile.audioCodec,
      fileSize: validation.output.fileSizeBytes || 0,
      renderTime,
      warnings: validation.warnings,
      errors: validation.errors,
      validation,

      // Backward compatibility fields
      outputFilePath: finalOutputPath,
      actualDurationSeconds: validation.output.duration,
      fileSizeBytes: validation.output.fileSizeBytes || 0,
      resolution: { width: validation.output.width, height: validation.output.height },
      encodingTimeSeconds: renderTime,
      ffmpegLogSummary: `FFmpeg completed in ${renderTime.toFixed(2)}s with status ${validation.status}.`,
    };
  }

  /**
   * Standalone output validator for already rendered media.
   */
  async validateOutput(
    videoFilePath: string,
    expectedProfile?: RenderProfile,
    jobId?: string,
    timelineDurationSeconds?: number
  ): Promise<RenderValidationResult> {
    return this.validator.validate(videoFilePath, {
      expectedProfile,
      jobId,
      expectedDurationSeconds: timelineDurationSeconds,
    });
  }
}
