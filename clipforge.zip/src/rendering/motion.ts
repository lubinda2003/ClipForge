/**
 * ClipForge Motion & Ken Burns Transform Generator
 * Generates deterministic FFmpeg filter strings for pan and zoom dynamics.
 */

import { MotionEffect } from '../contracts/timeline.ts';

export interface MotionFilterOptions {
  effect: MotionEffect | string;
  width: number;
  height: number;
  durationSeconds: number;
  fps?: number;
}

export class MotionTransformBuilder {
  /**
   * Generates a series of FFmpeg video filters applying the requested motion transform.
   */
  static buildFilter(options: MotionFilterOptions): string {
    const { effect, width, height, durationSeconds } = options;
    const dur = Math.max(0.1, durationSeconds);

    switch (effect) {
      case 'ken_burns_zoom_in': {
        // Smoothly zoom in from 100% to 108% centered
        return [
          `scale=eval=frame:w='ceil(${width}*(1.0 + 0.08*t/${dur})/2)*2':h='ceil(${height}*(1.0 + 0.08*t/${dur})/2)*2'`,
          `crop=${width}:${height}:(in_w-${width})/2:(in_h-${height})/2`,
        ].join(',');
      }

      case 'ken_burns_zoom_out': {
        // Smoothly zoom out from 108% to 100% centered
        return [
          `scale=eval=frame:w='ceil(${width}*(1.08 - 0.08*t/${dur})/2)*2':h='ceil(${height}*(1.08 - 0.08*t/${dur})/2)*2'`,
          `crop=${width}:${height}:(in_w-${width})/2:(in_h-${height})/2`,
        ].join(',');
      }

      case 'slow_pan_left': {
        // Scale to 110% width, camera moves left (view moves from right offset to left offset)
        const scaledW = Math.ceil((width * 1.10) / 2) * 2;
        const maxOffset = scaledW - width;
        return [
          `scale=${scaledW}:${height}:force_original_aspect_ratio=increase`,
          `crop=${width}:${height}:'${maxOffset}*(1 - t/${dur})':(in_h-${height})/2`,
        ].join(',');
      }

      case 'slow_pan_right': {
        // Scale to 110% width, camera moves right (view moves from left offset to right offset)
        const scaledW = Math.ceil((width * 1.10) / 2) * 2;
        const maxOffset = scaledW - width;
        return [
          `scale=${scaledW}:${height}:force_original_aspect_ratio=increase`,
          `crop=${width}:${height}:'${maxOffset}*(t/${dur})':(in_h-${height})/2`,
        ].join(',');
      }

      case 'pan_up': {
        // Scale to 110% height, view pans from bottom to top
        const scaledH = Math.ceil((height * 1.10) / 2) * 2;
        const maxOffset = scaledH - height;
        return [
          `scale=${width}:${scaledH}:force_original_aspect_ratio=increase`,
          `crop=${width}:${height}:(in_w-${width})/2:'${maxOffset}*(1 - t/${dur})'`,
        ].join(',');
      }

      case 'pan_down': {
        // Scale to 110% height, view pans from top to bottom
        const scaledH = Math.ceil((height * 1.10) / 2) * 2;
        const maxOffset = scaledH - height;
        return [
          `scale=${width}:${scaledH}:force_original_aspect_ratio=increase`,
          `crop=${width}:${height}:(in_w-${width})/2:'${maxOffset}*(t/${dur})'`,
        ].join(',');
      }

      case 'none':
      case 'static':
      default: {
        // Exact center crop with no panning
        return `crop=${width}:${height}:(in_w-${width})/2:(in_h-${height})/2`;
      }
    }
  }
}
