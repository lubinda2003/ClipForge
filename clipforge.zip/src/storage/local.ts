/**
 * ClipForge Local Storage Provider
 * Implements IStorageProvider for local filesystem storage, offline dev, test environments, and caching.
 */

import fs from 'node:fs';
import path from 'node:path';
import { IStorageProvider, StorageBucketType, StorageObjectMetadata } from './interface.ts';

export interface LocalStorageConfig {
  baseDirectory: string;
}

export class LocalStorageProvider implements IStorageProvider {
  readonly providerName = 'local_filesystem';
  readonly baseDirectory: string;

  constructor(baseDirectory: string = './.cache/clipforge') {
    this.baseDirectory = path.resolve(baseDirectory);
    this.ensureDirectory(this.baseDirectory);
  }

  private resolvePath(bucket: StorageBucketType, key: string): string {
    // Sanitize key to prevent path traversal
    const sanitizedKey = key.replace(/\.\./g, '').replace(/^\/+/, '');
    return path.join(this.baseDirectory, bucket, sanitizedKey);
  }

  private ensureDirectory(dirPath: string): void {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
  }

  async uploadFile(
    bucket: StorageBucketType,
    key: string,
    localFilePath: string,
    _options?: { contentType?: string; metadata?: Record<string, string> }
  ): Promise<{ key: string; publicUrl?: string; bytesUploaded: number }> {
    const destPath = this.resolvePath(bucket, key);
    this.ensureDirectory(path.dirname(destPath));

    fs.copyFileSync(localFilePath, destPath);
    const stats = fs.statSync(destPath);

    return {
      key,
      publicUrl: `file://${destPath}`,
      bytesUploaded: stats.size,
    };
  }

  async downloadFile(
    bucket: StorageBucketType,
    key: string,
    destinationLocalPath: string
  ): Promise<{ localPath: string; bytesDownloaded: number }> {
    const srcPath = this.resolvePath(bucket, key);
    if (!fs.existsSync(srcPath)) {
      throw new Error(`File not found in storage: [${bucket}] ${key}`);
    }

    this.ensureDirectory(path.dirname(destinationLocalPath));
    fs.copyFileSync(srcPath, destinationLocalPath);
    const stats = fs.statSync(destinationLocalPath);

    return {
      localPath: destinationLocalPath,
      bytesDownloaded: stats.size,
    };
  }

  async exists(bucket: StorageBucketType, key: string): Promise<boolean> {
    const filePath = this.resolvePath(bucket, key);
    return fs.existsSync(filePath);
  }

  async getMetadata(bucket: StorageBucketType, key: string): Promise<StorageObjectMetadata | null> {
    const filePath = this.resolvePath(bucket, key);
    if (!fs.existsSync(filePath)) {
      return null;
    }

    const stats = fs.statSync(filePath);
    return {
      key,
      sizeBytes: stats.size,
      lastModified: stats.mtime,
    };
  }

  async listObjects(
    bucket: StorageBucketType,
    prefix?: string,
    maxKeys?: number
  ): Promise<StorageObjectMetadata[]> {
    const bucketDir = path.join(this.baseDirectory, bucket);
    if (!fs.existsSync(bucketDir)) {
      return [];
    }

    const results: StorageObjectMetadata[] = [];
    const scanDir = (dir: string) => {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          scanDir(fullPath);
        } else if (entry.isFile()) {
          const relativeKey = path.relative(bucketDir, fullPath).replace(/\\/g, '/');
          if (!prefix || relativeKey.startsWith(prefix)) {
            const stats = fs.statSync(fullPath);
            results.push({
              key: relativeKey,
              sizeBytes: stats.size,
              lastModified: stats.mtime,
            });
          }
        }
      }
    };

    scanDir(bucketDir);

    if (maxKeys && maxKeys > 0) {
      return results.slice(0, maxKeys);
    }
    return results;
  }

  async deleteObject(bucket: StorageBucketType, key: string): Promise<void> {
    const filePath = this.resolvePath(bucket, key);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  }

  // Direct JSON write / read helpers for pipeline artifacts and cache records
  async writeJson(bucket: StorageBucketType, key: string, data: unknown): Promise<void> {
    const filePath = this.resolvePath(bucket, key);
    this.ensureDirectory(path.dirname(filePath));
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
  }

  async readJson<T>(bucket: StorageBucketType, key: string): Promise<T | null> {
    const filePath = this.resolvePath(bucket, key);
    if (!fs.existsSync(filePath)) {
      return null;
    }
    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(content) as T;
    } catch {
      return null;
    }
  }
}
