/**
 * ClipForge Storage Abstraction Layer
 * Supports Local Filesystem (for offline dev/testing/CI) and Cloudflare R2 / S3-compatible object storage.
 */

import { AudioAssetMetadata } from '../contracts/assets.ts';

export type StorageBucketType = 'inputs' | 'assets' | 'outputs';

export interface StorageObjectMetadata {
  key: string;
  sizeBytes: number;
  lastModified: Date;
  etag?: string;
  contentType?: string;
  customMetadata?: Record<string, string>;
}

export interface IStorageProvider {
  readonly providerName: string;

  /**
   * Uploads a local file to the targeted storage bucket and key.
   */
  uploadFile(
    bucket: StorageBucketType,
    key: string,
    localFilePath: string,
    options?: { contentType?: string; metadata?: Record<string, string> }
  ): Promise<{ key: string; publicUrl?: string; bytesUploaded: number }>;

  /**
   * Downloads an object to a destination local file path.
   */
  downloadFile(
    bucket: StorageBucketType,
    key: string,
    destinationLocalPath: string
  ): Promise<{ localPath: string; bytesDownloaded: number }>;

  /**
   * Checks if an object exists in storage.
   */
  exists(bucket: StorageBucketType, key: string): Promise<boolean>;

  /**
   * Retrieves object metadata without downloading full payload.
   */
  getMetadata(bucket: StorageBucketType, key: string): Promise<StorageObjectMetadata | null>;

  /**
   * Lists objects with a given prefix in a bucket.
   */
  listObjects(
    bucket: StorageBucketType,
    prefix?: string,
    maxKeys?: number
  ): Promise<StorageObjectMetadata[]>;

  /**
   * Deletes an object.
   */
  deleteObject(bucket: StorageBucketType, key: string): Promise<void>;
}

/**
 * Interface for querying the curated R2 asset catalog without scanning all binary files
 */
export interface IAssetCatalogService {
  findMusic(criteria: {
    category?: string;
    mood?: string;
    minEnergy?: 'low' | 'medium' | 'high';
    minDurationSeconds?: number;
    commercialUseOnly?: boolean;
  }): Promise<AudioAssetMetadata[]>;

  findSfx(criteria: {
    category?: string;
    minEnergy?: 'low' | 'medium' | 'high';
    commercialUseOnly?: boolean;
  }): Promise<AudioAssetMetadata[]>;

  getAssetMetadata(assetId: string): Promise<AudioAssetMetadata | null>;

  downloadAssetToCache(asset: AudioAssetMetadata, cacheDir: string): Promise<string>;
}
