/**
 * ClipForge Cache Layer
 * Provides deterministic hashing, TTL management, and caching over IStorageProvider.
 */

import crypto from 'node:crypto';
import { IStorageProvider } from './interface.ts';
import { LocalStorageProvider } from './local.ts';

export interface CacheEntry<T> {
  key: string;
  provider: string;
  timestamp: string;
  expiresAt: string;
  payload: T;
}

export class CacheManager {
  private readonly storage: IStorageProvider;
  private readonly defaultTtlSeconds: number;

  constructor(storage: IStorageProvider, defaultTtlSeconds: number = 86400) {
    this.storage = storage;
    this.defaultTtlSeconds = defaultTtlSeconds;
  }

  /**
   * Generates a deterministic cache key from provider and request parameters.
   */
  generateKey(provider: string, params: Record<string, unknown> | string): string {
    const serialized = typeof params === 'string' ? params : JSON.stringify(params, Object.keys(params).sort());
    const hash = crypto.createHash('sha256').update(serialized).digest('hex').substring(0, 32);
    return `cache/${provider}/${hash}.json`;
  }

  /**
   * Look up an entry from the cache. Returns null if expired or missing.
   */
  async get<T>(key: string): Promise<T | null> {
    try {
      if (this.storage instanceof LocalStorageProvider) {
        const entry = await this.storage.readJson<CacheEntry<T>>('inputs', key);
        if (!entry) return null;

        const isExpired = new Date(entry.expiresAt).getTime() < Date.now();
        if (isExpired) {
          await this.storage.deleteObject('inputs', key);
          return null;
        }

        return entry.payload;
      }
      return null;
    } catch {
      return null;
    }
  }

  /**
   * Stores an entry in the cache.
   */
  async set<T>(provider: string, key: string, payload: T, ttlSeconds?: number): Promise<void> {
    const ttl = ttlSeconds ?? this.defaultTtlSeconds;
    const now = new Date();
    const expiresAt = new Date(now.getTime() + ttl * 1000).toISOString();

    const entry: CacheEntry<T> = {
      key,
      provider,
      timestamp: now.toISOString(),
      expiresAt,
      payload,
    };

    if (this.storage instanceof LocalStorageProvider) {
      await this.storage.writeJson('inputs', key, entry);
    }
  }
}
