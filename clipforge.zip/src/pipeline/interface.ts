/**
 * ClipForge Pipeline Stage & Runner Interfaces
 * Defines modular stage execution contracts, step contexts, and deterministic artifact recording.
 */

import { ClipForgeConfig } from '../config/index.ts';
import { IStorageProvider } from '../storage/interface.ts';
import {
  PipelineStageName,
  VideoProductionJob,
  StageExecutionRecord,
} from '../contracts/pipeline.ts';

export interface IStageContext {
  job: VideoProductionJob;
  config: ClipForgeConfig;
  storage: IStorageProvider;
  workingDir: string;
  cacheDir: string;
  log: (level: 'info' | 'warn' | 'error' | 'debug', message: string, meta?: Record<string, unknown>) => void;
}

export interface IStageResult<TArtifact = unknown> {
  success: boolean;
  artifactName: string; // e.g., 'research.json', 'script.json'
  artifactData: TArtifact;
  executionTimeMs: number;
  warnings?: string[];
  error?: {
    code: string;
    message: string;
    stack?: string;
    retryable: boolean;
  };
}

export interface IPipelineStage<TInput = unknown, TOutput = unknown> {
  readonly name: PipelineStageName;
  readonly artifactFileName: string;

  /**
   * Execute this isolated stage with validated inputs and context.
   */
  execute(input: TInput, context: IStageContext): Promise<IStageResult<TOutput>>;

  /**
   * Verify whether prerequisites (previous stage artifacts) are satisfied.
   */
  canExecute(job: VideoProductionJob, context: IStageContext): Promise<boolean>;
}

export interface IPipelineRunner {
  createJob(topic: string, format: 'short' | 'long'): Promise<VideoProductionJob>;
  runJob(jobId: string, options?: { resumeFromStage?: PipelineStageName }): Promise<VideoProductionJob>;
  getJobStatus(jobId: string): Promise<VideoProductionJob | null>;
  getStageRecord(jobId: string, stage: PipelineStageName): Promise<StageExecutionRecord | null>;
}
