/**
 * ClipForge Timeline Validator
 * Validates timeline schema, track continuity, media references, safe-zone boundaries, and audio ducking.
 */

import { TimelineArtifact } from '../contracts/timeline.ts';

export interface TimelineValidationIssue {
  track?: string;
  elementId?: string;
  field: string;
  message: string;
  severity: 'error' | 'warning';
}

export interface TimelineValidationResult {
  valid: boolean;
  issues: TimelineValidationIssue[];
}

export class TimelineValidator {
  /**
   * Validates a TimelineArtifact.
   */
  public static validate(timeline: TimelineArtifact): TimelineValidationResult {
    const issues: TimelineValidationIssue[] = [];

    // 1. Format & Aspect Ratio
    if (timeline.format !== 'short' && timeline.format !== 'long') {
      issues.push({
        field: 'format',
        message: `Invalid format: ${timeline.format}. Expected 'short' or 'long'.`,
        severity: 'error',
      });
    }

    const expectedAspectRatio = timeline.format === 'short' ? '9:16' : '16:9';
    if (timeline.aspectRatio !== expectedAspectRatio) {
      issues.push({
        field: 'aspectRatio',
        message: `Aspect ratio '${timeline.aspectRatio}' does not match format '${timeline.format}'. Expected '${expectedAspectRatio}'.`,
        severity: 'error',
      });
    }

    // 2. Duration
    if (typeof timeline.totalDurationSeconds !== 'number' || isNaN(timeline.totalDurationSeconds) || timeline.totalDurationSeconds <= 0) {
      issues.push({
        field: 'totalDurationSeconds',
        message: `totalDurationSeconds must be a positive number. Got: ${timeline.totalDurationSeconds}`,
        severity: 'error',
      });
    }

    if (!timeline.tracks) {
      issues.push({
        field: 'tracks',
        message: 'Tracks property is missing from timeline.',
        severity: 'error',
      });
      return { valid: false, issues };
    }

    // 3. Video Track Validation
    const videoClips = timeline.tracks.video || [];
    if (videoClips.length === 0) {
      issues.push({
        track: 'video',
        field: 'tracks.video',
        message: 'Video track is empty. At least one video clip is required.',
        severity: 'error',
      });
    }

    let lastVideoEnd = 0;
    for (let i = 0; i < videoClips.length; i++) {
      const clip = videoClips[i];
      if (!clip.elementId) {
        issues.push({ track: 'video', field: 'elementId', message: `Video clip at index ${i} missing elementId.`, severity: 'error' });
      }
      if (!clip.sourceFilePath || clip.sourceFilePath.trim() === '') {
        issues.push({ track: 'video', elementId: clip.elementId, field: 'sourceFilePath', message: 'Missing sourceFilePath.', severity: 'error' });
      }
      if (clip.startTimelineSeconds < 0) {
        issues.push({ track: 'video', elementId: clip.elementId, field: 'startTimelineSeconds', message: 'Start time cannot be negative.', severity: 'error' });
      }
      if (clip.durationSeconds <= 0) {
        issues.push({ track: 'video', elementId: clip.elementId, field: 'durationSeconds', message: 'Duration must be positive.', severity: 'error' });
      }

      // Check monotonicity and continuity
      if (i > 0 && Math.abs(clip.startTimelineSeconds - lastVideoEnd) > 0.05) {
        issues.push({
          track: 'video',
          elementId: clip.elementId,
          field: 'startTimelineSeconds',
          message: `Discontinuity in video track: clip starts at ${clip.startTimelineSeconds}s but previous ended at ${lastVideoEnd}s.`,
          severity: 'error',
        });
      }

      // Validate transitions
      if (clip.transitionIn && clip.transitionIn.durationSeconds > clip.durationSeconds) {
        issues.push({
          track: 'video',
          elementId: clip.elementId,
          field: 'transitionIn.durationSeconds',
          message: `transitionIn duration (${clip.transitionIn.durationSeconds}s) exceeds clip duration (${clip.durationSeconds}s).`,
          severity: 'error',
        });
      }

      lastVideoEnd = Number((clip.startTimelineSeconds + clip.durationSeconds).toFixed(3));
    }

    // Check video track covers total timeline duration
    if (videoClips.length > 0 && Math.abs(lastVideoEnd - timeline.totalDurationSeconds) > 0.5) {
      issues.push({
        track: 'video',
        field: 'totalCoverage',
        message: `Video coverage (${lastVideoEnd}s) does not match total timeline duration (${timeline.totalDurationSeconds}s).`,
        severity: 'error',
      });
    }

    // 4. Narration Track Validation
    const narrationClips = timeline.tracks.narration || [];
    let lastNarrationEnd = 0;
    for (let i = 0; i < narrationClips.length; i++) {
      const clip = narrationClips[i];
      if (!clip.audioFilePath || clip.audioFilePath.trim() === '') {
        issues.push({ track: 'narration', elementId: clip.elementId, field: 'audioFilePath', message: 'Missing narration audioFilePath.', severity: 'error' });
      }
      if (clip.startTimelineSeconds < 0) {
        issues.push({ track: 'narration', elementId: clip.elementId, field: 'startTimelineSeconds', message: 'Narration start cannot be negative.', severity: 'error' });
      }
      if (clip.durationSeconds <= 0) {
        issues.push({ track: 'narration', elementId: clip.elementId, field: 'durationSeconds', message: 'Narration duration must be positive.', severity: 'error' });
      }
      lastNarrationEnd = Number((clip.startTimelineSeconds + clip.durationSeconds).toFixed(3));
    }

    // 5. Music Track & Ducking Validation
    const musicClips = timeline.tracks.music || [];
    for (const clip of musicClips) {
      if (clip.volume < 0 || clip.volume > 1.0) {
        issues.push({ track: 'music', elementId: clip.elementId, field: 'volume', message: `Invalid volume ${clip.volume}. Expected 0.0 to 1.0.`, severity: 'error' });
      }
      if (clip.duckingEnvelope) {
        let prevTime = -1;
        for (const pt of clip.duckingEnvelope) {
          if (pt.timestampSeconds < 0 || pt.timestampSeconds > timeline.totalDurationSeconds + 0.1) {
            issues.push({
              track: 'music',
              elementId: clip.elementId,
              field: 'duckingEnvelope.timestampSeconds',
              message: `Ducking envelope timestamp ${pt.timestampSeconds}s is out of bounds [0, ${timeline.totalDurationSeconds}].`,
              severity: 'error',
            });
          }
          if (pt.timestampSeconds < prevTime) {
            issues.push({
              track: 'music',
              elementId: clip.elementId,
              field: 'duckingEnvelope',
              message: `Ducking envelope timestamps are not monotonically increasing.`,
              severity: 'error',
            });
          }
          if (pt.volumeMultiplier < 0 || pt.volumeMultiplier > 1.0) {
            issues.push({
              track: 'music',
              elementId: clip.elementId,
              field: 'duckingEnvelope.volumeMultiplier',
              message: `Invalid ducking volume multiplier: ${pt.volumeMultiplier}. Expected 0.0 to 1.0.`,
              severity: 'error',
            });
          }
          prevTime = pt.timestampSeconds;
        }
      }
    }

    // 6. SFX Track Validation
    const sfxClips = timeline.tracks.sfx || [];
    for (const clip of sfxClips) {
      if (clip.startTimelineSeconds < 0) {
        issues.push({ track: 'sfx', elementId: clip.elementId, field: 'startTimelineSeconds', message: 'SFX start cannot be negative.', severity: 'error' });
      }
      if (clip.durationSeconds <= 0) {
        issues.push({ track: 'sfx', elementId: clip.elementId, field: 'durationSeconds', message: 'SFX duration must be positive.', severity: 'error' });
      }
    }

    // 7. Text Overlays & Safe Zone Validation
    const textOverlays = timeline.tracks.textOverlays || [];
    for (const overlay of textOverlays) {
      if (!overlay.primaryText || overlay.primaryText.trim() === '') {
        issues.push({ track: 'textOverlays', elementId: overlay.elementId, field: 'primaryText', message: 'Text overlay primaryText cannot be empty.', severity: 'error' });
      }
      if (overlay.startTimelineSeconds < 0) {
        issues.push({ track: 'textOverlays', elementId: overlay.elementId, field: 'startTimelineSeconds', message: 'Text overlay start cannot be negative.', severity: 'error' });
      }
      if (overlay.durationSeconds <= 0) {
        issues.push({ track: 'textOverlays', elementId: overlay.elementId, field: 'durationSeconds', message: 'Text overlay duration must be positive.', severity: 'error' });
      }
      const margins = overlay.positioning?.safeZoneMargins;
      if (
        !margins ||
        margins.topPercent < 0 ||
        margins.bottomPercent < 0 ||
        margins.leftPercent < 0 ||
        margins.rightPercent < 0 ||
        margins.topPercent + margins.bottomPercent >= 100 ||
        margins.leftPercent + margins.rightPercent >= 100
      ) {
        issues.push({
          track: 'textOverlays',
          elementId: overlay.elementId,
          field: 'safeZoneMargins',
          message: 'Invalid safe zone margins in text overlay.',
          severity: 'error',
        });
      }
    }

    return {
      valid: !issues.some(i => i.severity === 'error'),
      issues,
    };
  }
}
