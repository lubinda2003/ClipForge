/**
 * ClipForge Safe Zone Planner
 * Calculates UI-aware boundary margins for Short-Form (9:16) and Long-Form (16:9) formats.
 */

import { SafeZone, VideoFormat } from '../contracts/common.ts';
import { SHORT_FORM_PROFILE, LONG_FORM_PROFILE } from '../contracts/rendering.ts';
import { TextOverlayElement } from '../contracts/timeline.ts';

export class SafeZonePlanner {
  /**
   * Retrieves the platform-safe margin percentages for a given format.
   */
  public static getSafeZone(format: VideoFormat): SafeZone {
    if (format === 'short') {
      return { ...SHORT_FORM_PROFILE.safeZone };
    }
    return { ...LONG_FORM_PROFILE.safeZone };
  }

  /**
   * Derives optimal alignment and margins for text overlay variants within safe zones.
   */
  public static getPositioningForVariant(
    variant: TextOverlayElement['styleVariant'],
    format: VideoFormat
  ): TextOverlayElement['positioning'] {
    const safeZone = this.getSafeZone(format);

    switch (variant) {
      case 'hero_hook':
        // Short-form: centered punchy hook in safe area
        // Long-form: top-center title
        return {
          horizontalAlign: 'center',
          verticalAlign: format === 'short' ? 'center' : 'top',
          safeZoneMargins: safeZone,
        };

      case 'bold_caption':
        // Captions rest in the lower-middle zone, above TikTok/Reels description
        return {
          horizontalAlign: 'center',
          verticalAlign: 'bottom',
          safeZoneMargins: safeZone,
        };

      case 'lower_third':
        // Lower third info sits bottom-left
        return {
          horizontalAlign: 'left',
          verticalAlign: 'bottom',
          safeZoneMargins: safeZone,
        };

      case 'statistic_card':
        // Statistical callouts sit dead-center for high focus
        return {
          horizontalAlign: 'center',
          verticalAlign: 'center',
          safeZoneMargins: safeZone,
        };

      case 'chapter_title':
        // Chapter titles sit at the top-left in long-form, top-center in short-form
        return {
          horizontalAlign: format === 'short' ? 'center' : 'left',
          verticalAlign: 'top',
          safeZoneMargins: safeZone,
        };

      default:
        return {
          horizontalAlign: 'center',
          verticalAlign: 'bottom',
          safeZoneMargins: safeZone,
        };
    }
  }
}
