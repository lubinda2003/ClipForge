/**
 * ClipForge Music Planner
 * Maps background music assets into timeline audio clips with volume, looping, and ducking envelopes.
 */

import { SelectedAudioAsset } from '../contracts/assets.ts';
import { VideoFormat } from '../contracts/common.ts';
import { AudioClipElement } from '../contracts/timeline.ts';
import { DuckingPlanner, SpeechInterval } from './ducking_planner.ts';

export interface MusicPlannerOptions {
  format: VideoFormat;
  totalDurationSeconds: number;
  speechIntervals: SpeechInterval[];
  duckingMultiplier?: number;
}

export class MusicPlanner {
  private duckingPlanner: DuckingPlanner;

  constructor(duckingPlanner?: DuckingPlanner) {
    this.duckingPlanner = duckingPlanner || new DuckingPlanner();
  }

  /**
   * Plans the music track clips for the timeline.
   */
  public planMusicClips(
    musicTrack: SelectedAudioAsset | undefined,
    options: MusicPlannerOptions
  ): AudioClipElement[] {
    if (!musicTrack) {
      return [];
    }

    const { format, totalDurationSeconds, speechIntervals } = options;
    const duckingEnvelope = this.duckingPlanner.generateMusicDuckingEnvelope(
      speechIntervals,
      totalDurationSeconds
    );

    const baseVolume = musicTrack.volumeLevel || (format === 'short' ? 0.18 : 0.15);
    const fadeIn = musicTrack.fadeInSeconds ?? 0.5;
    const fadeOut = musicTrack.fadeOutSeconds ?? Math.min(2.0, totalDurationSeconds * 0.08);

    const assetDuration = musicTrack.asset.durationSeconds;
    const isLoopable = musicTrack.asset.loopable ?? true;

    const clips: AudioClipElement[] = [];

    if (assetDuration >= totalDurationSeconds || !isLoopable) {
      // Single clip spanning required duration
      clips.push({
        elementId: `clip_mus_${musicTrack.asset.assetId}_01`,
        type: 'music',
        audioFilePath: musicTrack.localPath,
        startTimelineSeconds: 0,
        durationSeconds: totalDurationSeconds,
        volume: baseVolume,
        duckingEnvelope,
        fadeInSeconds: fadeIn,
        fadeOutSeconds: fadeOut,
        loop: assetDuration < totalDurationSeconds,
      });
    } else {
      // Track is shorter than video duration and is loopable
      // We can emit a single looping audio clip element with total duration and loop=true
      clips.push({
        elementId: `clip_mus_${musicTrack.asset.assetId}_loop`,
        type: 'music',
        audioFilePath: musicTrack.localPath,
        startTimelineSeconds: 0,
        durationSeconds: totalDurationSeconds,
        volume: baseVolume,
        duckingEnvelope,
        fadeInSeconds: fadeIn,
        fadeOutSeconds: fadeOut,
        loop: true,
      });
    }

    return clips;
  }
}
