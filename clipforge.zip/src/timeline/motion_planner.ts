/**
 * ClipForge Motion Planner
 * Computes subtle, non-disruptive camera motion instructions (Ken Burns zooms and pans).
 */

import { MotionEffect } from '../contracts/timeline.ts';
import { SceneVisualRequirement } from '../contracts/scenes.ts';

export class MotionPlanner {
  /**
   * Selects a motion effect for a video clip element.
   */
  public planMotion(
    scene: SceneVisualRequirement,
    sceneIndex: number,
    totalScenes: number
  ): MotionEffect {
    // Opening Hook: punchy subtle push-in
    if (sceneIndex === 0) {
      return 'ken_burns_zoom_in';
    }

    // Final resolution: slow push-in or gentle zoom-out
    if (sceneIndex === totalScenes - 1) {
      return 'ken_burns_zoom_out';
    }

    const concept = (scene.visualConcept || '').toLowerCase();
    const cameraHint = scene.cameraMovementHint;

    if (cameraHint === 'slow_pan') {
      return sceneIndex % 2 === 0 ? 'slow_pan_right' : 'slow_pan_left';
    }

    if (cameraHint === 'slow_zoom') {
      return sceneIndex % 2 === 0 ? 'ken_burns_zoom_in' : 'ken_burns_zoom_out';
    }

    if (cameraHint === 'static') {
      return 'none';
    }

    // Concept-based heuristics
    if (concept.includes('landscape') || concept.includes('city') || concept.includes('horizon') || concept.includes('crowd')) {
      return sceneIndex % 2 === 0 ? 'slow_pan_right' : 'slow_pan_left';
    }

    if (concept.includes('microscope') || concept.includes('closeup') || concept.includes('cell') || concept.includes('chip') || concept.includes('dna')) {
      return 'ken_burns_zoom_in';
    }

    // Controlled alternation to prevent fatigue
    const effects: MotionEffect[] = [
      'none',
      'ken_burns_zoom_in',
      'none',
      'ken_burns_zoom_out',
      'slow_pan_right',
    ];

    return effects[sceneIndex % effects.length];
  }
}
