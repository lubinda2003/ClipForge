/**
 * ClipForge Retention Editing Planner
 * Operationalizes audience engagement strategy by placing pattern interrupts, hook markers, and audio accents.
 */

import { VideoFormat } from '../contracts/common.ts';
import { ScenesArtifact } from '../contracts/scenes.ts';
import { ScriptArtifact } from '../contracts/script.ts';
import { NarrationArtifact } from '../contracts/narration.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';

export interface RetentionAnnotation {
  timestampSeconds: number;
  event: 'hook' | 'pattern_interrupt' | 'payoff' | 'sfx_accent' | 'pacing_change';
  description: string;
}

export interface SfxLandmark {
  timestampSeconds: number;
  purpose: 'hook' | 'pattern_interrupt' | 'statistic_reveal' | 'scene_transition' | 'payoff' | 'emphasis';
  sceneId?: string;
  desiredEnergy?: 'low' | 'medium' | 'high';
}

export class RetentionEditingPlanner {
  /**
   * Identifies strategic retention events and sound effect triggers across the timeline.
   */
  public planRetentionEvents(
    scenes: ScenesArtifact,
    script: ScriptArtifact,
    narration: NarrationArtifact,
    format: VideoFormat,
    strategy?: ContentStrategyArtifact
  ): {
    annotations: RetentionAnnotation[];
    sfxLandmarks: SfxLandmark[];
  } {
    const annotations: RetentionAnnotation[] = [];
    const sfxLandmarks: SfxLandmark[] = [];

    // 1. Opening Hook (0.0s - 0.3s)
    annotations.push({
      timestampSeconds: 0,
      event: 'hook',
      description: `Immediate visual hook: ${script.segments[0]?.visualIntentDescription || 'Attention grabber'}`,
    });
    sfxLandmarks.push({
      timestampSeconds: 0.1,
      purpose: 'hook',
      sceneId: scenes.scenes[0]?.sceneId,
      desiredEnergy: 'high',
    });

    // 2. Identify scene timings
    let currentSceneStart = 0;
    const sceneIntervals: Array<{ sceneId: string; start: number; end: number; duration: number }> = [];

    for (const sc of scenes.scenes) {
      sceneIntervals.push({
        sceneId: sc.sceneId,
        start: currentSceneStart,
        end: currentSceneStart + sc.desiredDurationSeconds,
        duration: sc.desiredDurationSeconds,
      });
      currentSceneStart += sc.desiredDurationSeconds;
    }

    // 3. Strategic landmarks from script segments
    let lastInterruptTime = 0;
    const interruptInterval = format === 'short' ? 7.0 : 18.0;

    for (let i = 0; i < scenes.scenes.length; i++) {
      const scene = scenes.scenes[i];
      const interval = sceneIntervals[i];
      if (!interval) continue;

      // Check if scene is explicitly marked as pattern interrupt or emotional shift
      const isExplicitInterrupt =
        scene.visualPurpose === 'provide_pattern_interrupt' ||
        scene.visualPurpose === 'create_emotional_shift';

      // Check if natural interval has elapsed for a pattern interrupt
      const intervalElapsed = interval.start - lastInterruptTime >= interruptInterval;

      if (isExplicitInterrupt || (intervalElapsed && i > 0 && i < scenes.scenes.length - 1)) {
        annotations.push({
          timestampSeconds: Number(interval.start.toFixed(2)),
          event: 'pattern_interrupt',
          description: `Pattern interrupt reset: ${scene.visualConcept}`,
        });
        sfxLandmarks.push({
          timestampSeconds: Number((interval.start + 0.05).toFixed(2)),
          purpose: 'pattern_interrupt',
          sceneId: scene.sceneId,
          desiredEnergy: 'high',
        });
        lastInterruptTime = interval.start;
      }

      // Detect statistics or data callouts
      if (/\b\d+(\.\d+)?%|\b\d{2,}\b|\$\d+/.test(scene.narrationExcerpt)) {
        annotations.push({
          timestampSeconds: Number((interval.start + 0.3).toFixed(2)),
          event: 'sfx_accent',
          description: `Data point emphasis: ${scene.narrationExcerpt.slice(0, 40)}...`,
        });
        sfxLandmarks.push({
          timestampSeconds: Number((interval.start + 0.25).toFixed(2)),
          purpose: 'statistic_reveal',
          sceneId: scene.sceneId,
          desiredEnergy: 'medium',
        });
      }
    }

    // 4. Payoff / Climax (Penultimate or final scene)
    const finalScene = sceneIntervals[sceneIntervals.length - 1];
    if (finalScene) {
      const payoffTimestamp = Math.max(0, finalScene.start);
      annotations.push({
        timestampSeconds: Number(payoffTimestamp.toFixed(2)),
        event: 'payoff',
        description: 'Narrative payoff / final conclusion resolution',
      });
      sfxLandmarks.push({
        timestampSeconds: Number(payoffTimestamp.toFixed(2)),
        purpose: 'payoff',
        sceneId: finalScene.sceneId,
        desiredEnergy: 'high',
      });
    }

    // Sort chronologically
    annotations.sort((a, b) => a.timestampSeconds - b.timestampSeconds);
    sfxLandmarks.sort((a, b) => a.timestampSeconds - b.timestampSeconds);

    return {
      annotations,
      sfxLandmarks,
    };
  }
}
