/**
 * ClipForge Timeline Engine
 * Orchestrates Audio Asset Selection, Multi-Track Editing Composition, Validation, and Artifact Storage.
 */

import path from 'node:path';
import { VideoFormat } from '../contracts/common.ts';
import { TimelineArtifact } from '../contracts/timeline.ts';
import { ScenesArtifact } from '../contracts/scenes.ts';
import { BrollSelectionArtifact } from '../contracts/stock.ts';
import { NarrationArtifact } from '../contracts/narration.ts';
import { ScriptArtifact } from '../contracts/script.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';
import { AssetsArtifact } from '../contracts/assets.ts';
import { IStorageProvider } from '../storage/interface.ts';
import { LocalStorageProvider } from '../storage/local.ts';

import { AudioAssetLibrary } from '../assets/library.ts';
import { RetentionEditingPlanner } from './retention_planner.ts';
import { TimelineBuilder } from './builder.ts';
import { TimelineValidator } from './validator.ts';

export interface TimelineExecutionOptions {
  jobId: string;
  format: VideoFormat;
  topic?: string;
  targetMood?: string;
  storage?: IStorageProvider;
  audioLibrary?: AudioAssetLibrary;
  requireCommercialUse?: boolean;
}

export class TimelineEngine {
  private storage: IStorageProvider;
  private audioLibrary: AudioAssetLibrary;
  private builder: TimelineBuilder;
  private retentionPlanner: RetentionEditingPlanner;

  constructor(options?: { storage?: IStorageProvider; audioLibrary?: AudioAssetLibrary }) {
    this.storage = options?.storage || new LocalStorageProvider();
    this.audioLibrary = options?.audioLibrary || new AudioAssetLibrary({ storage: this.storage });
    this.builder = new TimelineBuilder();
    this.retentionPlanner = new RetentionEditingPlanner();
  }

  /**
   * Executes audio selection and multi-track timeline composition.
   */
  public async executeTimelineComposition(
    scenes: ScenesArtifact,
    broll: BrollSelectionArtifact,
    narration: NarrationArtifact,
    script: ScriptArtifact,
    strategy?: ContentStrategyArtifact,
    options?: TimelineExecutionOptions
  ): Promise<{ timeline: TimelineArtifact; assets: AssetsArtifact }> {
    const jobId = options?.jobId || script.jobId || 'job_untitled';
    const format = options?.format || script.format || 'short';
    const totalDurationSeconds = narration.totalDurationSeconds > 0
      ? narration.totalDurationSeconds
      : scenes.totalDurationSeconds;

    // 1. Identify retention landmarks and SFX trigger opportunities
    const retentionPlan = this.retentionPlanner.planRetentionEvents(
      scenes,
      script,
      narration,
      format,
      strategy
    );

    // 2. Select curated music and SFX assets
    const assets = await this.audioLibrary.selectAssetsForProduction({
      jobId,
      format,
      totalDurationSeconds,
      topic: options?.topic || script.title,
      targetMood: options?.targetMood || strategy?.emotionalTriggers?.[0] || strategy?.targetAudience?.primaryMotivation || 'energetic',
      desiredEnergy: format === 'short' ? 'high' : 'medium',
      sfxLandmarks: retentionPlan.sfxLandmarks,
    });

    // 3. Assemble complete multi-track timeline
    const timeline = this.builder.buildTimeline({
      jobId,
      format,
      scenes,
      broll,
      narration,
      script,
      assets,
      strategy,
    });

    // 4. Validate timeline integrity
    const validation = TimelineValidator.validate(timeline);
    if (!validation.valid) {
      const errorDetails = validation.issues.map(i => `[${i.track || 'root'}] ${i.field}: ${i.message}`).join('; ');
      const err = new Error(`Timeline validation failed: ${errorDetails}`);
      (err as any).code = 'TIMELINE_VALIDATION_FAILED';
      (err as any).validationIssues = validation.issues;
      throw err;
    }

    // 5. Persist artifacts
    if ('writeJson' in (this.storage as any)) {
      const timelineStorageKey = `jobs/${jobId}/timeline.json`;
      const assetsStorageKey = `jobs/${jobId}/assets.json`;
      await (this.storage as any).writeJson('inputs', timelineStorageKey, timeline);
      await (this.storage as any).writeJson('inputs', assetsStorageKey, assets);
    }

    return { timeline, assets };
  }
}
