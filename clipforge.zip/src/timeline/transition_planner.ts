/**
 * ClipForge Transition Planner
 * Plans tasteful, context-sensitive video transitions without visual clutter.
 */

import { VideoFormat } from '../contracts/common.ts';
import { TransitionType } from '../contracts/timeline.ts';
import { SceneVisualRequirement } from '../contracts/scenes.ts';

export interface TransitionPlan {
  transitionIn?: {
    type: TransitionType;
    durationSeconds: number;
  };
  transitionOut?: {
    type: TransitionType;
    durationSeconds: number;
  };
}

export class TransitionPlanner {
  /**
   * Plans transitions for a scene within a video sequence.
   */
  public planTransition(
    sceneIndex: number,
    totalScenes: number,
    scene: SceneVisualRequirement,
    format: VideoFormat,
    isPatternInterrupt: boolean = false
  ): TransitionPlan {
    const sceneDuration = scene.desiredDurationSeconds;
    const maxTransitionDuration = Math.min(0.4, Number((sceneDuration * 0.25).toFixed(2)));

    // Opening scene
    if (sceneIndex === 0) {
      return {
        transitionIn: {
          type: 'fade' as any, // initial fade-in or cut
          durationSeconds: Math.min(0.3, maxTransitionDuration),
        },
      };
    }

    // Closing scene outro
    if (sceneIndex === totalScenes - 1) {
      return {
        transitionOut: {
          type: 'dip_to_black',
          durationSeconds: Math.min(0.5, maxTransitionDuration),
        },
      };
    }

    // Pattern interrupt visual transition
    if (isPatternInterrupt) {
      return {
        transitionIn: {
          type: format === 'short' ? 'glitch' : 'slide_left',
          durationSeconds: Math.min(0.25, maxTransitionDuration),
        },
      };
    }

    // Major emotional turn or section transition
    if (scene.visualPurpose === 'create_emotional_shift' || scene.visualPurpose === 'provide_pattern_interrupt') {
      return {
        transitionIn: {
          type: 'zoom_in',
          durationSeconds: Math.min(0.3, maxTransitionDuration),
        },
      };
    }

    if (format === 'long' && scene.visualMood === 'contemplative' && sceneIndex % 4 === 0) {
      return {
        transitionIn: {
          type: 'crossfade',
          durationSeconds: Math.min(0.4, maxTransitionDuration),
        },
      };
    }

    // Default professional editorial standard: Clean Cut
    return {
      transitionIn: {
        type: 'cut',
        durationSeconds: 0,
      },
    };
  }
}
