/**
 * ClipForge SFX Planner
 * Maps sound effect assets into timeline audio clips with contextual volume and collision handling.
 */

import { SelectedAudioAsset } from '../contracts/assets.ts';
import { AudioClipElement } from '../contracts/timeline.ts';
import { DuckingPlanner, SpeechInterval } from './ducking_planner.ts';

export class SfxPlanner {
  private duckingPlanner: DuckingPlanner;

  constructor(duckingPlanner?: DuckingPlanner) {
    this.duckingPlanner = duckingPlanner || new DuckingPlanner();
  }

  /**
   * Plans the SFX audio track clips.
   */
  public planSfxClips(
    sfxTracks: SelectedAudioAsset[],
    speechIntervals: SpeechInterval[]
  ): AudioClipElement[] {
    const clips: AudioClipElement[] = [];
    const sorted = [...sfxTracks].sort((a, b) => a.targetTimestampSeconds - b.targetTimestampSeconds);

    let lastEnd = -1;

    for (let i = 0; i < sorted.length; i++) {
      const sfx = sorted[i];
      let start = sfx.targetTimestampSeconds;

      // Avoid exact micro-collisions (stagger by at least 0.15s if identical start)
      if (Math.abs(start - lastEnd) < 0.15 && start <= lastEnd) {
        start = Number((lastEnd + 0.15).toFixed(2));
      }

      const duration = sfx.targetDurationSeconds;
      const baseVol = sfx.volumeLevel || 0.35;
      const contextualVol = this.duckingPlanner.calculateSfxVolume(start, baseVol, speechIntervals);

      clips.push({
        elementId: `clip_sfx_${sfx.asset.category}_${i + 1}`,
        type: 'sfx',
        audioFilePath: sfx.localPath,
        startTimelineSeconds: start,
        durationSeconds: duration,
        volume: contextualVol,
        fadeInSeconds: 0.02,
        fadeOutSeconds: 0.05,
      });

      lastEnd = start + duration;
    }

    return clips;
  }
}
