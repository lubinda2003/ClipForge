/**
 * ClipForge Ducking Planner
 * Computes deterministic volume ducking envelopes for background music and SFX during speech.
 */

export interface SpeechInterval {
  startSeconds: number;
  endSeconds: number;
}

export interface DuckingEnvelopePoint {
  timestampSeconds: number;
  volumeMultiplier: number;
}

export interface DuckingPlannerConfig {
  duckedMultiplier?: number; // Volume multiplier during speech (e.g. 0.12 - 0.25)
  preRampSeconds?: number;   // Time to ramp down before speech (e.g. 0.2s)
  postHoldSeconds?: number;  // Time to hold ducked volume after speech (e.g. 0.25s)
  postRampSeconds?: number;  // Time to ramp back up after hold (e.g. 0.35s)
  bridgeGapSeconds?: number; // Gaps shorter than this are bridged without un-ducking (e.g. 0.45s)
}

export class DuckingPlanner {
  private duckedMultiplier: number;
  private preRampSeconds: number;
  private postHoldSeconds: number;
  private postRampSeconds: number;
  private bridgeGapSeconds: number;

  constructor(config?: DuckingPlannerConfig) {
    this.duckedMultiplier = config?.duckedMultiplier ?? 0.12;
    this.preRampSeconds = config?.preRampSeconds ?? 0.2;
    this.postHoldSeconds = config?.postHoldSeconds ?? 0.25;
    this.postRampSeconds = config?.postRampSeconds ?? 0.35;
    this.bridgeGapSeconds = config?.bridgeGapSeconds ?? 0.45;
  }

  /**
   * Generates a mathematical ducking envelope for background music across the timeline.
   */
  public generateMusicDuckingEnvelope(
    speechIntervals: SpeechInterval[],
    totalTimelineDurationSeconds: number
  ): DuckingEnvelopePoint[] {
    if (speechIntervals.length === 0) {
      return [
        { timestampSeconds: 0, volumeMultiplier: 1.0 },
        { timestampSeconds: totalTimelineDurationSeconds, volumeMultiplier: 1.0 },
      ];
    }

    // 1. Sort and merge speech intervals
    const sorted = [...speechIntervals]
      .filter(i => i.endSeconds > i.startSeconds && i.startSeconds < totalTimelineDurationSeconds)
      .sort((a, b) => a.startSeconds - b.startSeconds);

    if (sorted.length === 0) {
      return [
        { timestampSeconds: 0, volumeMultiplier: 1.0 },
        { timestampSeconds: totalTimelineDurationSeconds, volumeMultiplier: 1.0 },
      ];
    }

    const merged: SpeechInterval[] = [];
    let current = { ...sorted[0] };

    for (let i = 1; i < sorted.length; i++) {
      const next = sorted[i];
      if (next.startSeconds <= current.endSeconds + this.bridgeGapSeconds) {
        // Bridge gap
        current.endSeconds = Math.max(current.endSeconds, next.endSeconds);
      } else {
        merged.push(current);
        current = { ...next };
      }
    }
    merged.push(current);

    // 2. Build envelope points
    const points: DuckingEnvelopePoint[] = [];

    // Initial state at t=0
    const firstSpeech = merged[0];
    if (firstSpeech.startSeconds > this.preRampSeconds) {
      points.push({ timestampSeconds: 0, volumeMultiplier: 1.0 });
    }

    for (const block of merged) {
      const rampStart = Math.max(0, block.startSeconds - this.preRampSeconds);
      const speechStart = block.startSeconds;
      const speechEnd = Math.min(totalTimelineDurationSeconds, block.endSeconds);
      const holdEnd = Math.min(totalTimelineDurationSeconds, speechEnd + this.postHoldSeconds);
      const rampEnd = Math.min(totalTimelineDurationSeconds, holdEnd + this.postRampSeconds);

      // Add ramp-down point
      if (rampStart > 0 && (points.length === 0 || points[points.length - 1].timestampSeconds < rampStart)) {
        points.push({
          timestampSeconds: Number(rampStart.toFixed(3)),
          volumeMultiplier: 1.0,
        });
      }

      // Fully ducked at speech start
      points.push({
        timestampSeconds: Number(speechStart.toFixed(3)),
        volumeMultiplier: this.duckedMultiplier,
      });

      // Maintain ducked level until speech end and hold end
      points.push({
        timestampSeconds: Number(holdEnd.toFixed(3)),
        volumeMultiplier: this.duckedMultiplier,
      });

      // Ramp back up to full volume
      if (rampEnd < totalTimelineDurationSeconds) {
        points.push({
          timestampSeconds: Number(rampEnd.toFixed(3)),
          volumeMultiplier: 1.0,
        });
      }
    }

    // Final point at total duration
    const lastPoint = points[points.length - 1];
    if (lastPoint.timestampSeconds < totalTimelineDurationSeconds) {
      points.push({
        timestampSeconds: Number(totalTimelineDurationSeconds.toFixed(3)),
        volumeMultiplier: 1.0,
      });
    }

    // Deduplicate any points with identical timestamps
    const deduplicated: DuckingEnvelopePoint[] = [];
    for (const pt of points) {
      if (deduplicated.length > 0 && Math.abs(deduplicated[deduplicated.length - 1].timestampSeconds - pt.timestampSeconds) < 0.01) {
        // Keep the lower multiplier if overlapping
        deduplicated[deduplicated.length - 1].volumeMultiplier = Math.min(
          deduplicated[deduplicated.length - 1].volumeMultiplier,
          pt.volumeMultiplier
        );
      } else {
        deduplicated.push(pt);
      }
    }

    return deduplicated;
  }

  /**
   * Adjusts SFX volume level depending on whether it coincides with narration speech.
   */
  public calculateSfxVolume(
    timestampSeconds: number,
    baseVolume: number,
    speechIntervals: SpeechInterval[]
  ): number {
    const isOverlappingSpeech = speechIntervals.some(
      interval => timestampSeconds >= interval.startSeconds && timestampSeconds <= interval.endSeconds
    );
    // If overlapping speech, slightly pull back SFX so it accentuates without masking vowels
    return isOverlappingSpeech ? Number((baseVolume * 0.85).toFixed(2)) : baseVolume;
  }
}
