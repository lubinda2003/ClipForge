/**
 * ClipForge Caption Planner
 * Generates narration-synchronized text overlays with safe zone positioning and typographic hierarchy.
 */

import { VideoFormat } from '../contracts/common.ts';
import { ScriptArtifact, ScriptSegment } from '../contracts/script.ts';
import { NarrationArtifact, NarrationSegmentResult } from '../contracts/narration.ts';
import { TextOverlayElement } from '../contracts/timeline.ts';
import { SafeZonePlanner } from './safe_zone_planner.ts';

export class CaptionPlanner {
  /**
   * Generates text overlays aligned with narration segment timings.
   */
  public planCaptions(
    script: ScriptArtifact,
    narration: NarrationArtifact,
    format: VideoFormat
  ): TextOverlayElement[] {
    const overlays: TextOverlayElement[] = [];

    // Map narration results by segmentId
    const narrationMap = new Map<string, { result: NarrationSegmentResult; startSeconds: number }>();
    let cumulativeTime = 0;

    for (const result of narration.segmentResults) {
      narrationMap.set(result.segmentId, {
        result,
        startSeconds: Number(cumulativeTime.toFixed(3)),
      });
      cumulativeTime += result.actualDurationSeconds;
    }

    for (let i = 0; i < script.segments.length; i++) {
      const segment: ScriptSegment = script.segments[i];
      const narrationTiming = narrationMap.get(segment.segmentId);

      // Skip segments with no corresponding narration audio
      if (!narrationTiming) {
        continue;
      }

      const startSeconds = narrationTiming.startSeconds;
      const durationSeconds = narrationTiming.result.actualDurationSeconds;

      // Determine appropriate style variant based on segment role and content
      let variant: TextOverlayElement['styleVariant'] = 'bold_caption';
      let inAnim: TextOverlayElement['inAnimation'] = 'fade';
      let outAnim: TextOverlayElement['outAnimation'] = 'fade';

      if (i === 0) {
        // Hook / Opening segment
        if (format === 'short') {
          variant = 'hero_hook';
          inAnim = 'pop';
        } else {
          variant = 'chapter_title';
          inAnim = 'fade';
        }
      } else if (this.containsStatistic(segment.narrationText)) {
        variant = 'statistic_card';
        inAnim = 'pop';
      } else if (format === 'long' && segment.sectionName && segment.sectionName !== 'Body' && i % 3 === 0) {
        variant = 'chapter_title';
      }

      const positioning = SafeZonePlanner.getPositioningForVariant(variant, format);

      overlays.push({
        elementId: `text_cap_${segment.segmentId}`,
        primaryText: segment.narrationText,
        highlightWords: segment.emphasisKeywords || [],
        styleVariant: variant,
        positioning,
        startTimelineSeconds: startSeconds,
        durationSeconds: durationSeconds,
        inAnimation: inAnim,
        outAnimation: outAnim,
      });

      // If segment has a verifiable source attribution in long-form, add lower-third citation overlay
      if (format === 'long' && segment.sourceReference) {
        const lowerThirdPosition = SafeZonePlanner.getPositioningForVariant('lower_third', format);
        overlays.push({
          elementId: `text_cite_${segment.segmentId}`,
          primaryText: `Source: ${segment.sourceReference}`,
          styleVariant: 'lower_third',
          positioning: lowerThirdPosition,
          startTimelineSeconds: Number((startSeconds + 0.5).toFixed(3)),
          durationSeconds: Number(Math.min(3.5, durationSeconds - 0.5).toFixed(3)),
          inAnimation: 'fade',
          outAnimation: 'fade',
        });
      }
    }

    return overlays;
  }

  private containsStatistic(text: string): boolean {
    // Detect numbers, percentages, or measurements indicating key data points
    return /\b\d+(\.\d+)?%|\b\d{2,}\b|\$\d+/.test(text);
  }
}
