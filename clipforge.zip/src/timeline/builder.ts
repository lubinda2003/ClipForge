/**
 * ClipForge Timeline Builder
 * Assembles video, narration, music, SFX, text overlays, and retention tracks into a unified TimelineArtifact.
 */

import { VideoFormat, AspectRatio } from '../contracts/common.ts';
import {
  TimelineArtifact,
  VideoClipElement,
  NarrationClipElement,
} from '../contracts/timeline.ts';
import { ScenesArtifact } from '../contracts/scenes.ts';
import { BrollSelectionArtifact } from '../contracts/stock.ts';
import { NarrationArtifact } from '../contracts/narration.ts';
import { ScriptArtifact } from '../contracts/script.ts';
import { AssetsArtifact } from '../contracts/assets.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';

import { SafeZonePlanner } from './safe_zone_planner.ts';
import { DuckingPlanner, SpeechInterval } from './ducking_planner.ts';
import { MusicPlanner } from './music_planner.ts';
import { SfxPlanner } from './sfx_planner.ts';
import { CaptionPlanner } from './caption_planner.ts';
import { TransitionPlanner } from './transition_planner.ts';
import { MotionPlanner } from './motion_planner.ts';
import { RetentionEditingPlanner } from './retention_planner.ts';

export interface TimelineBuilderOptions {
  jobId: string;
  format: VideoFormat;
  scenes: ScenesArtifact;
  broll: BrollSelectionArtifact;
  narration: NarrationArtifact;
  script: ScriptArtifact;
  assets?: AssetsArtifact;
  strategy?: ContentStrategyArtifact;
}

export class TimelineBuilder {
  private duckingPlanner: DuckingPlanner;
  private musicPlanner: MusicPlanner;
  private sfxPlanner: SfxPlanner;
  private captionPlanner: CaptionPlanner;
  private transitionPlanner: TransitionPlanner;
  private motionPlanner: MotionPlanner;
  private retentionPlanner: RetentionEditingPlanner;

  constructor() {
    this.duckingPlanner = new DuckingPlanner();
    this.musicPlanner = new MusicPlanner(this.duckingPlanner);
    this.sfxPlanner = new SfxPlanner(this.duckingPlanner);
    this.captionPlanner = new CaptionPlanner();
    this.transitionPlanner = new TransitionPlanner();
    this.motionPlanner = new MotionPlanner();
    this.retentionPlanner = new RetentionEditingPlanner();
  }

  /**
   * Constructs the complete TimelineArtifact.
   */
  public buildTimeline(options: TimelineBuilderOptions): TimelineArtifact {
    const { jobId, format, scenes, broll, narration, script, assets, strategy } = options;

    const targetAspectRatio: AspectRatio = format === 'short' ? '9:16' : '16:9';
    const totalDurationSeconds = narration.totalDurationSeconds > 0
      ? narration.totalDurationSeconds
      : scenes.totalDurationSeconds;

    // 1. Build Narration Track and speech intervals
    const narrationClips: NarrationClipElement[] = [];
    const speechIntervals: SpeechInterval[] = [];
    let cumulativeNarrationTime = 0;

    for (const segment of narration.segmentResults) {
      const start = Number(cumulativeNarrationTime.toFixed(3));
      const dur = segment.actualDurationSeconds;
      const end = Number((start + dur).toFixed(3));

      narrationClips.push({
        elementId: `narration_${segment.segmentId}`,
        segmentId: segment.segmentId,
        audioFilePath: segment.audioFilePath,
        startTimelineSeconds: start,
        durationSeconds: dur,
        volume: 1.0,
      });

      speechIntervals.push({ startSeconds: start, endSeconds: end });
      cumulativeNarrationTime += dur;
    }

    // 2. Retention analysis
    const retentionPlan = this.retentionPlanner.planRetentionEvents(
      scenes,
      script,
      narration,
      format,
      strategy
    );

    // 3. Build Video Track from Scenes + B-Roll Selections
    const videoClips: VideoClipElement[] = [];
    const brollMap = new Map<string, (typeof broll.selections)[0]>();
    for (const sel of broll.selections) {
      brollMap.set(sel.sceneId, sel);
    }

    let cumulativeVideoTime = 0;
    const totalSceneCount = scenes.scenes.length;

    for (let i = 0; i < totalSceneCount; i++) {
      const scene = scenes.scenes[i];
      const selection = brollMap.get(scene.sceneId);

      // Derive visual clip timing from scene definition
      const startTimeline = Number(cumulativeVideoTime.toFixed(3));
      const clipDuration = scene.desiredDurationSeconds;

      const sourceFilePath = selection?.downloadedLocalPath ||
        selection?.selectedFile?.url ||
        selection?.selectedCandidate?.downloadUrl ||
        `stock_placeholder_${scene.sceneId}.mp4`;

      const isPatternInterrupt = retentionPlan.annotations.some(
        a => a.event === 'pattern_interrupt' && Math.abs(a.timestampSeconds - startTimeline) < 0.5
      );

      const transitions = this.transitionPlanner.planTransition(
        i,
        totalSceneCount,
        scene,
        format,
        isPatternInterrupt
      );

      const motion = this.motionPlanner.planMotion(scene, i, totalSceneCount);

      // Crop and scale instructions
      const candidateAspect = selection?.selectedFile?.aspectRatio ||
        selection?.selectedCandidate?.originalAspectRatio ||
        '16:9';
      let scaleMode: 'fit' | 'fill' | 'smart_center_crop' = 'fill';
      if (format === 'short' && candidateAspect === '16:9') {
        scaleMode = 'smart_center_crop';
      }

      videoClips.push({
        elementId: `video_clip_${scene.sceneId}`,
        sceneId: scene.sceneId,
        sourceFilePath,
        startTimelineSeconds: startTimeline,
        durationSeconds: clipDuration,
        sourceTrimStartSeconds: selection?.trimStartSeconds || 0,
        motionEffect: motion,
        transitionIn: transitions.transitionIn,
        transitionOut: transitions.transitionOut,
        cropOrScale: {
          scaleMode,
          aspectRatio: targetAspectRatio,
        },
      });

      cumulativeVideoTime += clipDuration;
    }

    // Adjust last video clip duration to precisely cover narration duration if minor floating-point difference
    if (videoClips.length > 0) {
      const totalVideoCoverage = videoClips.reduce((acc, c) => acc + c.durationSeconds, 0);
      const diff = totalDurationSeconds - totalVideoCoverage;
      if (Math.abs(diff) > 0.001 && Math.abs(diff) < 0.5) {
        videoClips[videoClips.length - 1].durationSeconds = Number(
          (videoClips[videoClips.length - 1].durationSeconds + diff).toFixed(3)
        );
      }
    }

    // 4. Music Track
    const musicClips = this.musicPlanner.planMusicClips(assets?.musicTrack, {
      format,
      totalDurationSeconds,
      speechIntervals,
    });

    // 5. SFX Track
    const sfxClips = this.sfxPlanner.planSfxClips(
      assets?.sfxTracks || [],
      speechIntervals
    );

    // 6. Text Overlays / Captions
    const textOverlays = this.captionPlanner.planCaptions(
      script,
      narration,
      format
    );

    return {
      jobId,
      createdAt: new Date().toISOString(),
      format,
      aspectRatio: targetAspectRatio,
      totalDurationSeconds: Number(totalDurationSeconds.toFixed(3)),
      tracks: {
        video: videoClips,
        narration: narrationClips,
        music: musicClips,
        sfx: sfxClips,
        textOverlays,
      },
      retentionAnnotations: retentionPlan.annotations,
      safeZone: SafeZonePlanner.getSafeZone(format),
      metadata: {
        totalVideoClips: videoClips.length,
        totalNarrationClips: narrationClips.length,
        totalMusicClips: musicClips.length,
        totalSfxClips: sfxClips.length,
        totalTextOverlays: textOverlays.length,
        musicAssetId: assets?.musicTrack?.asset?.assetId,
        attributionsRequired: assets?.attributionsRequired || [],
      },
    };
  }
}
