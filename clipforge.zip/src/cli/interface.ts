/**
 * ClipForge Command Line Interface (CLI) Specification
 * Headless execution entry points for automation, CI/CD runners, and developers.
 */

import { VideoFormat } from '../contracts/common.ts';
import { PipelineStageName } from '../contracts/pipeline.ts';

export interface CliGlobalOptions {
  config?: string; // Path to custom clipforge.config.json
  verbose?: boolean;
  quiet?: boolean;
  cacheDir?: string;
  outputDir?: string;
}

export interface CliCreateCommandOptions extends CliGlobalOptions {
  topic: string;
  format: VideoFormat;
  targetDuration?: 'concise' | 'standard' | 'deep_dive';
  dryRun?: boolean;
  fromStage?: PipelineStageName;
  stopAtStage?: PipelineStageName;
}

export interface CliStageCommandOptions extends CliGlobalOptions {
  jobId?: string;
  inputArtifactPath?: string;
  outputArtifactPath?: string;
}

export interface CliAssetCommandOptions extends CliGlobalOptions {
  action: 'list' | 'sync' | 'verify_licenses' | 'upload';
  category?: string;
  type?: 'music' | 'sfx';
}

export interface CliRenderCommandOptions extends CliGlobalOptions {
  timelineJsonPath: string;
  format: VideoFormat;
  outputVideoPath?: string;
}

export interface CliValidateCommandOptions extends CliGlobalOptions {
  videoPath: string;
  format: VideoFormat;
  reportPath?: string;
}
