/**
 * ClipForge CLI Runner
 * Implements commands: research, strategy, analyze, script, narrate, pipeline.
 */

import fs from 'node:fs';
import path from 'node:path';
import { VideoFormat } from '../contracts/common.ts';
import { ResearchEngine } from '../research/engine.ts';
import { ContentStrategyEngine } from '../strategy/engine.ts';
import { ScriptEngine } from '../scripting/engine.ts';
import { NarrationEngine } from '../narration/engine.ts';
import { ScenePlanner } from '../scenes/engine.ts';
import { BrollSelectionEngine } from '../stock/engine.ts';
import { ResearchArtifact } from '../contracts/research.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';
import { ScriptArtifact } from '../contracts/script.ts';
import { NarrationArtifact } from '../contracts/narration.ts';
import { ScenesArtifact } from '../contracts/scenes.ts';
import { BrollSelectionArtifact } from '../contracts/stock.ts';
import { AssetsArtifact } from '../contracts/assets.ts';
import { TimelineArtifact } from '../contracts/timeline.ts';
import { AudioAssetLibrary } from '../assets/library.ts';
import { TimelineEngine } from '../timeline/engine.ts';
import { RenderEngine } from '../rendering/engine.ts';
import { SHORT_FORM_PROFILE, LONG_FORM_PROFILE, RenderProfile } from '../contracts/rendering.ts';
import { LocalStorageProvider } from '../storage/local.ts';
import { CacheManager } from '../storage/cache.ts';

export interface CliParsedArgs {
  command: string;
  topic?: string;
  format: VideoFormat;
  jobId?: string;
  researchJsonPath?: string;
  strategyJsonPath?: string;
  scriptJsonPath?: string;
  narrationJsonPath?: string;
  scenesJsonPath?: string;
  brollJsonPath?: string;
  assetsJsonPath?: string;
  timelineJsonPath?: string;
  outputPath?: string;
  voice?: string;
  speed?: number;
  cacheDir?: string;
  verbose?: boolean;
  offline?: boolean;
  noDownload?: boolean;
  noRender?: boolean;
}

export function parseArgs(rawArgs: string[]): CliParsedArgs {
  const args = [...rawArgs];
  const command = args[0] || 'help';

  let topic: string | undefined;
  let format: VideoFormat = 'short';
  let jobId: string | undefined;
  let researchJsonPath: string | undefined;
  let strategyJsonPath: string | undefined;
  let scriptJsonPath: string | undefined;
  let narrationJsonPath: string | undefined;
  let scenesJsonPath: string | undefined;
  let brollJsonPath: string | undefined;
  let assetsJsonPath: string | undefined;
  let timelineJsonPath: string | undefined;
  let outputPath: string | undefined;
  let voice: string | undefined;
  let speed: number | undefined;
  let cacheDir: string | undefined;
  let verbose = false;
  let offline = false;
  let noDownload = false;
  let noRender = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--topic' && i + 1 < args.length) {
      topic = args[++i];
    } else if (arg === '--format' && i + 1 < args.length) {
      const f = args[++i].toLowerCase();
      if (f === 'short' || f === 'long') {
        format = f;
      }
    } else if ((arg === '--job-id' || arg === '--job') && i + 1 < args.length) {
      jobId = args[++i];
    } else if (arg === '--research-json' && i + 1 < args.length) {
      researchJsonPath = args[++i];
    } else if (arg === '--strategy-json' && i + 1 < args.length) {
      strategyJsonPath = args[++i];
    } else if (arg === '--script-json' && i + 1 < args.length) {
      scriptJsonPath = args[++i];
    } else if (arg === '--narration-json' && i + 1 < args.length) {
      narrationJsonPath = args[++i];
    } else if (arg === '--scenes-json' && i + 1 < args.length) {
      scenesJsonPath = args[++i];
    } else if (arg === '--broll-json' && i + 1 < args.length) {
      brollJsonPath = args[++i];
    } else if (arg === '--assets-json' && i + 1 < args.length) {
      assetsJsonPath = args[++i];
    } else if ((arg === '--timeline-json' || arg === '--timeline') && i + 1 < args.length) {
      timelineJsonPath = args[++i];
    } else if ((arg === '--output' || arg === '-o' || arg === '--video') && i + 1 < args.length) {
      outputPath = args[++i];
    } else if (arg === '--voice' && i + 1 < args.length) {
      voice = args[++i];
    } else if (arg === '--speed' && i + 1 < args.length) {
      speed = parseFloat(args[++i]);
    } else if (arg === '--cache-dir' && i + 1 < args.length) {
      cacheDir = args[++i];
    } else if (arg === '--verbose' || arg === '-v') {
      verbose = true;
    } else if (arg === '--offline') {
      offline = true;
    } else if (arg === '--no-download') {
      noDownload = true;
    } else if (arg === '--no-render') {
      noRender = true;
    }
  }

  return {
    command,
    topic,
    format,
    jobId,
    researchJsonPath,
    strategyJsonPath,
    scriptJsonPath,
    narrationJsonPath,
    scenesJsonPath,
    brollJsonPath,
    assetsJsonPath,
    timelineJsonPath,
    outputPath,
    voice,
    speed,
    cacheDir,
    verbose,
    offline,
    noDownload,
    noRender,
  };
}

export interface CliDependencies {
  researchEngine?: ResearchEngine;
  strategyEngine?: ContentStrategyEngine;
  scriptEngine?: ScriptEngine;
  narrationEngine?: NarrationEngine;
  scenePlanner?: ScenePlanner;
  brollEngine?: BrollSelectionEngine;
  audioLibrary?: AudioAssetLibrary;
  timelineEngine?: TimelineEngine;
  renderEngine?: RenderEngine;
}

export async function runCli(argv: string[], deps?: CliDependencies): Promise<number> {
  const parsed = parseArgs(argv);
  const storage = new LocalStorageProvider(parsed.cacheDir || './.cache/clipforge');
  const cache = new CacheManager(storage);

  const researchEngine = deps?.researchEngine || new ResearchEngine({
    storage,
    cache,
    geminiProvider: parsed.offline ? new (await import('../research/gemini.ts')).GeminiResearchProvider({ apiKey: '' }) : undefined,
    youtubeProvider: parsed.offline ? new (await import('../research/youtube.ts')).YouTubeResearchProvider({ apiKey: '' }) : undefined,
  });

  const strategyEngine = deps?.strategyEngine || new ContentStrategyEngine({
    storage,
    cache,
    geminiProvider: parsed.offline ? new (await import('../strategy/gemini.ts')).GeminiStrategyProvider({ apiKey: '' }) : undefined,
  });

  const scriptEngine = deps?.scriptEngine || new ScriptEngine({
    storage,
    cache,
    scriptProvider: parsed.offline ? new (await import('../scripting/gemini.ts')).GeminiScriptProvider({ apiKey: '' }) : undefined,
  });

  const narrationEngine = deps?.narrationEngine || new NarrationEngine({
    storage,
    cache,
    provider: parsed.offline ? new (await import('../narration/piper.ts')).PiperNarrationProvider({ mockMode: true, cache }) : undefined,
  });

  const scenePlanner = deps?.scenePlanner || new ScenePlanner({
    storage,
    cache,
    provider: parsed.offline ? new (await import('../scenes/gemini.ts')).GeminiScenePlanningProvider({ apiKey: '' }) : undefined,
  });

  const brollEngine = deps?.brollEngine || new BrollSelectionEngine({
    storage,
    cache,
  });

  const audioLibrary = deps?.audioLibrary || new AudioAssetLibrary({
    storage,
    cacheDir: parsed.cacheDir ? path.join(parsed.cacheDir, 'assets') : undefined,
  });

  const timelineEngine = deps?.timelineEngine || new TimelineEngine({
    storage,
    audioLibrary,
  });

  const renderEngine = deps?.renderEngine || new RenderEngine({
    baseDirectory: parsed.cacheDir || './.cache/clipforge',
    storage,
  });

  switch (parsed.command) {
    case 'research': {
      if (!parsed.topic) {
        console.error('Error: --topic is required for "research" command.');
        return 1;
      }
      console.log(`[ClipForge] Initiating research for "${parsed.topic}" (${parsed.format})...`);
      const artifact = await researchEngine.executeResearch(parsed.topic, {
        format: parsed.format,
        jobId: parsed.jobId,
      });

      console.log(`[ClipForge] Research completed successfully for job: ${artifact.jobId}`);
      console.log(`- Facts collected: ${artifact.observedData.verifiableFacts.length}`);
      console.log(`- Public videos observed: ${artifact.observedData.youtubePublicVideos.length}`);
      console.log(`- Trend status: ${artifact.inferredInsights.trendAssessment?.trendStatus}`);
      return 0;
    }

    case 'strategy': {
      let researchArtifact: ResearchArtifact;

      if (parsed.researchJsonPath && fs.existsSync(parsed.researchJsonPath)) {
        const fileContent = fs.readFileSync(parsed.researchJsonPath, 'utf-8');
        researchArtifact = JSON.parse(fileContent) as ResearchArtifact;
      } else if (parsed.topic) {
        console.log(`[ClipForge] Research artifact not provided. Running research pass first...`);
        researchArtifact = await researchEngine.executeResearch(parsed.topic, {
          format: parsed.format,
          jobId: parsed.jobId,
        });
      } else {
        console.error('Error: Either --research-json or --topic is required for "strategy" command.');
        return 1;
      }

      console.log(`[ClipForge] Formulating content strategy for "${researchArtifact.topic}" (${parsed.format})...`);
      const strategy = await strategyEngine.executeStrategy(researchArtifact, {
        format: parsed.format,
        jobId: parsed.jobId,
      });

      console.log(`[ClipForge] Strategy completed successfully for job: ${strategy.jobId}`);
      console.log(`- Hook: "${strategy.hook.hookText}" (${strategy.hook.durationTargetSeconds}s)`);
      console.log(`- Core thesis: ${strategy.angle.coreThesis}`);
      console.log(`- Estimated duration: ${strategy.estimatedDurationRangeSeconds.min}s - ${strategy.estimatedDurationRangeSeconds.max}s (Target: ${strategy.estimatedDurationRangeSeconds.target}s)`);
      return 0;
    }

    case 'analyze': {
      if (!parsed.topic) {
        console.error('Error: --topic is required for "analyze" command.');
        return 1;
      }
      console.log(`[ClipForge] Executing Phase 2 Analysis (Research + Strategy) for "${parsed.topic}" (${parsed.format})...`);
      const research = await researchEngine.executeResearch(parsed.topic, {
        format: parsed.format,
        jobId: parsed.jobId,
      });

      const strategy = await strategyEngine.executeStrategy(research, {
        format: parsed.format,
        jobId: research.jobId,
      });

      console.log(`\n=== ClipForge Analysis Summary ===`);
      console.log(`Job ID: ${strategy.jobId}`);
      console.log(`Topic: ${strategy.topic} [Format: ${strategy.format}]`);
      console.log(`Trend: ${research.inferredInsights.trendAssessment?.trendStatus}`);
      console.log(`Hook (${strategy.hook.hookType}): "${strategy.hook.hookText}"`);
      console.log(`Duration Range: ${strategy.estimatedDurationRangeSeconds.min}s - ${strategy.estimatedDurationRangeSeconds.max}s`);
      console.log(`Artifacts saved in .cache/clipforge/inputs/jobs/${strategy.jobId}/`);
      return 0;
    }

    case 'script': {
      let researchArtifact: ResearchArtifact | undefined;
      let strategyArtifact: ContentStrategyArtifact | undefined;

      if (parsed.strategyJsonPath && fs.existsSync(parsed.strategyJsonPath)) {
        strategyArtifact = JSON.parse(fs.readFileSync(parsed.strategyJsonPath, 'utf-8'));
      }

      if (parsed.researchJsonPath && fs.existsSync(parsed.researchJsonPath)) {
        researchArtifact = JSON.parse(fs.readFileSync(parsed.researchJsonPath, 'utf-8'));
      }

      if (!strategyArtifact || !researchArtifact) {
        if (!parsed.topic) {
          console.error('Error: --topic or (--research-json AND --strategy-json) is required for "script" command.');
          return 1;
        }

        if (!researchArtifact) {
          console.log(`[ClipForge] Executing research pass for "${parsed.topic}"...`);
          researchArtifact = await researchEngine.executeResearch(parsed.topic, {
            format: parsed.format,
            jobId: parsed.jobId,
          });
        }

        if (!strategyArtifact) {
          console.log(`[ClipForge] Executing strategy pass for "${parsed.topic}"...`);
          strategyArtifact = await strategyEngine.executeStrategy(researchArtifact, {
            format: parsed.format,
            jobId: researchArtifact.jobId,
          });
        }
      }

      console.log(`[ClipForge] Generating script for "${strategyArtifact.topic}" (${parsed.format})...`);
      const script = await scriptEngine.executeScripting(researchArtifact, strategyArtifact, {
        format: parsed.format,
        jobId: parsed.jobId || strategyArtifact.jobId,
      });

      console.log(`[ClipForge] Script generated successfully for job: ${script.jobId}`);
      console.log(`- Title: "${script.title}"`);
      console.log(`- Segments: ${script.segments.length}`);
      console.log(`- Total word count: ${script.totalWordCount}`);
      console.log(`- Estimated duration: ~${script.estimatedTotalDurationSeconds}s`);
      console.log(`Artifact saved: .cache/clipforge/inputs/jobs/${script.jobId}/script.json`);
      return 0;
    }

    case 'narrate': {
      let scriptArtifact: ScriptArtifact | undefined;

      if (parsed.scriptJsonPath && fs.existsSync(parsed.scriptJsonPath)) {
        scriptArtifact = JSON.parse(fs.readFileSync(parsed.scriptJsonPath, 'utf-8'));
      } else if (parsed.topic) {
        console.log(`[ClipForge] Generating upstream pipeline (research -> strategy -> script) for "${parsed.topic}"...`);
        const research = await researchEngine.executeResearch(parsed.topic, {
          format: parsed.format,
          jobId: parsed.jobId,
        });
        const strategy = await strategyEngine.executeStrategy(research, {
          format: parsed.format,
          jobId: research.jobId,
        });
        scriptArtifact = await scriptEngine.executeScripting(research, strategy, {
          format: parsed.format,
          jobId: strategy.jobId,
        });
      } else {
        console.error('Error: Either --script-json or --topic is required for "narrate" command.');
        return 1;
      }

      console.log(`[ClipForge] Synthesizing narration for "${scriptArtifact.topic}" (${scriptArtifact.segments.length} segments)...`);
      const narration = await narrationEngine.executeNarration(scriptArtifact, {
        jobId: parsed.jobId || scriptArtifact.jobId,
        voice: parsed.voice,
        speed: parsed.speed,
      });

      console.log(`[ClipForge] Narration synthesized successfully for job: ${narration.jobId}`);
      console.log(`- Engine: ${narration.engine} (Model: ${narration.modelOrVoice})`);
      console.log(`- Segments synthesized: ${narration.segmentResults.length}`);
      console.log(`- Measured actual duration: ${narration.totalDurationSeconds}s`);
      console.log(`Artifact saved: .cache/clipforge/inputs/jobs/${narration.jobId}/narration.json`);
      return 0;
    }

    case 'scenes': {
      let scriptArtifact: ScriptArtifact | undefined;
      let narrationArtifact: NarrationArtifact | undefined;

      if (parsed.scriptJsonPath && fs.existsSync(parsed.scriptJsonPath)) {
        scriptArtifact = JSON.parse(fs.readFileSync(parsed.scriptJsonPath, 'utf-8'));
      }
      if (parsed.narrationJsonPath && fs.existsSync(parsed.narrationJsonPath)) {
        narrationArtifact = JSON.parse(fs.readFileSync(parsed.narrationJsonPath, 'utf-8'));
      }

      if (!scriptArtifact) {
        if (!parsed.topic) {
          console.error('Error: Either --script-json or --topic is required for "scenes" command.');
          return 1;
        }

        console.log(`[ClipForge] Generating upstream pipeline (research -> strategy -> script -> narrate) for "${parsed.topic}"...`);
        const research = await researchEngine.executeResearch(parsed.topic, {
          format: parsed.format,
          jobId: parsed.jobId,
        });
        const strategy = await strategyEngine.executeStrategy(research, {
          format: parsed.format,
          jobId: research.jobId,
        });
        scriptArtifact = await scriptEngine.executeScripting(research, strategy, {
          format: parsed.format,
          jobId: strategy.jobId,
        });
        narrationArtifact = await narrationEngine.executeNarration(scriptArtifact, {
          jobId: scriptArtifact.jobId,
          voice: parsed.voice,
          speed: parsed.speed,
        });
      }

      console.log(`[ClipForge] Planning visual scenes for "${scriptArtifact.topic}" (${scriptArtifact.segments.length} script segments)...`);
      const scenes = await scenePlanner.executeScenePlanning(scriptArtifact, narrationArtifact, undefined, undefined, {
        jobId: parsed.jobId || scriptArtifact.jobId,
        format: parsed.format,
      });

      console.log(`[ClipForge] Scene planning completed successfully for job: ${scenes.jobId}`);
      console.log(`- Total scenes planned: ${scenes.totalScenes}`);
      console.log(`- Total duration: ${scenes.totalDurationSeconds}s`);
      console.log(`- Target aspect ratio: ${scenes.scenes[0]?.targetAspectRatio || '9:16'}`);
      console.log(`Artifact saved: .cache/clipforge/inputs/jobs/${scenes.jobId}/scenes.json`);
      return 0;
    }

    case 'broll': {
      let scenesArtifact: ScenesArtifact | undefined;

      if (parsed.scenesJsonPath && fs.existsSync(parsed.scenesJsonPath)) {
        scenesArtifact = JSON.parse(fs.readFileSync(parsed.scenesJsonPath, 'utf-8'));
      } else if (parsed.topic) {
        console.log(`[ClipForge] Running upstream stages to generate scenes for "${parsed.topic}"...`);
        const research = await researchEngine.executeResearch(parsed.topic, {
          format: parsed.format,
          jobId: parsed.jobId,
        });
        const strategy = await strategyEngine.executeStrategy(research, {
          format: parsed.format,
          jobId: research.jobId,
        });
        const script = await scriptEngine.executeScripting(research, strategy, {
          format: parsed.format,
          jobId: strategy.jobId,
        });
        const narration = await narrationEngine.executeNarration(script, {
          jobId: script.jobId,
          voice: parsed.voice,
          speed: parsed.speed,
        });
        scenesArtifact = await scenePlanner.executeScenePlanning(script, narration, strategy, research, {
          jobId: script.jobId,
          format: parsed.format,
        });
      } else {
        console.error('Error: Either --scenes-json or --topic is required for "broll" command.');
        return 1;
      }

      console.log(`[ClipForge] Selecting B-Roll media for ${scenesArtifact.totalScenes} scenes (${scenesArtifact.format})...`);
      const broll = await brollEngine.executeBrollSelection(scenesArtifact, {
        jobId: parsed.jobId || scenesArtifact.jobId,
        format: parsed.format,
        downloadMedia: !parsed.noDownload && !parsed.offline,
      });

      console.log(`[ClipForge] B-Roll selection completed successfully for job: ${broll.jobId}`);
      console.log(`- Selected scenes: ${broll.selections.length}/${broll.totalScenes}`);
      console.log(`- Unresolved scenes: ${broll.unresolvedScenes?.length || 0}`);
      console.log(`- Bytes downloaded: ${(broll.cacheStats.bytesDownloaded / 1024 / 1024).toFixed(2)} MB`);
      console.log(`Artifact saved: .cache/clipforge/inputs/jobs/${broll.jobId}/broll_selection.json`);
      return 0;
    }

    case 'assets':
    case 'audio': {
      const jobId = parsed.jobId || 'job_cli_assets';
      console.log(`[ClipForge] Selecting audio assets for job ${jobId} (${parsed.format})...`);

      let totalDuration = parsed.format === 'short' ? 45 : 180;
      if (parsed.narrationJsonPath && fs.existsSync(parsed.narrationJsonPath)) {
        const narr: NarrationArtifact = JSON.parse(fs.readFileSync(parsed.narrationJsonPath, 'utf-8'));
        totalDuration = narr.totalDurationSeconds;
      }

      const assets = await audioLibrary.selectAssetsForProduction({
        jobId,
        format: parsed.format,
        totalDurationSeconds: totalDuration,
        topic: parsed.topic,
        desiredEnergy: parsed.format === 'short' ? 'high' : 'medium',
      });

      console.log(`[ClipForge] Audio assets selected successfully for job: ${assets.jobId}`);
      console.log(`- Music Track: ${assets.musicTrack?.asset.title || 'None'}`);
      console.log(`- SFX Tracks: ${assets.sfxTracks?.length || 0}`);
      console.log(`- Attributions Required: ${assets.attributionsRequired?.length || 0}`);
      if (assets.warnings?.length) {
        console.log(`- Warnings: ${assets.warnings.join('; ')}`);
      }
      return 0;
    }

    case 'timeline':
    case 'edit': {
      let scenesArtifact: ScenesArtifact | undefined;
      let brollArtifact: BrollSelectionArtifact | undefined;
      let narrationArtifact: NarrationArtifact | undefined;
      let scriptArtifact: ScriptArtifact | undefined;

      if (parsed.scenesJsonPath && fs.existsSync(parsed.scenesJsonPath)) {
        scenesArtifact = JSON.parse(fs.readFileSync(parsed.scenesJsonPath, 'utf-8'));
      }
      if (parsed.brollJsonPath && fs.existsSync(parsed.brollJsonPath)) {
        brollArtifact = JSON.parse(fs.readFileSync(parsed.brollJsonPath, 'utf-8'));
      }
      if (parsed.narrationJsonPath && fs.existsSync(parsed.narrationJsonPath)) {
        narrationArtifact = JSON.parse(fs.readFileSync(parsed.narrationJsonPath, 'utf-8'));
      }
      if (parsed.scriptJsonPath && fs.existsSync(parsed.scriptJsonPath)) {
        scriptArtifact = JSON.parse(fs.readFileSync(parsed.scriptJsonPath, 'utf-8'));
      }

      // If missing inputs but topic is provided, run upstream stages
      if (!scenesArtifact || !brollArtifact || !narrationArtifact || !scriptArtifact) {
        if (!parsed.topic) {
          console.error('Error: Either full upstream JSON artifacts (--scenes-json, --broll-json, --narration-json, --script-json) or --topic is required for "timeline" command.');
          return 1;
        }

        console.log(`[ClipForge] Running upstream stages to construct multi-track timeline for "${parsed.topic}"...`);
        const research = await researchEngine.executeResearch(parsed.topic, { format: parsed.format, jobId: parsed.jobId });
        const strategy = await strategyEngine.executeStrategy(research, { format: parsed.format, jobId: research.jobId });
        scriptArtifact = await scriptEngine.executeScripting(research, strategy, { format: parsed.format, jobId: strategy.jobId });
        narrationArtifact = await narrationEngine.executeNarration(scriptArtifact, { jobId: scriptArtifact.jobId, voice: parsed.voice, speed: parsed.speed });
        scenesArtifact = await scenePlanner.executeScenePlanning(scriptArtifact, narrationArtifact, strategy, research, { jobId: scriptArtifact.jobId, format: parsed.format });
        brollArtifact = await brollEngine.executeBrollSelection(scenesArtifact, { jobId: scriptArtifact.jobId, format: parsed.format, downloadMedia: !parsed.noDownload && !parsed.offline });
      }

      console.log(`[ClipForge] Composing multi-track timeline for ${scenesArtifact.totalScenes} scenes (${scenesArtifact.format})...`);
      const { timeline, assets } = await timelineEngine.executeTimelineComposition(
        scenesArtifact,
        brollArtifact,
        narrationArtifact,
        scriptArtifact,
        undefined,
        {
          jobId: parsed.jobId || scriptArtifact.jobId,
          format: parsed.format,
          topic: parsed.topic || scriptArtifact.title,
        }
      );

      console.log(`[ClipForge] Timeline generated and validated successfully for job: ${timeline.jobId}`);
      console.log(`- Format / Aspect Ratio: ${timeline.format} (${timeline.aspectRatio})`);
      console.log(`- Total Duration: ${timeline.totalDurationSeconds}s`);
      console.log(`- Video Clips: ${timeline.tracks.video.length}`);
      console.log(`- Narration Clips: ${timeline.tracks.narration.length}`);
      console.log(`- Music Clips: ${timeline.tracks.music.length} (Asset: ${assets.musicTrack?.asset.title || 'None'})`);
      console.log(`- SFX Clips: ${timeline.tracks.sfx.length}`);
      console.log(`- Text Overlays: ${timeline.tracks.textOverlays.length}`);
      console.log(`- Retention Events: ${timeline.retentionAnnotations?.length || 0}`);
      console.log(`Artifact saved: .cache/clipforge/inputs/jobs/${timeline.jobId}/timeline.json`);
      return 0;
    }

    case 'render': {
      let timeline: TimelineArtifact | undefined;
      const effectiveJobId = parsed.jobId || 'job_render_cli';

      if (parsed.timelineJsonPath && fs.existsSync(parsed.timelineJsonPath)) {
        timeline = JSON.parse(fs.readFileSync(parsed.timelineJsonPath, 'utf-8'));
      } else if (parsed.jobId) {
        const pathsToTry = [
          path.resolve(storage.baseDirectory, 'outputs', 'jobs', parsed.jobId, 'timeline.json'),
          path.resolve(storage.baseDirectory, 'inputs', 'jobs', parsed.jobId, 'timeline.json'),
        ];
        for (const p of pathsToTry) {
          if (fs.existsSync(p)) {
            timeline = JSON.parse(fs.readFileSync(p, 'utf-8'));
            break;
          }
        }
      }

      if (!timeline) {
        console.error('Error: Either valid --timeline-json <path> or --job-id <id> with an existing timeline artifact is required for "render" command.');
        return 1;
      }

      const profile: RenderProfile =
        parsed.format === 'short' || timeline.format === 'short' || timeline.aspectRatio === '9:16'
          ? { ...SHORT_FORM_PROFILE }
          : { ...LONG_FORM_PROFILE };

      console.log(`\n========================================`);
      console.log(`ClipForge FFmpeg Video Rendering & Validation`);
      console.log(`Job ID: ${timeline.jobId || effectiveJobId}`);
      console.log(`Format: ${profile.format} (${profile.resolution.width}x${profile.resolution.height} @ ${profile.frameRate}fps)`);
      console.log(`Target Duration: ${timeline.totalDurationSeconds}s`);
      console.log(`Tracks: ${timeline.tracks.video.length} video, ${timeline.tracks.narration.length} narration, ${timeline.tracks.music.length} music, ${timeline.tracks.sfx.length} sfx, ${timeline.tracks.textOverlays.length} overlays`);
      console.log(`========================================\n`);

      console.log(`[ClipForge] Checking FFmpeg & FFprobe environment...`);
      const env = await renderEngine.checkEnvironment();
      if (!env.ffmpegAvailable || !env.ffprobeAvailable) {
        console.error('Error: FFmpeg or FFprobe binary is missing or not executable in PATH.');
        return 1;
      }
      console.log(`[ClipForge] FFmpeg version: ${env.ffmpegVersion}, FFprobe version: ${env.ffprobeVersion}`);

      console.log(`[ClipForge] Executing FFmpeg rendering pass...`);
      try {
        const result = await renderEngine.executeRender({
          jobId: timeline.jobId || effectiveJobId,
          timeline,
          profile,
          outputFilePath: parsed.outputPath,
        });

        console.log(`\n[ClipForge] Rendering completed successfully in ${result.renderTime.toFixed(2)}s!`);
        console.log(`[ClipForge] Output Video: ${result.outputPath}`);
        console.log(`[ClipForge] Probed Resolution: ${result.width}x${result.height}`);
        console.log(`[ClipForge] Probed Codecs: Video: ${result.videoCodec}, Audio: ${result.audioCodec}`);
        console.log(`[ClipForge] Probed Duration: ${result.duration.toFixed(2)}s (Target: ${timeline.totalDurationSeconds}s)`);
        console.log(`[ClipForge] Output File Size: ${(result.fileSize / (1024 * 1024)).toFixed(2)} MB`);
        console.log(`[ClipForge] Output Validation Status: ${result.validation.status.toUpperCase()}`);

        if (result.warnings.length > 0) {
          console.log(`[ClipForge] Warnings:\n  - ${result.warnings.join('\n  - ')}`);
        }

        if (result.errors.length > 0) {
          console.error(`[ClipForge] Validation Errors:\n  - ${result.errors.join('\n  - ')}`);
          return 1;
        }

        return 0;
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        console.error(`\n[ClipForge] Render failed: ${msg}`);
        return 1;
      }
    }

    case 'validate': {
      if (!parsed.outputPath) {
        console.error('Error: --output <video-path> or --video <video-path> is required for "validate" command.');
        return 1;
      }

      console.log(`[ClipForge] Probing & validating media file at "${parsed.outputPath}"...`);
      const profile = parsed.format === 'short' ? SHORT_FORM_PROFILE : LONG_FORM_PROFILE;
      const validation = await renderEngine.validateOutput(
        parsed.outputPath,
        profile,
        parsed.jobId || 'probe_cli'
      );

      console.log(`\n=== ClipForge FFprobe Validation Summary ===`);
      console.log(`File: ${validation.output.path}`);
      console.log(`Status: ${validation.status.toUpperCase()}`);
      console.log(`Duration: ${validation.output.duration.toFixed(2)}s`);
      console.log(`Resolution: ${validation.output.width}x${validation.output.height} (${validation.output.fps} fps)`);
      console.log(`Video Codec: ${validation.output.videoCodec || 'none'}`);
      console.log(`Audio Codec: ${validation.output.audioCodec || 'none'}`);
      console.log(`Size: ${((validation.output.fileSizeBytes || 0) / (1024 * 1024)).toFixed(2)} MB`);
      console.log(`\nDetailed Checks:`);
      for (const [chk, val] of Object.entries(validation.checks)) {
        console.log(`  - ${chk}: ${val ? 'PASSED' : 'FAILED'}`);
      }

      if (validation.warnings.length > 0) {
        console.log(`\nWarnings:\n  - ${validation.warnings.join('\n  - ')}`);
      }
      if (validation.errors.length > 0) {
        console.error(`\nErrors:\n  - ${validation.errors.join('\n  - ')}`);
        return 1;
      }

      return validation.status === 'passed' ? 0 : 1;
    }

    case 'pipeline':
    case 'produce': {
      if (!parsed.topic) {
        console.error('Error: --topic is required for pipeline execution.');
        return 1;
      }

      console.log(`\n========================================`);
      console.log(`ClipForge Production Pipeline: Research -> MP4 Video`);
      console.log(`Topic: "${parsed.topic}" [Format: ${parsed.format}]`);
      console.log(`========================================\n`);

      // 1. Research
      console.log(`[Stage 1/9] Researching topic...`);
      const research = await researchEngine.executeResearch(parsed.topic, {
        format: parsed.format,
        jobId: parsed.jobId,
      });

      // 2. Strategy
      console.log(`[Stage 2/9] Formulating Strategy...`);
      const strategy = await strategyEngine.executeStrategy(research, {
        format: parsed.format,
        jobId: research.jobId,
      });

      // 3. Scripting
      console.log(`[Stage 3/9] Generating Script...`);
      const script = await scriptEngine.executeScripting(research, strategy, {
        format: parsed.format,
        jobId: strategy.jobId,
      });

      // 4. Narration
      console.log(`[Stage 4/9] Synthesizing Narration...`);
      const narration = await narrationEngine.executeNarration(script, {
        jobId: script.jobId,
        voice: parsed.voice,
        speed: parsed.speed,
      });

      // 5. Scene Planning
      console.log(`[Stage 5/9] Planning Visual Scenes...`);
      const scenes = await scenePlanner.executeScenePlanning(script, narration, strategy, research, {
        jobId: script.jobId,
        format: parsed.format,
      });

      // 6. B-Roll Selection
      console.log(`[Stage 6/9] Selecting & Downloading B-Roll Assets...`);
      const broll = await brollEngine.executeBrollSelection(scenes, {
        jobId: script.jobId,
        format: parsed.format,
        downloadMedia: !parsed.noDownload && !parsed.offline,
      });

      // 7. Multi-Track Timeline & Audio Assets
      console.log(`[Stage 7/9] Composing Multi-Track Timeline & Audio Assets...`);
      const { timeline, assets } = await timelineEngine.executeTimelineComposition(
        scenes,
        broll,
        narration,
        script,
        strategy,
        {
          jobId: script.jobId,
          format: parsed.format,
          topic: parsed.topic,
        }
      );

      console.log(`\n=== ClipForge Pre-Production Summary ===`);
      console.log(`Job ID: ${timeline.jobId}`);
      console.log(`Title: ${script.title}`);
      console.log(`Format: ${timeline.format} (${timeline.aspectRatio})`);
      console.log(`Script Segments: ${script.segments.length}`);
      console.log(`Narration Duration: ${narration.totalDurationSeconds}s`);
      console.log(`Visual Scenes: ${scenes.totalScenes} scenes (${scenes.totalDurationSeconds}s)`);
      console.log(`B-Roll Media Selected: ${broll.selections.length}/${broll.totalScenes}`);
      console.log(`Music Track: ${assets.musicTrack?.asset.title || 'None'} (${assets.musicTrack?.asset.bpm || 0} BPM)`);
      console.log(`SFX Accent Tracks: ${assets.sfxTracks?.length || 0}`);
      console.log(`Text / Caption Overlays: ${timeline.tracks.textOverlays.length}`);
      console.log(`Retention Landmarks: ${timeline.retentionAnnotations?.length || 0}`);
      console.log(`Total Timeline Duration: ${timeline.totalDurationSeconds}s`);

      if (parsed.noRender || parsed.offline || parsed.noDownload) {
        const reason = parsed.noRender ? '--no-render' : parsed.offline ? '--offline' : '--no-download';
        console.log(`\n[Stage 8/9 & 9/9] Skipping video rendering as ${reason} was requested.`);
        console.log(`Pre-production artifacts available at: .cache/clipforge/inputs/jobs/${timeline.jobId}/`);
        return 0;
      }

      // 8. Real FFmpeg Video Rendering & 9. FFprobe Output Validation
      console.log(`\n[Stage 8/9] Executing Real FFmpeg Video Rendering...`);
      const renderProfile: RenderProfile =
        parsed.format === 'short' ? { ...SHORT_FORM_PROFILE } : { ...LONG_FORM_PROFILE };

      try {
        const renderResult = await renderEngine.executeRender({
          jobId: timeline.jobId,
          timeline,
          profile: renderProfile,
          outputFilePath: parsed.outputPath,
        });

        console.log(`[Stage 9/9] Probing & Validating Output Media...`);
        console.log(`\n========================================`);
        console.log(`ClipForge Pipeline Complete!`);
        console.log(`Output MP4: ${renderResult.outputPath}`);
        console.log(`Resolution: ${renderResult.width}x${renderResult.height} (${renderResult.fps} fps)`);
        console.log(`Codecs: Video: ${renderResult.videoCodec}, Audio: ${renderResult.audioCodec}`);
        console.log(`Duration: ${renderResult.duration.toFixed(2)}s`);
        console.log(`File Size: ${(renderResult.fileSize / (1024 * 1024)).toFixed(2)} MB`);
        console.log(`Validation: ${renderResult.validation.status.toUpperCase()}`);
        console.log(`Render Time: ${renderResult.renderTime.toFixed(2)}s`);
        console.log(`========================================\n`);

        return renderResult.validation.status === 'passed' ? 0 : 1;
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        console.error(`\n[ClipForge] Pipeline rendering failed: ${msg}`);
        return 1;
      }
    }

    case 'help':
    default:
      console.log(`ClipForge Headless Video Production Pipeline
Usage:
  clipforge research --topic "<topic>" [--format short|long] [--job-id <id>]
  clipforge strategy --topic "<topic>" [--format short|long] [--research-json <path>]
  clipforge analyze  --topic "<topic>" [--format short|long]
  clipforge script   --topic "<topic>" [--format short|long] [--strategy-json <path>] [--research-json <path>]
  clipforge narrate  --script-json <path> [--voice <voice>] [--speed <speed>]
  clipforge scenes   --script-json <path> [--narration-json <path>]
  clipforge broll    --scenes-json <path> [--no-download]
  clipforge assets   --topic "<topic>" [--format short|long]
  clipforge timeline --topic "<topic>" [--format short|long]
  clipforge render   --job-id <id> [--format short|long] [--output <path>]
  clipforge render   --timeline <path> [--format short|long] [--output <path>]
  clipforge validate --output <path> [--format short|long]
  clipforge pipeline --topic "<topic>" [--format short|long] [--offline] [--no-render]
`);
      return 0;
  }
}

// Allow direct execution if invoked via CLI runner
if (process.argv[1] && process.argv[1].endsWith('cli/index.ts')) {
  runCli(process.argv.slice(2)).then(code => {
    if (code !== 0) process.exit(code);
  });
}
