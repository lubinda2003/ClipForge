/**
 * ClipForge Strategy Validator
 * Ensures strategy artifacts are actionable, structurally coherent, format-appropriate, and contain no fixed-30s anti-patterns.
 */

import { ContentStrategyArtifact } from '../contracts/strategy.ts';
import { StrategyValidationResult } from './interfaces.ts';

export function validateStrategyArtifact(strategy: ContentStrategyArtifact): StrategyValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!strategy.topic || !strategy.topic.trim()) {
    errors.push('Strategy topic is missing or empty.');
  }

  if (strategy.format !== 'short' && strategy.format !== 'long') {
    errors.push(`Invalid video format: ${strategy.format}. Expected "short" or "long".`);
  }

  // Audience validation
  if (!strategy.targetAudience?.primarySegment) {
    errors.push('Target audience primarySegment is required.');
  }
  if (!strategy.targetAudience?.primaryMotivation) {
    errors.push('Target audience primaryMotivation is required.');
  }

  // Angle validation
  if (!strategy.angle?.coreThesis) {
    errors.push('Core thesis is required in strategy angle.');
  }
  if (!strategy.angle?.contrarianOrUniquePerspective) {
    errors.push('Unique or contrarian perspective is required in strategy angle.');
  }

  // Hook validation
  if (!strategy.hook?.hookText) {
    errors.push('Hook text is required.');
  }
  if (!strategy.hook?.durationTargetSeconds || strategy.hook.durationTargetSeconds <= 0) {
    errors.push('Hook durationTargetSeconds must be a positive number.');
  }
  if (strategy.format === 'short' && strategy.hook?.durationTargetSeconds > 6) {
    warnings.push('Short-form hook duration exceeds 6 seconds; recommend 2.5 - 4.5 seconds for maximum retention.');
  }

  // Narrative structure validation
  if (!Array.isArray(strategy.narrativeStructure) || strategy.narrativeStructure.length < 3) {
    errors.push('Narrative structure must contain at least 3 structured acts or sections.');
  } else {
    const totalPercentage = strategy.narrativeStructure.reduce((sum, act) => sum + (act.approxPercentageOfVideo || 0), 0);
    if (totalPercentage < 70 || totalPercentage > 130) {
      warnings.push(`Narrative structure percentage sum (${totalPercentage}%) deviates significantly from 100%.`);
    }
  }

  // Retention mechanisms
  if (!Array.isArray(strategy.retentionPlan) || strategy.retentionPlan.length === 0) {
    errors.push('Retention plan must contain at least one retention mechanism.');
  }

  // Duration Range Validation
  const dur = strategy.estimatedDurationRangeSeconds;
  if (!dur || typeof dur.min !== 'number' || typeof dur.max !== 'number' || typeof dur.target !== 'number') {
    errors.push('estimatedDurationRangeSeconds (min, max, target) is required.');
  } else {
    if (dur.min <= 0 || dur.max <= 0 || dur.target <= 0) {
      errors.push('All duration range values must be greater than zero.');
    }
    if (dur.max < dur.min) {
      errors.push(`Maximum duration (${dur.max}s) cannot be less than minimum duration (${dur.min}s).`);
    }
    if (dur.target < dur.min || dur.target > dur.max) {
      errors.push(`Target duration (${dur.target}s) must fall within min (${dur.min}s) and max (${dur.max}s) range.`);
    }

    // Explicit check against arbitrary 30-second fixed duration
    if (dur.min === 30 && dur.max === 30 && dur.target === 30) {
      warnings.push('Duration is fixed to exactly 30s. Strategy should specify a flexible duration range based on content depth.');
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
  };
}
