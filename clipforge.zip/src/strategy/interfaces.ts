/**
 * ClipForge Strategy Interfaces
 */

import { VideoFormat } from '../contracts/common.ts';
import { ResearchArtifact } from '../contracts/research.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';

export interface StrategyOptions {
  jobId?: string;
  format?: VideoFormat;
  targetDurationCategory?: 'concise' | 'standard' | 'deep_dive';
  useCache?: boolean;
}

export interface StrategyValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export interface IGeminiStrategyProvider {
  readonly providerName: string;
  isAvailable(): boolean;
  generateStrategy(
    research: ResearchArtifact,
    options?: StrategyOptions
  ): Promise<ContentStrategyArtifact>;
}

export interface IContentStrategyEngine {
  executeStrategy(
    research: ResearchArtifact,
    options?: StrategyOptions
  ): Promise<ContentStrategyArtifact>;
}
