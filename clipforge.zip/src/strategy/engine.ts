/**
 * ClipForge Content Strategy Engine
 * Coordinates strategy generation from research.json, validation, and artifact persistence.
 */

import { ResearchArtifact } from '../contracts/research.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';
import { IContentStrategyEngine, StrategyOptions, IGeminiStrategyProvider } from './interfaces.ts';
import { GeminiStrategyProvider } from './gemini.ts';
import { validateStrategyArtifact } from './validator.ts';
import { IStorageProvider } from '../storage/interface.ts';
import { LocalStorageProvider } from '../storage/local.ts';
import { CacheManager } from '../storage/cache.ts';

export interface ContentStrategyEngineDependencies {
  storage?: IStorageProvider;
  cache?: CacheManager;
  geminiProvider?: IGeminiStrategyProvider;
}

export class ContentStrategyEngine implements IContentStrategyEngine {
  private readonly storage: IStorageProvider;
  private readonly cache: CacheManager;
  private readonly geminiProvider: IGeminiStrategyProvider;

  constructor(deps: ContentStrategyEngineDependencies = {}) {
    this.storage = deps.storage || new LocalStorageProvider();
    this.cache = deps.cache || new CacheManager(this.storage);
    this.geminiProvider = deps.geminiProvider || new GeminiStrategyProvider({ cache: this.cache });
  }

  async executeStrategy(
    research: ResearchArtifact,
    options: StrategyOptions = {}
  ): Promise<ContentStrategyArtifact> {
    if (!research || !research.topic) {
      throw new Error('Valid ResearchArtifact is required to formulate Content Strategy.');
    }

    const jobId = options.jobId || research.jobId || `job_${Date.now()}`;

    // 1. Generate strategy via Gemini provider
    const strategy = await this.geminiProvider.generateStrategy(research, {
      ...options,
      jobId,
    });

    // Ensure jobId and topic are aligned
    strategy.jobId = jobId;
    strategy.topic = research.topic;
    strategy.format = options.format || research.formatTarget || strategy.format;

    // 2. Validate strategy structure and retention parameters
    const validation = validateStrategyArtifact(strategy);
    if (!validation.isValid) {
      throw new Error(`Strategy validation failed:\n${validation.errors.join('\n')}`);
    }

    // 3. Persist strategy.json to job directory
    const artifactKey = `jobs/${jobId}/strategy.json`;
    if (this.storage instanceof LocalStorageProvider) {
      await this.storage.writeJson('inputs', artifactKey, strategy);
    }

    return strategy;
  }
}
