/**
 * ClipForge Gemini Strategy Provider
 * Translates structured research findings into a concrete, high-retention content strategy.
 * Consumes research.json directly; does not repeat external research queries.
 */

import { GoogleGenAI } from '@google/genai';
import { ResearchArtifact } from '../contracts/research.ts';
import { ContentStrategyArtifact } from '../contracts/strategy.ts';
import { IGeminiStrategyProvider, StrategyOptions } from './interfaces.ts';
import { CacheManager } from '../storage/cache.ts';

export interface GeminiStrategyConfig {
  apiKey?: string;
  model?: string;
  cache?: CacheManager;
}

export class GeminiStrategyProvider implements IGeminiStrategyProvider {
  readonly providerName = 'gemini_content_strategy';
  private readonly apiKey: string;
  private readonly modelName: string;
  private readonly cache?: CacheManager;

  constructor(config: GeminiStrategyConfig = {}) {
    this.apiKey = (config.apiKey !== undefined ? config.apiKey : process.env.GEMINI_API_KEY || '').trim();
    this.modelName = config.model || process.env.GEMINI_MODEL || 'gemini-3.6-flash';
    this.cache = config.cache;
  }

  isAvailable(): boolean {
    return Boolean(this.apiKey && this.apiKey.length > 5);
  }

  private redactKey(msg: string): string {
    if (!this.apiKey) return msg;
    return msg.split(this.apiKey).join('[REDACTED]');
  }

  async generateStrategy(
    research: ResearchArtifact,
    options: StrategyOptions = {}
  ): Promise<ContentStrategyArtifact> {
    const format = options.format || research.formatTarget || 'short';
    const cacheKey = this.cache?.generateKey('gemini_strategy', {
      topic: research.topic.toLowerCase().trim(),
      format,
      targetDurationCategory: options.targetDurationCategory || 'standard',
    });

    if (this.cache && cacheKey) {
      const cached = await this.cache.get<ContentStrategyArtifact>(cacheKey);
      if (cached) {
        return cached;
      }
    }

    if (!this.isAvailable()) {
      return this.buildHeuristicStrategy(research, format, options);
    }

    try {
      const ai = new GoogleGenAI({ apiKey: this.apiKey });

      const prompt = `You are the Executive Content Strategist for ClipForge, an automated high-retention video production pipeline.
Transform the provided research data into an actionable, non-generic content strategy.

CRITICAL INSTRUCTIONS:
1. DO NOT RE-RESEARCH. Formulate the strategy exclusively from the provided research artifacts.
2. AVOID GENERIC ADVICE like "Start with a hook". Write EXACT hook text, specific visual cues, and concrete narrative beats.
3. FOR SHORT-FORM (9:16 vertical):
   - Immediate high-curiosity opening (0-3s).
   - Minimal setup. High information density.
   - Fast escalation, pattern interrupt mid-way, and definitive payoff before loop.
   - Recommend a flexible duration range (e.g. 40s - 75s based on topic depth). NEVER FIX AT 30s.
4. FOR LONG-FORM (16:9 horizontal):
   - Clear opening promise.
   - Multi-act chaptered narrative progression with rising stakes and evidence.
   - Pattern interrupts spaced strategically to sustain watch time.
   - Recommend a flexible duration range (e.g. 360s - 720s).
5. STRUCTURE ACTIONABLE RETENTION MECHANISMS:
   - HOOK: Present surprising result or contrarian reality immediately.
   - OPEN LOOP: Introduce unanswered question created by that result.
   - PROGRESSION: Reveal evidence in escalating steps.
   - PAYOFF: Deliver the resolution after the strongest evidence.

RESEARCH DATA FOR TOPIC "${research.topic}":
Format Target: ${format}
Observed Competitor Titles: ${JSON.stringify(research.observedData.competitorTitles)}
Common Questions: ${JSON.stringify(research.observedData.commonQuestions)}
Verifiable Facts: ${JSON.stringify(research.observedData.verifiableFacts)}
Promising Angles: ${JSON.stringify(research.inferredInsights.promisingContentAngles)}
Content Gaps: ${JSON.stringify(research.inferredInsights.contentGapsIdentified)}
Potential Hooks: ${JSON.stringify(research.inferredInsights.potentialHooks)}
Curiosity Gaps: ${JSON.stringify(research.inferredInsights.curiosityGaps || [])}

Respond ONLY with a valid JSON object strictly matching this schema:
{
  "topic": "${research.topic}",
  "format": "${format}",
  "targetAudience": {
    "primarySegment": "string (specific persona)",
    "familiarityLevel": "beginner" | "intermediate" | "expert",
    "primaryMotivation": "string"
  },
  "angle": {
    "coreThesis": "string (bold, specific argument)",
    "whyNow": "string",
    "contrarianOrUniquePerspective": "string"
  },
  "hook": {
    "hookText": "Exact spoken opening line (must create immediate curiosity gap)",
    "hookType": "curiosity_gap" | "bold_claim" | "shocking_stat" | "contrarian" | "relatable_pain_point",
    "visualCue": "Specific visual depiction for the opening 3 seconds",
    "durationTargetSeconds": number (${format === 'short' ? '3.0' : '4.5'})
  },
  "titleConcepts": ["string", "string", "string"],
  "narrativeStructure": [
    {
      "actOrSection": "string",
      "objective": "string",
      "approxPercentageOfVideo": number
    }
  ],
  "emotionalTriggers": ["string"],
  "retentionPlan": [
    {
      "timestampTargetSeconds": number,
      "mechanism": "pattern_interrupt" | "curiosity_loop_open" | "curiosity_loop_close" | "pacing_shift" | "key_takeaway",
      "description": "Concrete action taken at this point in video"
    }
  ],
  "callToAction": {
    "type": "comment_prompt" | "subscribe" | "share" | "none",
    "promptText": "string"
  },
  "estimatedDurationRangeSeconds": {
    "min": number,
    "max": number,
    "target": number
  }
}`;

      const response = await ai.models.generateContent({
        model: this.modelName,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.4,
        },
      });

      const responseText = response.text || '{}';
      const parsed = JSON.parse(responseText) as ContentStrategyArtifact;

      const sanitized: ContentStrategyArtifact = {
        jobId: research.jobId,
        createdAt: new Date().toISOString(),
        topic: research.topic,
        format,
        targetAudience: {
          primarySegment: parsed.targetAudience?.primarySegment || 'Knowledge seekers and curious viewers',
          familiarityLevel: parsed.targetAudience?.familiarityLevel || 'intermediate',
          primaryMotivation: parsed.targetAudience?.primaryMotivation || 'Understanding the real mechanism and practical takeaways',
        },
        angle: {
          coreThesis: parsed.angle?.coreThesis || `The real impact of ${research.topic} is different from common perception.`,
          whyNow: parsed.angle?.whyNow || `Recent developments make understanding ${research.topic} essential today.`,
          contrarianOrUniquePerspective: parsed.angle?.contrarianOrUniquePerspective || `Most coverage focuses on hype, but the actual bottleneck reveals the truth.`,
        },
        hook: {
          hookText: parsed.hook?.hookText || `Almost everything you have heard about ${research.topic} is missing the real story.`,
          hookType: parsed.hook?.hookType || 'curiosity_gap',
          visualCue: parsed.hook?.visualCue || 'Rapid cinematic close-up of high-tech interface cutting to unexpected real-world data.',
          durationTargetSeconds: parsed.hook?.durationTargetSeconds || (format === 'short' ? 3.2 : 4.5),
        },
        titleConcepts: Array.isArray(parsed.titleConcepts) && parsed.titleConcepts.length > 0
          ? parsed.titleConcepts
          : [`The Truth About ${research.topic}`, `Why ${research.topic} Changes Everything`],
        narrativeStructure: Array.isArray(parsed.narrativeStructure) && parsed.narrativeStructure.length >= 3
          ? parsed.narrativeStructure
          : this.getDefaultNarrativeStructure(format),
        emotionalTriggers: Array.isArray(parsed.emotionalTriggers) ? parsed.emotionalTriggers : ['curiosity', 'surprise', 'clarity'],
        retentionPlan: Array.isArray(parsed.retentionPlan) && parsed.retentionPlan.length > 0
          ? parsed.retentionPlan
          : this.getDefaultRetentionPlan(format),
        callToAction: parsed.callToAction || {
          type: 'comment_prompt',
          promptText: `What is your take on ${research.topic}? Drop your thoughts below.`,
        },
        estimatedDurationRangeSeconds: parsed.estimatedDurationRangeSeconds || (format === 'short'
          ? { min: 45, max: 75, target: 58 }
          : { min: 360, max: 660, target: 480 }),
      };

      if (this.cache && cacheKey) {
        await this.cache.set('gemini_strategy', cacheKey, sanitized);
      }

      return sanitized;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      throw new Error(this.redactKey(`Gemini strategy generation failed: ${msg}`));
    }
  }

  private buildHeuristicStrategy(
    research: ResearchArtifact,
    format: 'short' | 'long',
    _options: StrategyOptions
  ): ContentStrategyArtifact {
    const isShort = format === 'short';

    return {
      jobId: research.jobId,
      createdAt: new Date().toISOString(),
      topic: research.topic,
      format,
      targetAudience: {
        primarySegment: isShort ? 'Mobile-first curious knowledge consumers' : 'Deep-dive technology and analysis enthusiasts',
        familiarityLevel: 'intermediate',
        primaryMotivation: 'Cut through mainstream buzz and discover the verifiable facts and practical implications.',
      },
      angle: {
        coreThesis: `The true impact of ${research.topic} isn't the surface spectacle—it's the underlying structural shift.`,
        whyNow: `Public attention on ${research.topic} is peaking, but superficial reporting leaves the most important question unanswered.`,
        contrarianOrUniquePerspective: `While most explanations focus on abstract hype, the verified evidence reveals a much more consequential reality.`,
      },
      hook: {
        hookText: isShort
          ? `If you think ${research.topic} is just hype, you are looking at the wrong number.`
          : `Everyone is talking about ${research.topic}, but 90% of people misunderstand the mechanism that actually makes it work.`,
        hookType: 'curiosity_gap',
        visualCue: 'High-contrast text punch-in over rapid macro b-roll, immediately establishing tension.',
        durationTargetSeconds: isShort ? 3.0 : 4.5,
      },
      titleConcepts: [
        `The Hidden Reality of ${research.topic}`,
        `What Nobody Explains About ${research.topic}`,
        `Why ${research.topic} Is Moving Faster Than You Think`,
      ],
      narrativeStructure: this.getDefaultNarrativeStructure(format),
      emotionalTriggers: ['curiosity', 'discovery', 'empowerment', 'clarity'],
      retentionPlan: this.getDefaultRetentionPlan(format),
      callToAction: {
        type: 'comment_prompt',
        promptText: `Did this change how you view ${research.topic}? Share your perspective below.`,
      },
      estimatedDurationRangeSeconds: isShort
        ? { min: 45, max: 70, target: 55 }
        : { min: 360, max: 660, target: 480 },
    };
  }

  private getDefaultNarrativeStructure(format: 'short' | 'long'): Array<{ actOrSection: string; objective: string; approxPercentageOfVideo: number }> {
    if (format === 'short') {
      return [
        {
          actOrSection: 'Hook & Core Disruption',
          objective: 'State the counter-intuitive observation immediately to freeze the scroll.',
          approxPercentageOfVideo: 15,
        },
        {
          actOrSection: 'The Hidden Mechanism',
          objective: 'Explain why the conventional view is wrong using concrete data point.',
          approxPercentageOfVideo: 40,
        },
        {
          actOrSection: 'Pattern Interrupt & Proof',
          objective: 'Visual and auditory shift highlighting the pivotal piece of evidence.',
          approxPercentageOfVideo: 25,
        },
        {
          actOrSection: 'Payoff & Loop Setup',
          objective: 'Resolve the opening curiosity gap with a memorable closing takeaway that naturally loops.',
          approxPercentageOfVideo: 20,
        },
      ];
    }

    return [
      {
        actOrSection: 'Act 1: The Promise & The Paradox',
        objective: 'Hook the viewer with the unexpected contradiction in current discussions.',
        approxPercentageOfVideo: 12,
      },
      {
        actOrSection: 'Act 2: How We Got Here',
        objective: 'Establish verified historical and technological context without dragging pace.',
        approxPercentageOfVideo: 20,
      },
      {
        actOrSection: 'Act 3: The Core Breakdown & Deep Evidence',
        objective: 'Present the primary analysis, breaking down the central mechanisms step-by-step.',
        approxPercentageOfVideo: 35,
      },
      {
        actOrSection: 'Act 4: Counterarguments & Edge Cases',
        objective: 'Address common misconceptions and provide nuanced critical counterpoints.',
        approxPercentageOfVideo: 18,
      },
      {
        actOrSection: 'Act 5: The Synthesis & Verdict',
        objective: 'Deliver the comprehensive resolution, future forecast, and final thought.',
        approxPercentageOfVideo: 15,
      },
    ];
  }

  private getDefaultRetentionPlan(format: 'short' | 'long'): Array<{ timestampTargetSeconds?: number; mechanism: 'pattern_interrupt' | 'curiosity_loop_open' | 'curiosity_loop_close' | 'pacing_shift' | 'key_takeaway'; description: string }> {
    if (format === 'short') {
      return [
        {
          timestampTargetSeconds: 0,
          mechanism: 'curiosity_loop_open',
          description: 'Open curiosity loop by challenging standard assumptions in the first 3 seconds.',
        },
        {
          timestampTargetSeconds: 22,
          mechanism: 'pattern_interrupt',
          description: 'Sudden audio and visual shift to re-engage attention before mid-video drop-off.',
        },
        {
          timestampTargetSeconds: 45,
          mechanism: 'curiosity_loop_close',
          description: 'Deliver the definitive answer to the opening loop.',
        },
      ];
    }

    return [
      {
        timestampTargetSeconds: 0,
        mechanism: 'curiosity_loop_open',
        description: 'Introduce the central unresolved question in the introductory hook.',
      },
      {
        timestampTargetSeconds: 90,
        mechanism: 'pacing_shift',
        description: 'Transition from high-level setup into granular evidence with rapid visual proof.',
      },
      {
        timestampTargetSeconds: 240,
        mechanism: 'pattern_interrupt',
        description: 'Introduce an unexpected contrarian case study to disrupt predictable rhythm.',
      },
      {
        timestampTargetSeconds: 420,
        mechanism: 'key_takeaway',
        description: 'Synthesize actionable conclusions before delivering the final resolution.',
      },
    ];
  }
}
